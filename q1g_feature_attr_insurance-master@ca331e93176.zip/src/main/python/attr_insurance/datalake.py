from oktopuss_core.datalake import DefaultDatalake
from oktopuss_core.datalinks import ComponentDataLink
from oktopuss_datalake.datalake_env import update_environment
from oktopuss_datalake.datalakes.parser import Parser
from pkg_resources import resource_filename
from datalake_csob_sk.tenants.q0g.q0gdatalake import Q0GDatalake


Clean, _clean_yml = Parser.parse(resource_filename('attr_insurance', 'resources/datalakes/clean'))
Feature, _feature_yml = Parser.parse(resource_filename('attr_insurance', 'resources/datalakes/feature'))


class Datalake(DefaultDatalake):
    def __init__(self):
        DefaultDatalake.__init__(self)
        self.datalake = Q0GDatalake()
        self.environments.update(ds=self.initDataScienceEnvironment)

    def initDefaultEnvironment(self, env):
        env = self.datalake.initDefaultEnvironment(env)
        env = update_environment(env, Clean, _clean_yml)
        env = update_environment(env, Feature, _feature_yml)
        return env

    def initDataScienceEnvironment(self, env):
        env = self.initDefaultEnvironment(env)

        for datalink in Clean:
            dl = env[datalink]

            # Set DS relative path just in cloud environment. For local development full path is required.
            if type(dl) is ComponentDataLink:
                env[datalink].set_path_to_ds_case_space()

        for datalink in Feature:
            dl = env[datalink]

            # Set DS relative path just in cloud environment. For local development full path is required.
            if type(dl) is ComponentDataLink:
                env[datalink].set_path_to_ds_case_space()

        return env
