from pyspark.sql import DataFrame
from dateutil.relativedelta import relativedelta
from q1g_common.utils.date import get_last_day_of_month
from q1g_common.pipelines.csob_pipeline import CSOBPipeline
from attr_insurance.pipelines.transformations import transform

sources_master = {
    'dmsk__l0_owner__card_svc': {
        'first_day': relativedelta(months=-1, day=31),
        'last_day': relativedelta(day=31)},
    'dmsk__l0_owner__cont': {},
    'dmsk__l0_owner__cont_dt_actl': {},
    'dmsk__l0_owner__cont_dt_hist': {},
    'dmsk__l0_owner__cont_gen': {},
    'dmsk__l0_owner__cont_prod': {},
    'dmsk__l0_owner__cont_rltd': {},
    'dmsk__l0_owner__cont_stat': {},
    'dmsk__l0_owner__cont_stat_type_gen': {},
    'dmsk__l0_owner__cont_val': {},
    'dmsk__l0_owner__party': {'table_type': 'latestUntil'},
    'dmsk__l0_owner__party_cont': {},
    'dmsk__l0_owner__party_rltd': {},
    'dmsk__l0_owner__prod': {},
    'dmsk__l0_owner__prod_hier': {},
    'dmsk__l0_owner__prod_nm': {},
    'dmsk__l0_owner__card': {}
}
sources_clean = {
    'mis__ins__cakaren_storien_detail_dat': {},
    'mis__ins__pzp_storna_dat': {},
    'mis__ins__prieskum_spokojnosti_dat': {},
    'mis__ins__banka_upomienky_dat': {},
    'mis__ins__poistovna_zmluvy_dat': {},
    'mis__ins__pz_detail_cp_detail': {},
    'mis__ins__pz_detail_cp_osoby': {'dtkn_cols': ['kod_rc']},
    'mis__ins__pz_detail_domos_detail': {},
    'mis__ins__pz_detail_domos_plochy': {},
    'mis__ins__pz_detail_life_person': {},
}
sources_feature = {
    'dmsk__je69050__administrative_structure_svk': {},
    'dmsk__je69050__area_code_gen': {},
    'attr_client_base': {},
    'card': {},
    'attr_insurance': {
        'first_day': relativedelta(months=-12, day=31),
        'last_day': relativedelta(months=-1, day=31)},
    'product_level_category': {'table_type': 'latestUntil'}
}
sources = {
    'master': sources_master,
    'feature': sources_feature,
    'clean': sources_clean
}
tkn_policies = {}


class AttrInsurancePipeline(CSOBPipeline):

    def get_initial_configuration(self):
        if get_last_day_of_month(self.business_date) == self.business_date:
            self.modelling_date = self.business_date
        else:
            self.modelling_date = get_last_day_of_month(self.business_date + relativedelta(months=-1))

        return sources, tkn_policies

    def transform_sources(self, sources_df: dict) -> DataFrame:
        final_df = transform(sources_df, self.modelling_date, self.spark)

        return final_df
