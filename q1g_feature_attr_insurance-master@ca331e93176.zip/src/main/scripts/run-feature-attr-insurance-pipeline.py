#!/usr/bin/env python
import argparse
import logging
from oktopuss_common.logging import setupLogging
from q1g_common.utils.parser import parse_date_time
from attr_insurance.pipelines.attr_insurance_pipeline import AttrInsurancePipeline
from oktopuss_spark.spark import spark_session

if __name__ == '__main__':
    # Command line argument parsing
    # These parameters will have to come from the airflow dag
    parser = argparse.ArgumentParser()
    parser.add_argument('--verbose', help='Set loglevel to debug', required=False, action='store_true')
    parser.add_argument('--business_date', help='Date for which to read data', required=True, type=str)
    parser.add_argument(
        '--include_tokenization',
        help='Flag set to include tokenization mechanism',
        required=False,
        action='store_true'
    )

    arguments = parser.parse_args()

    # Parse business_date
    business_date = parse_date_time('business_date', arguments.business_date)

    # Set up logger
    setupLogging(default_level=logging.DEBUG if arguments.verbose else logging.INFO)
    logger = logging.root

    with spark_session(options={
        "spark.executor.memoryOverheadFactor": "0.4",
        "spark.default.parallelism": "600",
        "spark.sql.shuffle.partitions": "600",
    }) as spark:
        pipeline = AttrInsurancePipeline(
            business_date=business_date,
            target_key='attr_insurance',
            target_layer='feature',
            include_tokenization=arguments.include_tokenization)
        pipeline.run_pipeline()
