from datetime import datetime, date
from oktopuss_test.spark import SparkTestCase
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, LongType, StringType
from attr_insurance.pipelines.attr_insurance_pipeline import AttrInsurancePipeline
import test_data
from attr_insurance.pipelines.transformations import (
    prepare_dtsk, prepare_ukaz1, prepare_cont_stav, prepare_cpz, prepare_domos,
    prepare_domos_plocha, prepare_domos_ps, prepare_csv, prepare_finukaz, prepare_cp_info,
    prepare_pu, prepare_upom, prepare_agg_prev_two_m, prepare_agg_prev_y, prepare_tmp_life_assured,
    prepare_tmp_life_assured_c, prepare_b, prepare_c, prepare_contract, prepare_life_assured,
    prepare_cp_osoby2, prepare_cp_osoby3, prepare_cp_osoby4, prepare_prev_val_q,
    prepare_tmp_insurance_cont2, prepare_key_employee, prepare_by_customer, prepare_prev_vals,
)

DT = datetime(2023, 1, 19)


class TestAttrInsurancePipeline(SparkTestCase):
    def setUp(self):
        self.pipeline = AttrInsurancePipeline(DT, target_key='attr_insurance',
                                              target_layer='feature', include_tokenization=True)
        self.spark = self.pipeline.spark
        self.spark.sql(f"""
            SET process_dt = TO_DATE('{DT.date()}', 'yyyy-MM-dd')
        """)
        self.spark.sql("""
            SET process_dt_hist = ${process_dt} -60
        """)

    @staticmethod
    def convert_to_long(df):
        cols_to_cast = []
        for field in df.schema.fields:
            if str(field.dataType) == "IntegerType":
                cols_to_cast.append(field.name)
        for col_nm in cols_to_cast:
            df = df.withColumn(col_nm, col(col_nm).cast('long'))
        return df

    @staticmethod
    def convert_to_int(df):
        cols_to_cast = []
        for field in df.schema.fields:
            if str(field.dataType) == "IntegerType":
                cols_to_cast.append(field.name)
        for col_nm in cols_to_cast:
            df = df.withColumn(col_nm, col(col_nm).cast('int'))
        return df

    def test_prepare_dtsk(self):
        src_df_party = self.spark.createDataFrame([
            (1, 790, 'val1', 'subtp1'),
            (2, 790, 'val2', 'subtp2'),
            (3, 790, 'val3', 'subtp3')
        ], ['party_id', 'src_syst_cd', 'party_src_val', 'party_subtp_cd'])

        src_df_party_rltd = self.spark.createDataFrame([
            (11, 1, 4, '2023-01-01', '2023-01-31'),
            (22, 2, 4, '2023-01-01', '2023-01-31'),
            (33, 3, 4, '2023-01-01', '2023-01-31')
        ], ['party_id', 'child_party_id', 'party_rltd_rsn_cd', 'party_rltd_start_dt', 'party_rltd_end_dt'])

        expected_df = self.spark.createDataFrame([
            (11, 1, 'val1', 'subtp1'),
            (22, 2, 'val2', 'subtp2'),
            (33, 3, 'val3', 'subtp3')
        ], ['CUSTOMERID', 'party_id', 'party_src_val', 'typ'])

        print("### Source:")
        src_df_party.show()
        src_df_party_rltd.show()
        print("### Expected:")
        expected_df.show()
        target_data = prepare_dtsk(src_df_party, src_df_party_rltd, self.spark)
        print("### Target:")
        target_data.show()
        self.assertDatasetEqual(target_data, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_ukaz1(self):
        # Prepare data
        data_cont = [("1", 3, 790, 'Y')]
        data_cont_val = [("1", 30654, 100, '2023-01-01', '2023-12-31'),
                         ("1", 30655, 200, '2023-01-01', '2023-12-31'),
                         ("1", 30656, 300, '2023-01-01', '2023-12-31')]
        data_cont_dt_hist = [("1", 6022, '2023-01-01', '2023-01-01', '2023-12-31'),
                             ("1", 6023, '2023-01-01', '2023-01-01', '2023-12-31')]

        df_cont = self.spark.createDataFrame(data_cont,
                                             ["cont_id", "cont_type_cd", "src_syst_cd", "cont_single_acct_in"])
        df_cont_val = self.spark.createDataFrame(data_cont_val,
                                                 ["cont_id", "meas_cd", "cont_val_am", "cont_val_start_dt",
                                                  "cont_val_end_dt"])
        df_cont_dt_hist = self.spark.createDataFrame(data_cont_dt_hist,
                                                     ["cont_id", "meas_cd", "cont_dt_hist_dt", "cont_dt_start_dt",
                                                      "cont_dt_end_dt"])

        result = prepare_ukaz1(df_cont, df_cont_val, df_cont_dt_hist, self.spark)

        # Prepare expected result
        expected_data = [("1", 100, 200, 300, '2023-01-01', '2023-01-01')]
        expected_df = self.spark.createDataFrame(expected_data,
                                                 ["cont_id", "SPLATKA_VYSKA", "POISTNE", "KAPITALOVA_HODNOTA",
                                                  "DT_VLOZENIA_KONTR_POIST", "DT_PRVEJ_PLATBY"])
        print("### Source:")
        df_cont.show()
        df_cont_val.show()
        df_cont_dt_hist.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_prepare_cont_stav(self):
        source = [("type_cd1", "Storno pojistky", "2023-01-01", "2023-01-31"),
                  ("type_cd2", "Storno pojistky", "2023-01-01", "2023-01-31"),
                  ("type_cd3", "test", "2023-01-01", "2023-01-31")]
        source_df = self.spark.createDataFrame(source,
                                               ["cont_stat_type_cd", "cont_stat_type_ds",
                                                "cont_stat_type_gen_start_dt",
                                                "cont_stat_type_gen_end_dt"])
        expected = [("type_cd1", "Storno pojistky", "2023-01-01", 0),
                    ("type_cd2", "Storno pojistky", "2023-01-01", 0),
                    ("type_cd3", "test", "2023-01-01", 1)]
        expected_df = self.spark.createDataFrame(expected,
                                                 ["cont_stat_type_cd", "cont_stat_type_ds",
                                                  "cont_stat_type_gen_start_dt",
                                                  "OTVORENA"])
        result = prepare_cont_stav(source_df, self.spark)
        print("### Source:")
        source_df.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_cpz(self):
        src_df_cont = self.spark.createDataFrame([(1, 'A', 790),
                                                  (2, 'B', 790),
                                                  (3, 'C', 788)],
                                                 ['cont_id', 'cont_acct', 'src_syst_cd'])
        src_df_cont_rltd = self.spark.createDataFrame([(1, 1, 790, 71),
                                                       (2, 2,  790, 71),
                                                       (3, 3,  788, 77)],
                                                      ['child_cont_id', 'cont_id',
                                                       'etl_src_syst_cd', 'cont_rltd_rsn_cd'])
        expected_df = self.spark.createDataFrame([(1, 'A'),
                                                  (2, 'B')],
                                                 ['cont_id', 'cont_acct'])
        result = prepare_cpz(src_df_cont, src_df_cont_rltd, self.spark)
        print("### Source:")
        src_df_cont.show()
        src_df_cont_rltd.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_domos(self):
        src_df_pz_detail_domos_detail_dat = self.spark.createDataFrame([
            ("CPZ1", "INS_TYPE1", "REGION1", "LIABILITY1", "PACKAGE1", "POOL1"),
            ("CPZ2", "INS_TYPE2", "REGION2", "LIABILITY2", "PACKAGE2", "POOL2"),
            ("CPZ3", "INS_TYPE3", "REGION3", "LIABILITY3", "PACKAGE3", "POOL3")
        ], ["CPZ", "HOUSE_INS_TYPE", "REGION_INS_REALITY", "FLG_LIABILITY", "PACKAGE_TYPE", "FLG_POOL"])

        expected_df = self.spark.createDataFrame([
            ("CPZ1", "INS_TYPE1", "REGION1", "LIABILITY1", "PACKAGE1", "POOL1"),
            ("CPZ2", "INS_TYPE2", "REGION2", "LIABILITY2", "PACKAGE2", "POOL2"),
            ("CPZ3", "INS_TYPE3", "REGION3", "LIABILITY3", "PACKAGE3", "POOL3")
        ], ["CPZ", "HOUSE_INS_TYPE", "REGION_INS_REALITY", "FLG_LIABILITY", "PACKAGE_TYPE", "FLG_POOL"])
        result = prepare_domos(src_df_pz_detail_domos_detail_dat, self.spark)
        print("### Source:")
        src_df_pz_detail_domos_detail_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def prepare_prepare_domos_plocha(self):
        src_df_pz_detail_domos_plochy_dat = self.spark.createDataFrame([
            ("CPZ1", "Pivnica (plocha)", 10),
            ("CPZ1", "Garaz (plocha)", 20),
            ("CPZ1", "Domacnost podkrovie m2", 30),
            ("CPZ1", "Domacnost byt m2", 40),
            ("CPZ1", "Povala (plocha)", 50),
            ("CPZ1", "Vedlajsia budova (plocha)", 60),
            ("CPZ1", "Domacnost garaz m2", 70),
            ("CPZ1", "Prizemie (plocha)", 80),
            ("CPZ1", "Domacnost vedl. budova m2", 90),
            ("CPZ1", "Domacnost prizemie m2", 100),
            ("CPZ1", "Domacnost pivnica m2", 110),
            ("CPZ1", "Podkrovie (plocha)", 120),
            ("CPZ1", "Podlazie (plocha)", 130),
            ("CPZ1", "Domacnost povala m2", 140),
            ("CPZ1", "Byt (plocha)", 150),
            ("CPZ1", "Domacnost podlazie m2", 160),
            ("CPZ1", "Stavba - obývaná plocha", 170),
            ("CPZ1", "Stavba - neobývaná plocha", 180)
        ], ["CPZ", "popis", "m2"])
        expected_df = self.spark.createDataFrame([
            ("CPZ1", 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180)
        ], ["CPZ", "pivnica_plocha", "garaz_plocha", "domacnost_podkrovie_m2", "domacnost_byt_m2",
            "povala_plocha", "vedl_budova_plocha", "domacnost_garaz_m2", "prizemie_plocha",
            "domacnost_vedl_budova_m2", "domacnost_prizemie_m2", "domacnost_pivnica_m2",
            "podkrovie_plocha", "podlazie_plocha", "domacnost_povala_m2", "byt_plocha",
            "domacnost_podlazie_m2", "dom_obyvana_m2", "dom_neobyvana_m2"]
        )
        result = prepare_domos_plocha(src_df_pz_detail_domos_plochy_dat, self.spark)
        print("### Source:")
        src_df_pz_detail_domos_plochy_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_domos_ps(self):
        src_df_pz_detail_domos_plochy_dat = self.spark.createDataFrame([
            ("CPZ1", "Pivnica (plocha)", 10),
            ("CPZ1", "Garaz (plocha)", 20),
            ("CPZ1", "Domacnost podkrovie m2", 30),
            ("CPZ2", "Pivnica (plocha)", 15),
            ("CPZ2", "Garaz (plocha)", 25),
            ("CPZ2", "Domacnost podkrovie m2", 35)
        ], ["CPZ", "popis", "m2"])

        schema = StructType([
            StructField("CPZ", StringType(), True),
            StructField("pivnica_plocha", LongType(), True),
            StructField("garaz_plocha", LongType(), True),
            StructField("domacnost_podkrovie_m2", LongType(), True),
            StructField("domacnost_byt_m2", LongType(), True),
            StructField("povala_plocha", LongType(), True),
            StructField("vedl_budova_plocha", LongType(), True),
            StructField("domacnost_garaz_m2", LongType(), True),
            StructField("prizemie_plocha", LongType(), True),
            StructField("domacnost_vedl_budova_m2", LongType(), True),
            StructField("domacnost_prizemie_m2", LongType(), True),
            StructField("domacnost_pivnica_m2", LongType(), True),
            StructField("podkrovie_plocha", LongType(), True),
            StructField("podlazie_plocha", LongType(), True),
            StructField("domacnost_povala_m2", LongType(), True),
            StructField("byt_plocha", LongType(), True),
            StructField("domacnost_podlazie_m2", LongType(), True),
            StructField("dom_obyvana_m2", LongType(), True),
            StructField("dom_neobyvana_m2", LongType(), True)
        ])
        expected_df = self.spark.createDataFrame([
            ("CPZ1", 10, 20, 30, None, None, None, None, None, None, None,
             None, None, None, None, None, None, None, None),
            ("CPZ2", 15, 25, 35, None, None, None, None, None, None, None,
             None, None, None, None, None, None, None, None)
        ], schema)
        result = prepare_domos_ps(src_df_pz_detail_domos_plochy_dat, self.spark)
        print("### Source:")
        src_df_pz_detail_domos_plochy_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_csv(self):
        src_df_card_svc = self.spark.createDataFrame([
            (1, 1, 'Product 1', '2023-01-01', '2023-01-31'),
            (1, 2, 'Product 2', '2023-02-01', '2023-02-28'),
            (2, 3, 'Product 3', '2023-01-01', '2023-01-31')],
            ['card_id', 'prod_id', 'PROD_NM_CZ', 'card_svc_start_dt', 'card_svc_end_dt'])
        src_df_prod = self.spark.createDataFrame([
            (1, 'Product 1', 16),
            (2, 'Product 2', 136),
            (3, 'Product 3', 16)],
            ['prod_id', 'PROD_NM_CZ', 'prod_type_cd'])
        src_df_prod_nm = self.spark.createDataFrame([
            (1, 'Product 1', '2023-01-01', '2023-12-31'),
            (2, 'Product 2', '2023-01-01', '2023-12-31'),
            (3, 'Product 3', '2023-01-01', '2023-12-31')],
           ['prod_id', 'PROD_NM_CZ', 'prod_nm_start_dt', 'prod_nm_end_dt'])
        src_df_prod_hier = self.spark.createDataFrame([
            (1, 2, '2023-01-01', '2023-12-31'),
            (2, 3, '2023-01-01', '2023-12-31')],
           ['child_prod_id', 'prod_id', 'prod_hier_start_dt', 'prod_hier_end_dt'])
        expected_df = self.spark.createDataFrame([(1, 1, 'Product 1', '2023-01-01', '2023-01-31'),
                                                  (1, 2, 'Product 2', '2023-02-01', '2023-02-28')
                                                  ],
                                                 ['card_id', 'prod_id', 'PROD_NM_CZ', 'start_dt', 'end_dt'])
        result = prepare_csv(src_df_card_svc, src_df_prod, src_df_prod_nm, src_df_prod_hier, self.spark)
        print("### Source:")
        src_df_card_svc.show()
        src_df_prod.show()
        src_df_prod_nm.show()
        src_df_prod_hier.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_finukaz(self):
        src_df_cont = self.spark.createDataFrame([
            (1, '2023-01-01', '2023-12-31', 790, 3, 'N')],
            ['cont_id', 'cont_start_dt', 'cont_end_dt', 'src_syst_cd', 'cont_type_cd', 'cont_single_acct_in'])
        src_df_cont_val = self.spark.createDataFrame([
            (1, 30654, 100, '2023-01-01', '2023-12-31'),
            (1, 30655, 200, '2023-01-01', '2023-12-31'),
            (1, 30656, 300, '2023-01-01', '2023-12-31')],
            ['cont_id', 'meas_cd', 'cont_val_am', 'cont_val_start_dt', 'cont_val_end_dt'])
        src_df_cont_dt_hist = self.spark.createDataFrame([
            (1, '2023-01-01', '2023-12-31', 6022)],
            ['cont_id', 'cont_dt_start_dt', 'cont_dt_end_dt', 'meas_cd'])
        expected_df = self.spark.createDataFrame([
            (1, 100, 200, 300)],
            ['cont_id', 'PAYMENT_VALUE', 'INSURANCE_PREMIUM', 'CAPITAL_VALUE'])
        result = prepare_finukaz(src_df_cont, src_df_cont_val, src_df_cont_dt_hist, self.spark)
        print("### Source:")
        src_df_cont.show()
        src_df_cont_val.show()
        src_df_cont_dt_hist.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_cp_info(self):
        src_df_pz_detail_cp_detail_dat = self.spark.createDataFrame([
            ("CPZ1", "Territory1", "RiskType1", 1000, "Variant1"),
            ("CPZ2", "Territory2", "RiskType2", 2000, "Variant2"),
            ("CPZ3", "Territory3", "RiskType3", 3000, "Variant3")
        ], ["CPZ", "INS_TERRITORY", "RISK_TYPE", "LUGGAGE_INS_AMT", "VARIANT"])
        expected_df = self.spark.createDataFrame([
            ("CPZ1", "Territory1", "RiskType1", 1000, "Variant1"),
            ("CPZ2", "Territory2", "RiskType2", 2000, "Variant2"),
            ("CPZ3", "Territory3", "RiskType3", 3000, "Variant3")
        ], ["CPZ", "INS_TERRITORY", "RISK_TYPE", "LUGGAGE_INS_AMT", "VARIANT"])

        result = prepare_cp_info(src_df_pz_detail_cp_detail_dat, self.spark)
        print("### Source:")
        src_df_pz_detail_cp_detail_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_pu(self):
        src_df_insurance_research_lpu_dat = self.spark.createDataFrame([
            (1, '2023-01-01', '2023-01-15'),
            (2, '2023-02-01', '2023-02-15'),
            (3, '2023-03-01', '2023-03-15')
        ], ['id', 'D_VZNIKU_PU', 'D_REVIDACIE'])
        expected_df = self.spark.createDataFrame([
            (1, '2023-01-01', '2023-01-15'),
            ], ['id', 'D_VZNIKU_PU', 'D_REVIDACIE'])
        result = prepare_pu(src_df_insurance_research_lpu_dat, self.spark)
        print("### Source:")
        src_df_insurance_research_lpu_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_upom(self):
        src_df_insurance_upomienky_dat = self.spark.createDataFrame([
            (1, '2022-01-01'),
            (2, '2023-01-01'),
            (3, '2023-01-12'),
            (4, '2023-01-01'),
            (5, '2023-05-01')
        ], ['id', 'd_tlac_upom'])
        result = prepare_upom(src_df_insurance_upomienky_dat, self.spark)
        expected_df = self.spark.createDataFrame([
            (2, '2023-01-01'),
            (3, '2023-01-12'),
            (4, '2023-01-01')
        ], ['id', 'd_tlac_upom'])
        print("### Source:")
        src_df_insurance_upomienky_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(result, expected_df, order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_agg_prev_two_m(self):
        src_df_attr_insurance = self.spark.createDataFrame([
            (202301, 1, 100, 10, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
            (202212, 2, 200, 20, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1),
            (202211, 3, 300, 30, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
        ], ["month_id", "customerid", "SUM_PAYOUT_INS_M", "C_CLAIM_INS_M", "I_WORK_TRAVEL_INS", "I_OWED_INS_M",
            "C_CLAIM_DENIED_INS_M", "I_REMINDER_INS_M", "c_opened_RISK_LIFE_INS", "c_opened_invest_life_ins",
            "c_opened_reg_expenses_ins", "c_opened_ins", "c_active_ins",
            "c_RISK_LIFE_INS",
            "c_invest_life_ins",
            "SUM_DURATION_TRAVEL_INS",
            "c_reg_expenses_ins"])
        expected_df = self.spark.createDataFrame([
            (2, 200, 20, 0, 0, 0, 0, 0, 1, 0, 1),
            (3, 300, 30, 1, 1, 5, 1, 1, 0, 0, 1)
        ], ["customerid", "SUM_PAYOUT_INS", "C_CLAIM_INS", "I_WORK_TRAVEL_INS_Q", "I_OWE_INS_Q",
            "C_CLAIM_DENIED_INS_Q", "I_REMINDER_INS_Q", "I_OPENED_LIFE_INS_Q", "I_OPENED_NONLIFE_INS_Q",
            "I_NONLIFE_INS_Q", "I_LIFE_INS_Q"])
        result = prepare_agg_prev_two_m(src_df_attr_insurance, self.spark)
        print("### Source:")
        src_df_attr_insurance.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_agg_prev_y(self):
        src_df_attr_insurance = self.spark.createDataFrame([
            (202211, 1, 100, 5, 1, 2, 1, 1, 1, 1, 10, 1, 1, 1, 1, 1, 1, 1, 1),
            (202212, 2, 200, 10, 0, 3, 0, 0, 1, 1, 20, 1, 1, 1, 1, 1, 1, 1, 1),
            (202210, 3, 300, 15, 1, 0, 1, 1, 0, 1, 30, 1, 1, 1, 1, 1, 1, 1, 1)
        ], ["month_id", "customerid", "SUM_PAYOUT_INS_M", "C_CLAIM_INS_M", "I_WORK_TRAVEL_INS",
            "C_CLAIM_DENIED_INS_M",  "I_REMINDER_INS_M", "I_OWED_INS_M", "c_opened_invest_life_ins",
            "c_opened_RISK_LIFE_INS",
            "I_NONLIFE_INS_Y", "I_LIFE_INS_Y", "SUM_DURATION_TRAVEL_INS_Y",  "c_opened_ins", "c_active_ins",
            "c_RISK_LIFE_INS",
            "c_invest_life_ins",
            "SUM_DURATION_TRAVEL_INS",
            "c_reg_expenses_ins"])
        expected_df = self.spark.createDataFrame([
            (1, 100, 5, 1, 2, 1, 1, 1, 0, 0, 1, 1),
            (2, 200, 10, 0, 3, 0, 0, 1, 0, 0, 1, 1),
            (3, 300, 15, 1, 0, 1, 1, 1, 0, 0, 1, 1)
        ], ["customerid", "SUM_PAYOUT_INS", "C_CLAIM_INS", "I_WORK_TRAVEL_INS_Y", "C_CLAIM_DENIED_INS_Y",
            "I_REMINDER_INS_Y", "I_OWE_INS_Y", "I_OPENED_LIFE_INS_Y", "I_OPENED_NONLIFE_INS_Y",
            "I_NONLIFE_INS_Y", "I_LIFE_INS_Y", "SUM_DURATION_TRAVEL_INS_Y"])

        result = prepare_agg_prev_y(src_df_attr_insurance, self.spark)
        print("### Source:")
        src_df_attr_insurance.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_tmp_life_assured(self):
        src_df_pz_detail_life_person_dat = self.spark.createDataFrame([
            ("CPZ1", "Life Assured", "CUSTOMER1"),
            ("CPZ2", "Life Assured", "CUSTOMER2"),
            ("CPZ3", "Other", "CUSTOMER3"),
            ("CPZ4", "Life Assured", None),
        ], ["CPZ", "PERSON_TYPE", "CUSTOMERID"])
        expected_df = self.spark.createDataFrame([
            ("CPZ1", "CUSTOMER1"),
            ("CPZ2", "CUSTOMER2"),
        ], ["CPZ", "CUSTOMERID"])
        result = prepare_tmp_life_assured(src_df_pz_detail_life_person_dat, self.spark)
        print("### Source:")
        src_df_pz_detail_life_person_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_tmp_life_assured_c(self):
        src_df_pz_detail_life_person_dat = self.spark.createDataFrame([
            ("CPZ1", "Payer", "C",  "Customer1"),
            ("CPZ2", "Payer", "C", "Customer2"),
            ("CPZ3", "Payer", "M",  "Customer3"),
            ("CPZ1", "Life Assured", "C", "Customer4"),
            ("CPZ2", "Life Assured", "C", None),
        ], ["CPZ", "PERSON_TYPE", "SEX",  "CUSTOMERID"])

        expected_df = self.spark.createDataFrame([
            ("CPZ1", "Customer4"),
        ], ["CPZ", "CUSTOMERID"])

        result = prepare_tmp_life_assured_c(src_df_pz_detail_life_person_dat, self.spark)
        print("### Source:")
        src_df_pz_detail_life_person_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_b(self):
        src_df_attr_client_base = self.spark.createDataFrame([
            (202301, 1),
            (202301, 2),
            (202302, 3)],
            ["month_id", "customerid"])
        expected_df = self.spark.createDataFrame([
            (202301, 1),
            (202301, 2)],
            ["month_id", "customerid"])
        result = prepare_b(src_df_attr_client_base, self.spark)
        print("### Source:")
        src_df_attr_client_base.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_c(self):
        df_stg_insurance_cont = self.spark.createDataFrame([
            (1, '123-456', 'PROD1', '123456', 'PROD1', '2023-01-01', '2023-02-01',
             '2023-03-01', '2023-04-01', 100, 50, 500, True),
            (2, '789-012', 'PROD2', '789012', 'PROD2', '2023-02-01', '2023-03-01',
             '2023-04-01', '2023-05-01', 200, 100, 1000, False)
        ], ['insert_dt', 'CUSTOMERID', 'CONT_ID', 'CONT_ACCT', 'PROD_SRC_VAL', 'DT_NEGOTIATED_INS', 'DT_START_INS',
            'DT_END_INS', 'DT_CANCELED_INS', 'PAYMENT_VALUE', 'INSURANCE_PREMIUM', 'CAPITAL_VALUE', 'ACTIVE'])

        expected_df = self.spark.createDataFrame([
            (1, '123-456', 'PROD1', '123456', 'PROD1', '2023-01-01',
             '2023-02-01', '2023-03-01', '2023-04-01', 100, 50, 500, True),
            (2, '789-012', 'PROD2', '789012', 'PROD2', '2023-02-01',
             '2023-03-01', '2023-04-01', '2023-05-01', 200, 100, 1000, False)
        ], ['insert_dt', 'CUSTOMERID', 'CONT_ID', 'CONT_ACCT', 'PROD_SRC_VAL', 'DT_NEGOTIATED_INS', 'DT_START_INS',
            'DT_END_INS', 'DT_CANCELED_INS', 'PAYMENT_VALUE', 'INSURANCE_PREMIUM', 'CAPITAL_VALUE', 'ACTIVE'])
        result = prepare_c(df_stg_insurance_cont, self.spark)
        print("### Source:")
        df_stg_insurance_cont.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_contract(self):

        # c.insert_dt, c.CUSTOMERID, c.CONT_ID, c.CONT_ACCT,
        # c.PROD_SRC_VAL, c.DT_NEGOTIATED_INS, c.DT_START_INS, c.DT_END_INS,
        # c.PAYMENT_VALUE, c.INSURANCE_PREMIUM, c.CAPITAL_VALUE,
        # case when c.DT_END_INS >= ${process_dt} and (c.DT_CANCELED_INS is null or c.DT_CANCELED_INS > ${process_dt})
        # then c.ACTIVE else 0 end as ACTIVE,
        df_c = self.spark.createDataFrame(
            [(1, 'A', 1, 'VAL1',
              date(2023, 1, 1), date(2023, 1, 1), date(2022, 12, 1), date(2023, 12, 31), date(2023, 12, 1),
              100, 0, 10, 1),
             (2, 'B', 2, 'VAL2',
              date(2023, 1, 1), date(2023, 1, 1), date(2022, 12, 1), date(2023, 12, 31), None,
              100, 0, 10, 1)],
            ['CUSTOMERID', 'CONT_ID', 'CONT_ACCT', 'PROD_SRC_VAL',
             'insert_dt', 'DT_NEGOTIATED_INS', 'DT_START_INS', 'DT_END_INS', 'DT_CANCELED_INS',
             'PAYMENT_VALUE', 'INSURANCE_PREMIUM', 'CAPITAL_VALUE', 'ACTIVE'])

        src_df_insurance_cakajuce_stor_dat = self.spark.createDataFrame([
            (1, 'X'),
            (2, 'Y')],
            ['KOD_CISLO_ZMLUVY', 'DATUM_STORNA'])
        src_df_insurance_pzp_storna_dat = self.spark.createDataFrame([
            (1, 'P'),
            (2, 'Q')],
            ['KOD_CISLO_ZMLUVY', 'D_STORNA'])
        src_df_insurance_zmluvy_dat = self.spark.createDataFrame([
            (1, 'M'),
            (2, 'N')],
            ['C_POJ_SML', 'DAT_STORNA'])
        expected_df = self.spark.createDataFrame([
            (date(2023, 1, 1), 1, 'A', 1, 'VAL1',
             date(2023, 1, 1),  date(2022, 12, 1), date(2023, 12, 31), 100, 0, 10, 1,
             '2023-12-01'),
            (date(2023, 1, 1), 2, 'B', 2, 'VAL2',
             date(2023, 1, 1),  date(2022, 12, 1), date(2023, 12, 31), 100, 0, 10, 1,
             'Q')],
            ['insert_dt', 'customerid', 'cont_id', 'cont_acct', 'prod_src_val', 'dt_negotiated_ins',
             'dt_start_ins', 'dt_end_ins', 'payment_value', 'insurance_premium',
             'capital_value', 'active', 'dt_canceled_ins'])

        result = prepare_contract(df_c, src_df_insurance_cakajuce_stor_dat, src_df_insurance_pzp_storna_dat,
                                  src_df_insurance_zmluvy_dat, self.spark)
        print("### Source:")
        df_c.show()
        src_df_insurance_cakajuce_stor_dat.show()
        src_df_insurance_pzp_storna_dat.show()
        src_df_insurance_zmluvy_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_life_assured(self):
        df_stg_insurance_cont = self.spark.createDataFrame([
            ('CPZ1', 1, '2023-01-01', '2023-12-31', None),
            ('CPZ2', 1, '2023-01-01', '2023-12-31', None),
            ('CPZ3', 0, '2023-01-01', '2023-12-31', '2021-12-31')
        ], ['CONT_ACCT', 'ACTIVE', 'DT_START_INS', 'DT_END_INS', 'DT_CANCELED_INS'])
        df_tmp_life_assured = self.spark.createDataFrame([
            ('CPZ1', 1, 'customer1'),
            ('CPZ2', 2, 'customer2'),
            ('CPZ3', 2, 'customer3')
        ], ['CPZ', 'customerid', 'name'])

        result = prepare_life_assured(df_stg_insurance_cont, df_tmp_life_assured, self.spark)
        expected_df = self.spark.createDataFrame([
            (1, 1),
            (2, 1),

        ], ['customerid', 'I_LIFE_ASSURED'])

        print("### Source:")
        df_stg_insurance_cont.show()
        df_tmp_life_assured.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_cp_osoby2(self):
        src_df_pz_detail_cp_osoby_dat = self.spark.createDataFrame([
            ("CPZ1", "Poistený"),
            ("CPZ2", "Poistený"),
            ("CPZ2", "Iný"),
            ("CPZ3", "Poistený"),
            ("CPZ3", "Poistený"),
            ("CPZ3", "Iný"),
        ], ["CPZ", "osobavztah"])
        result = prepare_cp_osoby2(src_df_pz_detail_cp_osoby_dat, self.spark)
        expected_df = self.spark.createDataFrame([
            ("CPZ1", 1),
            ("CPZ2", 1),
            ("CPZ3", 2),
        ], ["CPZ", "NUM_INSURED"])
        print("### Source:")
        src_df_pz_detail_cp_osoby_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_cp_osoby3(self):
        src_df_pz_detail_cp_osoby_dat = self.spark.createDataFrame([
            (1, '2000-01-01', 'Poistený', '1234567890'),
            (2, '2005-05-05', 'Iný', '0987654321'),
            (3, '2010-10-10', 'Poistený', '9876543210')
        ], ['CPZ', 'process_dt', 'osobavztah', 'kod_RC'])
        result = prepare_cp_osoby3(src_df_pz_detail_cp_osoby_dat, self.spark)
        expected_df = self.spark.createDataFrame([
            (1, 1, 1, 0),

        ], ['CPZ', 'NUM_INSURED_CHILDREN', 'NUM_INSURED_SMALL_CHILDREN', 'NUM_INSURED_TEEN_CHILDREN'])
        print("### Source:")
        src_df_pz_detail_cp_osoby_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_cp_osoby4(self):
        src_df_pz_detail_cp_osoby_dat = self.spark.createDataFrame([
            ("CPZ1", "Poistený", "2000-01-01", "123456/1234"),
            ("CPZ2", "Iný", "1990-01-01", "654321/4321"),
            ("CPZ3", "Poistený", "1950-01-01", "987654/5678"),
            ("CPZ4", "Poistený", "1940-01-01", "456789/8765"),
            ("CPZ5", "Iný", "1980-01-01", "789012/2109"),
        ], ["CPZ", "osobavztah", "process_dt", "kod_RC"])
        expected_df = self.spark.createDataFrame([
           ("CPZ4", 1),
        ], ["CPZ", "NUM_INSURED_SENIOR"])
        result = prepare_cp_osoby4(src_df_pz_detail_cp_osoby_dat, self.spark)
        print("### Source:")
        src_df_pz_detail_cp_osoby_dat.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_prev_val_q(self):
        src_df_attr_insurance = self.spark.createDataFrame([
            (202211, 1, 100),
            (202210, 2, 200),
            (202210, 3, 300)
        ], ["month_id", "customerid", "SUM_PAYMENT_YEAR_INS"])
        result = prepare_prev_val_q(src_df_attr_insurance, self.spark)
        expected_df = self.spark.createDataFrame([
            (2, 200),
            (3, 300)
        ], ["customerid", "SUM_PAYMENT_YEAR_INS"])
        print("### Source:")
        src_df_attr_insurance.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_tmp_insurance_cont2(self):
        df_contract = self.spark.createDataFrame([
            (1, 'ABC123', 1, 'INSURANCE', 790, 1, date(2022, 12, 20), date(2023, 1, 1),
             date(2023, 6, 6), date(2023, 6, 6))],
            ['CUSTOMERID', 'CONT_ACCT', 'ACTIVE', 'PROD_SRC_VAL', 'SRC_SYST_CD', 'cont_id',
             'DT_NEGOTIATED_INS', 'DT_START_INS', 'DT_END_INS', 'DT_CANCELED_INS'])
        src_df_product_level_category = self.spark.createDataFrame(
            [('INSURANCE', 3200, 'INSURANCE', 'category', 3110, 3213)],
            ['src_syst_dsc', 'lvl2_category', 'PROD_SRC_VAL', 'PROD_DSC', 'LVL3_CATEGORY', 'LVL4_CATEGORY'])
        df_cp_info = self.spark.createDataFrame(
            [('ABC123', 'Európa', 'turisticke', 100, 'EXC. Family')],
            ['CPZ', 'INS_TERRITORY', 'RISK_TYPE', 'LUGGAGE_INS_AMT', 'VARIANT'])
        df_cp_osoby2 = self.spark.createDataFrame(
            [('ABC123', 2)],
            ['CPZ', 'NUM_INSURED'])
        df_cp_osoby3 = self.spark.createDataFrame(
            [('ABC123', 1, 1, 1)],
            ['CPZ', 'NUM_INSURED_CHILDREN', 'NUM_INSURED_SMALL_CHILDREN', 'NUM_INSURED_TEEN_CHILDREN'])
        df_cp_osoby4 = self.spark.createDataFrame(
            [('ABC123', 1)],
            ['CPZ', 'NUM_INSURED_SENIOR'])
        df_domos = self.spark.createDataFrame(
            [('ABC123', 0, '123', 10, 20)],
            ['CPZ', 'HOUSE_INS_TYPE', 'REGION_INS_REALITY', 'FLG_LIABILITY', 'FLG_POOL'])
        df_gen = self.spark.createDataFrame(
            [('ABC123', 0, '123')],
            ['id', 'code_municipality', 'zip'])
        df_admin = self.spark.createDataFrame(
            [('ABC123', 0, 'Západné Slovensko')],
            ['id', 'kod_obce', 'NAZOV_OBLASTI'])
        df_domos_plocha = self.spark.createDataFrame(
            [('ABC123', 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200)],
            ['CPZ', 'pivnica_plocha', 'garaz_plocha', 'domacnost_podkrovie_m2', 'domacnost_byt_m2', 'povala_plocha',
             'vedl_budova_plocha', 'domacnost_garaz_m2', 'prizemie_plocha', 'domacnost_vedl_budova_m2',
             'domacnost_prizemie_m2', 'domacnost_pivnica_m2', 'podkrovie_plocha', 'podlazie_plocha',
             'domacnost_povala_m2', 'byt_plocha', 'domacnost_podlazie_m2', 'dom_obyvana_m2', 'dom_neobyvana_m2'])
        df_domos_ps = self.spark.createDataFrame(
            [('ABC123', 'Západné Slovensko', 'Stredné Slovensko', 'Východné Slovensko', 'Bratislavský kraj')],
            ['CPZ', 'NAZOV_OBLASTI', 'NAZOV_OBLASTI', 'NAZOV_OBLASTI', 'NAZOV_OBLASTI'])
        df_finukaz = self.spark.createDataFrame(
            [(1, 100, 10, 10)],
            ['cont_id', 'INSURANCE_PREMIUM', 'PAYMENT_VALUE', 'CAPITAL_VALUE'])
        df_upom = self.spark.createDataFrame(
            [('ABC123', '123456', 100)],
            ['kod_cislo_zmluvy', 'typ_upom', 'DLZNE_POISTNE'])
        df_pu = self.spark.createDataFrame(
            [('ABC123', '2022-01-01', '2022-01-01', '2022-01-01', 100, 'Nelikvidny          ', 'Živel - stavba')],
            ['C_POJ_SML', 'DAT_HLASENIA_PU', 'D_VZNIKU_PU', 'D_REVIDACIE', 'PLNENIE', 'likvidny', 'typ_pu_popis'])
        result = prepare_tmp_insurance_cont2(df_contract, src_df_product_level_category,
                                             df_cp_info, df_cp_osoby2, df_cp_osoby3, df_cp_osoby4,
                                             df_domos, df_domos_plocha, df_domos_ps, df_finukaz,
                                             df_upom, df_pu, df_admin, df_gen, self.spark)
        expected_df = self.spark.createDataFrame(test_data.data_tmp_insurance_cont,
                                                 test_data.columns_tmp_insurance_cont)

        print("### Source:")
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_key_employee(self):
        df_stg_insurance_cont = self.spark.createDataFrame([
            (1, 'CPZ1', 1, '2023-01-01', None, '2023-12-31'),
            (2, 'CPZ2', 1, '2023-01-01', None, '2023-12-31'),
            (3, 'CPZ3', 0, '2023-01-01', '2023-12-31', '2023-12-31'),
        ], ['CONT_ID', 'CONT_ACCT', 'ACTIVE', 'DT_START_INS', 'DT_CANCELED_INS', 'DT_END_INS'])
        df_tmp_life_assured_c = self.spark.createDataFrame([
            (1, 'customer1', 'CPZ1'),
            (2, 'customer2', 'CPZ2'),
            (3, 'customer3', 'CPZ3'),
        ], ['customerid', 'name', 'CPZ'])

        result = prepare_key_employee(df_stg_insurance_cont, df_tmp_life_assured_c, self.spark)
        expected_df = self.spark.createDataFrame([
            (1, 1),
            (2, 1),
            ], ['customerid', 'I_KEY_EMPLOYEE_INS'])
        print("### Source:")
        df_stg_insurance_cont.show()
        df_tmp_life_assured_c.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)

    def test_prepare_by_customer(self):
        src_df_attr_client_base_df = self.spark.createDataFrame([
            (1, 202301),
            (2, 202301),
            (3, 202301),
        ], ['customerid', 'month_id'])

        df_tmp_insurance_cont_df = self.spark.createDataFrame(test_data.data_tmp_insurance_cont,
                                                              test_data.columns_tmp_insurance_cont)
        result = prepare_by_customer(src_df_attr_client_base_df,
                                     df_tmp_insurance_cont_df, self.spark)
        print("### Source:")
        src_df_attr_client_base_df.show()
        df_tmp_insurance_cont_df.show()
        print("### Target:")
        result.show()
        self.assertEqual(result.count(), 3)

    def test_prepare_prev_vals(self):
        src_df_attr_insurance = self.spark.createDataFrame([
            (202212, 1, 'Y'),
            (202302, 2, 'N'),
            (202212, 3, 'Y')
        ], ['month_id', 'customerid', 'C_ACTIVE_INS'])
        result = prepare_prev_vals(src_df_attr_insurance, self.spark)
        expected_df = self.spark.createDataFrame([
            (1, 'Y'),
            (3, 'Y')
        ], ['customerid', 'C_ACTIVE_INS'])
        print("### Source:")
        src_df_attr_insurance.show()
        print("### Expected:")
        expected_df.show()
        print("### Target:")
        result.show()
        self.assertDatasetEqual(self.convert_to_long(result),
                                self.convert_to_long(expected_df),
                                order_of_rows_matter=False, order_of_columns_matter=False)


# print("### Source:")
        # print("### Expected:")
        # expected_df.show()
        # print("### Target:")
        # result.show()
        # self.assertDatasetEqual(self.convert_to_long(result),
#                                 self.convert_to_long(expected_df),
#                                 order_of_rows_matter=False, order_of_columns_matter=False)
