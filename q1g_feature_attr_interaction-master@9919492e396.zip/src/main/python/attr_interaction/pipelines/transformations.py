def transform(sources_df, modelling_date, spark):
    """
    transform
    :param sources_df\
    :param modelling_date\
    :param spark\
    :return df_attr_interaction_new
    """
    ccdb__oh__w_event = sources_df['master']['ccdb__oh__w_event']
    ccdb__oh__w_event_tick = sources_df['master']['ccdb__oh__w_event_tick']
    ccdb__oh__w_party = sources_df['master']['ccdb__oh__w_party']
    ccdb__oh__w_person_fact = sources_df['master']['ccdb__oh__w_person_fact']
    ccdb__oh__w_property_value = sources_df['master']['ccdb__oh__w_property_value']
    ccdb__oh__w_real_estate_fact = sources_df['master']['ccdb__oh__w_real_estate_fact']
    ccdb__oh__w_vehicle_fact = sources_df['master']['ccdb__oh__w_vehicle_fact']
    dmsk__l0_owner__party = sources_df['master']['dmsk__l0_owner__party']
    dmsk__l0_owner__party_indiv_nm = sources_df['master']['dmsk__l0_owner__party_indiv_nm']
    dmsk__l0_owner__party_rltd = sources_df['master']['dmsk__l0_owner__party_rltd']
    dmsk__l0_owner__party_role_stat = sources_df['master']['dmsk__l0_owner__party_role_stat']
    dmsk__l0_owner__party_seg = sources_df['master']['dmsk__l0_owner__party_seg']
    dmsk__l0_owner__seg_gen = sources_df['master']['dmsk__l0_owner__seg_gen']
    feature__attr_client_base = sources_df['feature']['attr_client_base']
    dmsk__pm_owner__stg_extra_info = sources_df['feature']['dmsk__pm_owner__stg_extra_info']
    dmsk__pm_owner__stg_product_interest_afp = sources_df['feature']['dmsk__pm_owner__stg_product_interest_afp']

    df_attr_interaction_new = attr_interaction(
        key,
        key2,
        spark
    )
    return df_attr_interaction_new

def attr_interaction(
    key,
    key2,
    spark
):
    """
    attr_interaction
    :param key,
    :param key2,
    :param spark\
    :return df_attr_interaction
    """
    df_key.createOrReplaceTempView("KEY")
    df_key2.createOrReplaceTempView("KEY2")

    df_attr_interaction = spark.sql("""
step(p_stepname => l_proc_name || ' DELETE FROM CALL_CENTRUM_LOG', p_source => 'PM_OWNER.*', p_target => 'CALL_CENTRUM_LOG');   
        DELETE FROM PM_OWNER.CALL_CENTRUM_LOG
        WHERE 1=1
            AND event_dt < process_dt + 1
            AND event_dt >= ADD_MONTHS(process_dt + 1, -1);
        COMMIT;
    
        DELETE FROM PM_OWNER.CALL_CENTRUM_HISTORY
        WHERE 1=1
            AND event_dt < process_dt + 1
            AND event_dt >= ADD_MONTHS(process_dt + 1, -1);
        COMMIT;
    
        DELETE FROM PM_OWNER.FEEDBACK_EVALUATION
        WHERE 1=1
            AND event_dt < process_dt + 1
            AND event_dt >= ADD_MONTHS(process_dt + 1, -1);
        COMMIT;

        step(p_stepname => l_proc_name || ' INSERT CALL_CENTRUM_LOG', p_source => 'N/A', p_target => 'CALL_CENTRUM_LOG');         
        INSERT INTO PM_OWNER.CALL_CENTRUM_LOG
    
            WITH CC_LOG AS (
                SELECT DISTINCT
                    a.MEDIA_TYPE,
                    a.start_timestamp AS event_dt,
                    a.interaction_type,
                    COALESCE( -- If total_duration > 31 days or NULL, fill column with respective median
                        DECODE(SIGN(2678400 - a.total_duration),
                            1, a.total_duration),
                        DECODE(a.media_type,
                            'Voice', 140,
                            'Email', 7500),
                    0) as total_duration,
                    CASE
                        WHEN SUBSTR(a.FROMM, -9, 1) = '9' AND SUBSTR(a.FROMM, 1, GREATEST(1, (length(a.FROMM)-9))) in ('0', '00', '000', '0000', '00000') THEN '+421' || SUBSTR(a.FROMM, -9, 9) --mobil SK
                        WHEN SUBSTR(a.FROMM, -9, 1) in ('2', '3', '4', '5') AND SUBSTR(a.FROMM, 1, GREATEST(1, (length(a.FROMM)-9))) in ('0', '00', '000', '0000', '00000') THEN '+421' || SUBSTR(a.FROMM, -9, 9) --pevna linka SK
                        --                       
                        WHEN SUBSTR(a.FROMM, 1, 4) = '+420' AND LENGTH(SUBSTR(a.FROMM, 5)) = 9 THEN a.FROMM -- mobil CZ
                        WHEN SUBSTR(a.FROMM, 1, 5) = '00420' AND LENGTH(SUBSTR(a.FROMM, 6)) = 9 THEN '+420' || SUBSTR(a.FROMM, -9, 9) --mobil CZ
                        WHEN LENGTH(a.FROMM) in (14, 15) AND c.DIALLING_CODE is not null AND SUBSTR(a.FROMM,1,3)='000'  THEN '+' || SUBSTR(FROMM,4,14)
                        WHEN LENGTH(a.FROMM)=14 AND c.DIALLING_CODE is not null AND SUBSTR(a.FROMM,1,2)='00'   THEN '+' || SUBSTR(FROMM,3,14)
                        WHEN LENGTH(a.FROMM)=16 AND c.DIALLING_CODE is not null AND SUBSTR(a.FROMM,1,3)='000' AND SUBSTR(a.FROMM,4,1)!='0' THEN '+' || SUBSTR(FROMM,4,14)
                        WHEN LENGTH(a.FROMM)=16 AND c.DIALLING_CODE is not null AND SUBSTR(a.FROMM,1,4)='0000' THEN '+' || SUBSTR(FROMM,5,12) 
                        WHEN LENGTH(a.FROMM)=4 THEN a.FROMM
                        WHEN a.FROMM like '%@%' THEN a.FROMM
                        ELSE NULL
                    END FROMM_FINAL,
                    CASE           
                        WHEN SUBSTR(a.TOO, -9, 1) = '9' AND SUBSTR(a.TOO, 1, GREATEST(1, (length(a.TOO)-9))) in ('0', '00', '000', '0000', '00000') THEN '+421' || SUBSTR(a.TOO, -9, 9) --mobil SK
                        WHEN SUBSTR(a.TOO, -9, 1) in ('2', '3', '4', '5') AND SUBSTR(a.TOO, 1, GREATEST(1, (length(a.TOO)-9))) in ('0', '00', '000', '0000', '00000') THEN '+421' || SUBSTR(a.TOO, -9, 9) --pevna linka SK
                        --
                        WHEN SUBSTR(a.TOO, 1, 4) = '+420' AND LENGTH(SUBSTR(a.TOO, 5)) = 9 THEN a.TOO -- mobil CZ
                        WHEN SUBSTR(a.TOO, 1, 5) = '00420' AND LENGTH(SUBSTR(a.TOO, 6)) = 9 THEN '+420' || SUBSTR(a.TOO, -9, 9) --mobil CZ
                        WHEN LENGTH(a.TOO) in (14, 15) AND e.DIALLING_CODE is not null AND SUBSTR(a.TOO,1,3)='000'  THEN '+' || SUBSTR(TOO,4,14)
                        WHEN LENGTH(a.TOO)=14 AND e.DIALLING_CODE is not null AND SUBSTR(a.TOO,1,2)='00'   THEN '+' || SUBSTR(TOO,3,14)
                        WHEN LENGTH(a.TOO)=16 AND e.DIALLING_CODE is not null AND SUBSTR(a.TOO,1,3)='000' AND SUBSTR(a.TOO,4,1)!='0' THEN '+' || SUBSTR(TOO,4,14)
                        WHEN LENGTH(a.TOO)=16 AND e.DIALLING_CODE is not null AND SUBSTR(a.TOO,1,4)='0000' THEN '+' || SUBSTR(TOO,5,12)
                        WHEN LENGTH(a.TOO)=4 THEN a.TOO
                        WHEN a.TOO like '%@%' THEN a.TOO
                        ELSE NULL
                    END as TOO_FINAL,
                    technical_result
                FROM L0_OWNER.CALL_CENTRUM_LOG a
                --INBOUND
                --medzinarodne predvolby
                LEFT JOIN UNICA_OWNER.UNICA_LIST_INT_DIAL_CODES c
                ON SUBSTR(CASE
                    WHEN SUBSTR(a.FROMM,1,3)='000'  AND LENGTH(a.FROMM) in (14, 15) THEN SUBSTR(a.FROMM,4,14)
                    WHEN SUBSTR(a.FROMM,1,2)='00'   AND LENGTH(a.FROMM) in (14) THEN SUBSTR(a.FROMM,3,14)
                    WHEN SUBSTR(a.FROMM,1,3)='000' AND SUBSTR(a.FROMM,4,1)!='0' AND LENGTH(a.FROMM) in (16) THEN SUBSTR(a.FROMM,4,14)
                    WHEN SUBSTR(a.FROMM,1,4)='0000' AND LENGTH(a.FROMM) in (16) THEN SUBSTR(a.FROMM,5,12)
                    ELSE NULL END
                    , 1, LENGTH(c.DIALLING_CODE)
                ) = c.DIALLING_CODE
                
                --OUTBOUND
                --medzinarodne predvolby      
                LEFT JOIN UNICA_OWNER.UNICA_LIST_INT_DIAL_CODES e
                ON SUBSTR(CASE
                    WHEN SUBSTR(a.TOO,1,3)='000'  AND LENGTH(a.TOO) in (14, 15) THEN SUBSTR(a.TOO,4,14)
                    WHEN SUBSTR(a.TOO,1,2)='00'   AND LENGTH(a.TOO) in (14) THEN SUBSTR(a.TOO,3,14)
                    WHEN SUBSTR(a.TOO,1,3)='000'  AND SUBSTR(a.TOO,4,1)!='0' AND LENGTH(a.TOO) in (16) THEN SUBSTR(a.TOO,4,14)
                    WHEN SUBSTR(a.TOO,1,4)='0000' AND LENGTH(a.TOO) in (16) THEN SUBSTR(a.TOO,5,12)                  
                    ELSE NULL END
                    , 1, LENGTH(e.DIALLING_CODE)
                ) = e.DIALLING_CODE
                WHERE (
                    CASE
                        WHEN TRIM(COALESCE(a.FROMM,'Unknown')) not in ('Unknown','00') THEN 1
                        ELSE 0
                        END +
                    CASE WHEN TRIM(COALESCE(a.TOO,'Unknown')) not in ('Unknown','00') THEN 1
                    ELSE 0
                    END
                ) > 0
                AND a.start_timestamp < process_dt + 1
                AND a.start_timestamp >= ADD_MONTHS(process_dt + 1, -1)
            )
            
            SELECT
                MEDIA_TYPE,
                EVENT_DT,
                INTERACTION_TYPE,
                TOTAL_DURATION,
                DECODE(MEDIA_TYPE || INTERACTION_TYPE,
                    'EmailInbound', FROMM_FINAL,
                    'EmailOutbound', NULL,
                FROMM_FINAL) AS FROMM_FINAL,
                DECODE(MEDIA_TYPE || INTERACTION_TYPE,
                    'EmailInbound', NULL,
                    'EmailOutbound', FROMM_FINAL,
                TOO_FINAL) AS TOO_FINAL,
                TECHNICAL_RESULT
            FROM CC_LOG
        ;
    
        stat_ins(p_count => SQL%ROWCOUNT);
        commit;

        step(p_stepname => l_proc_name || ' INSERT CUSTOMER_CONTACT', p_source => 'N/A', p_target => 'CUSTOMER_CONTACT');     
        INSERT INTO PM_OWNER.CUSTOMER_CONTACT
    
            SELECT 
                cc.customerid,
                LOWER(cc.contact_value) as contact_value,
                cc.contact_type, -- In very specific cases, contact_type not properly set
                DECODE(count(distinct cc.source_system),
                    1, max(cc.source_system),
                    2, 'CRM|SCUBE', count(distinct cc.source_system)) AS source_system,
                sysdate as insert_dt,
                NULL as contact_start_dt, -- contacts' validity often starts and ends, therefore currently not included
                NULL as contact_end_dt -- contacts' validity often starts and ends, therefore currently not included
            FROM (
                select 
                    cont.customerid,
                    cont.source_system,
                    CASE
                        WHEN contact_type in ('email', 'e-mail') OR contact_value like '%@%' THEN 'Email'
                        WHEN contact_type in ('phone_number', 'mobil', 'telefon', 'fax', 'SMS') THEN 'Voice'
                        ELSE contact_type END as contact_type,
                    CASE
                        WHEN SUBSTR(cont.contact_value, -9, 1) = '9' AND SUBSTR(cont.contact_value, 1, GREATEST(1, (length(cont.contact_value)-9))) in ('0', '00', '000', '0000', '00000') THEN '+421' || SUBSTR(cont.contact_value, -9, 9) --mobil SK
                        WHEN SUBSTR(cont.contact_value, -9, 1) in ('2', '3', '4', '5') AND SUBSTR(cont.contact_value, 1, GREATEST(1, (length(cont.contact_value)-9))) in ('0', '00', '000', '0000', '00000') THEN '+421' || SUBSTR(cont.contact_value, -9, 9) --pevna linka SK
                        WHEN SUBSTR(cont.contact_value, 1, 4) = '+420' AND LENGTH(SUBSTR(cont.contact_value, 5)) = 9 THEN cont.contact_value -- mobil CZ
                        WHEN SUBSTR(cont.contact_value, 1, 5) = '00420' AND LENGTH(SUBSTR(cont.contact_value, 6)) = 9 THEN '+420' || SUBSTR(cont.contact_value, -9, 9) --mobil CZ
                        WHEN LENGTH(cont.contact_value) in (14, 15) AND c.DIALLING_CODE is not null AND SUBSTR(cont.contact_value,1,3)='000'  THEN '+' || SUBSTR(cont.contact_value,4,14)
                        WHEN LENGTH(cont.contact_value)=14 AND c.DIALLING_CODE is not null AND SUBSTR(cont.contact_value,1,2)='00'   THEN '+' || SUBSTR(cont.contact_value,3,14)
                        WHEN LENGTH(cont.contact_value)=16 AND c.DIALLING_CODE is not null AND SUBSTR(cont.contact_value,1,3)='000' AND SUBSTR(cont.contact_value,4,1)!='0' THEN '+' || SUBSTR(cont.contact_value,4,14)
                        WHEN LENGTH(cont.contact_value)=16 AND c.DIALLING_CODE is not null AND SUBSTR(cont.contact_value,1,4)='0000' THEN '+' || SUBSTR(cont.contact_value,5,12) 
                        WHEN LENGTH(cont.contact_value)=4 THEN cont.contact_value
                        WHEN cont.contact_value like '%@%' THEN cont.contact_value
                        ELSE contact_value
                    END AS contact_value,
                    
                    contact_start_dt,
                    contact_end_dt
                
                FROM (
                    select
                        PR.party_id as customerid,
                        'SCUBE' source_system,
                        case when contct.CONTCT_TYPE_CD IN (14) then 'website'
                             else ctg.contct_type_gen_ds end contact_type,
                        case
                            when substr(PARTY_CONTCT_VAL, 1, 2) in ('00') and length(PARTY_CONTCT_VAL) = 14 AND contct.CONTCT_TYPE_CD IN (10, 11)
                                then '+' || SUBSTR(PARTY_CONTCT_VAL, 3, 12)
                            when substr(PARTY_CONTCT_VAL, 1, length(PARTY_CONTCT_VAL)-9) in ('421', '0421', '420', '0420') AND length(PARTY_CONTCT_VAL) in (12, 13) AND contct.CONTCT_TYPE_CD IN (10, 11)
                                THEN '+' || substr(PARTY_CONTCT_VAL, -12, 12) 
                            when substr(PARTY_CONTCT_VAL, -9, 1) in ('2', '3', '4', '5', '9') AND length(PARTY_CONTCT_VAL) = 9 AND contct.CONTCT_TYPE_CD IN (10, 11)
                                THEN '+421' || PARTY_CONTCT_VAL
                            when substr(PARTY_CONTCT_VAL, -9, 1) in ('2', '3', '4', '5', '9') AND SUBSTR(PARTY_CONTCT_VAL, 1, GREATEST(0, (length(PARTY_CONTCT_VAL)-9))) in ('0', '00') AND contct.CONTCT_TYPE_CD IN (10, 11)
                                THEN '+421' || SUBSTR(PARTY_CONTCT_VAL, -9, 9)
                            else lower(PARTY_CONTCT_VAL) end contact_value,
                        PARTY_CONTCT_START_DT as contact_start_dt,
                        PARTY_CONTCT_END_DT as contact_end_dt
                    from (
                        SELECT
                            PARTY_ID,
                            CONTCT_TYPE_CD,
                            CONTCT_PLACE_CD,
                            PARTY_CONTCT_VAL_ID,
                            PARTY_CONTCT_START_DT,
                            PARTY_CONTCT_END_DT,
                            CASE 
                                WHEN REGEXP_LIKE(party_contct_val, '^[+ /0-9\-]+$') AND CONTCT_TYPE_CD IN (10, 11)
                                THEN TRANSLATE(party_contct_val, 'x- /', 'x')
                                ELSE party_contct_val END PARTY_CONTCT_VAL,
                            PARTY_CONTCT_PREF_IN,
                                PARTY_CONTCT_PROD_ID,
                                ETL_SRC_SYST_CD,
                                PAID_INS,
                                PAID_UPD,
                                PARTY_CONTCT_NOTE,
                                PARTY_CONTCT_BRAND_PARTY_ID,
                                ROW_SOURCE_CD
                            FROM L0_OWNER.PARTY_CONTCT
                            WHERE 1=1
                                AND PARTY_CONTCT_START_DT < process_dt + 1
                                AND PARTY_CONTCT_START_DT >= (CASE WHEN process_dt + 1 > initial_load_dt THEN ADD_MONTHS(process_dt + 1, -1) ELSE min_contct_start END)
                                AND PARTY_CONTCT_END_DT >= LEAST(initial_load_dt, PARTY_CONTCT_START_DT)
                            ) contct
                      
                    JOIN L0_OWNER.PARTY_RLTD PR
                        ON  PR.child_party_id = contct.party_id
                        AND PR.party_rltd_rsn_cd = 4
                        AND pr.party_id IS NOT NULL
                        AND PR.party_rltd_start_dt < process_dt + 1
                        AND PR.party_rltd_start_dt >= (CASE WHEN process_dt + 1 > initial_load_dt THEN ADD_MONTHS(process_dt + 1, -1) ELSE min_contct_start END)
                        AND PR.party_rltd_end_dt >= LEAST(initial_load_dt, PR.party_rltd_start_dt)
                        
                    LEFT JOIN l0_owner.contct_type_gen ctg
                        ON ctg.contct_type_cd = contct.CONTCT_TYPE_CD
                        AND contct_type_gen_start_dt < process_dt + 1
                        AND contct_type_gen_start_dt >= (CASE WHEN process_dt + 1 > initial_load_dt THEN ADD_MONTHS(process_dt + 1, -1) ELSE min_contct_start END)
                        AND contct_type_gen_end_dt >= LEAST(initial_load_dt, contct_type_gen_start_dt)
                    
                    union all
                    
                    SELECT 
                        customerid,
                        source_system,
                        contact_type,
                        contact_value,
                        contact_start_dt,
                        contact_end_dt
                    FROM (
                        select
                            CCDB.customerid,
                            'CRM' source_system,
                            t_phone_number,
                            t_email,
                            t_website,
                            PARTY_CONTACT_START_DT as CONTACT_START_DT,
                            PARTY_CONTACT_end_DT as CONTACT_end_DT
                        from CCDB_OWNER.DH_S_CCD_PARTY_CONTACT CNT --MIN START_DT 21.10.2021
                        
                        --doplnenie CUID/CUSTOMERID
                        LEFT JOIN (
                            SELECT 
                                CCDB_ID,
                                CUSTOMERID 
                            FROM (
                                SELECT
                                    pp.cd_rec_party_1 as CCDB_ID,
                                    TO_NUMBER(CASE WHEN pp.cd_rec_party_2_source='1' THEN P.party_id  ELSE NULL END) as CUSTOMERID, --1 - CDS
                                    ROW_NUMBER() OVER (PARTITION BY TO_NUMBER(CASE WHEN pp.cd_rec_party_2_source='1' THEN P.party_id  ELSE NULL END) ORDER BY dt_bus_eff_from desc, pp.cd_rec_party_1) row_num
                                FROM CCDB_OWNER.oh_w_party_party PP
                                
                                LEFT JOIN L0_OWNER.PARTY P
                                    ON P.party_src_key=pp.cd_rec_party_2
                                    AND pp.cd_rec_party_2_source='1'
                                    AND P.SRC_SYST_CD=1
                                
                                where 1=1
                                    and trim(TRANSLATE(PP.cd_rec_party_1, '0123456789-,.', ' ')) is null
                                    and PP.PARTY_PARTY_START_DT < process_dt + 1
                                    and PP.PARTY_PARTY_START_DT >= (CASE WHEN process_dt + 1 > initial_load_dt THEN ADD_MONTHS(process_dt + 1, -1) ELSE min_contct_start END)
                                    and PP.PARTY_PARTY_END_DT >= LEAST(initial_load_dt, PP.PARTY_PARTY_START_DT)
                                    and PP.cd_rec_relation_type = 'PARTY_INSTANCE'
                                    and pp.cd_rec_relation_type_source = 'CCDB'
                                    and pp.cd_rec_source = 'CCDB'
                                    and pp.cd_rec_party_1_source = 'CCDB.CRM'
                                    and TO_NUMBER(CASE WHEN pp.cd_rec_party_2_source='1' THEN P.party_id  ELSE NULL END) is not null
                            ) WHERE row_num = 1
                        ) ccdb ON ccdb.CCDB_ID=CNT.CD_REC_PARTY
                            
                        WHERE 1=1
                        AND  ccdb.customerid IS NOT NULL
                        AND cnt.party_contact_start_dt < process_dt + 1
                        AND cnt.party_contact_start_dt >= (CASE WHEN process_dt + 1 > initial_load_dt THEN ADD_MONTHS(process_dt + 1, -1) ELSE min_contct_start END)
                        AND cnt.party_contact_end_dt >= LEAST(initial_load_dt, cnt.party_contact_start_dt)
                    )
                    UNPIVOT (
                        contact_value  -- unpivot_clause
                        FOR contact_type --  unpivot_for_clause
                        IN ( -- unpivot_in_clause
                            t_phone_number AS 'phone_number', 
                            t_email AS 'email', 
                            t_website AS 'website'
                        )
                    )
                ) cont
                --medzinarodne predvolby
                LEFT JOIN UNICA_OWNER.UNICA_LIST_INT_DIAL_CODES c
                    ON SUBSTR(
                        CASE
                            WHEN SUBSTR(cont.contact_value,1,3)='000'  AND LENGTH(cont.contact_value) in (14, 15) THEN SUBSTR(cont.contact_value,4,14)
                            WHEN SUBSTR(cont.contact_value,1,2)='00'   AND LENGTH(cont.contact_value) in (14) THEN SUBSTR(cont.contact_value,3,14)
                            WHEN SUBSTR(cont.contact_value,1,3)='000' AND SUBSTR(cont.contact_value,4,1)!='0' AND LENGTH(cont.contact_value) in (16) THEN SUBSTR(cont.contact_value,4,14)
                            WHEN SUBSTR(cont.contact_value,1,4)='0000' AND LENGTH(cont.contact_value) in (16) THEN SUBSTR(cont.contact_value,5,12)
                            ELSE NULL
                        END, 1, LENGTH(c.DIALLING_CODE)
                    ) = c.DIALLING_CODE
                
                WHERE contact_type NOT IN ('swift', 'Kontaktní osoba')
            ) cc
            LEFT JOIN PM_OWNER.CUSTOMER_CONTACT cc0
                ON cc.customerid = cc0.customerid
                AND cc.contact_value = cc0.contact_value
            WHERE cc0.customerid IS NULL
            
            GROUP BY cc.customerid, cc.contact_value, cc.contact_type
        ;	
    
        stat_ins(p_count => SQL%ROWCOUNT);
        commit;

        step(p_stepname => l_proc_name || ' INSERT CALL_CENTRUM_HISTORY', p_source => 'N/A', p_target => 'CALL_CENTRUM_HISTORY');     
        INSERT INTO PM_OWNER.CALL_CENTRUM_HISTORY
            SELECT * FROM (
                SELECT 
                    f.customerid,
                    f.contact_value,
                    media_type,
                    event_dt,
                    interaction_type,
                    total_duration,
                    technical_result, 
                    phone_description as csob_phone_number_description
                FROM (
                    SELECT
                        customerid,
                        contact_value
            --            ,contact_type -- Very rarely wrong contact_type, in general not necessary for JOINing data
                    FROM PM_OWNER.CUSTOMER_CONTACT
                ) f
                JOIN (
                    SELECT DISTINCT
                        EVENT_DT,
                        FROMM_FINAL,
                        INTERACTION_TYPE,
                        MEDIA_TYPE,
                        TECHNICAL_RESULT,
                        TOO_FINAL,
                        TOTAL_DURATION,
                        csob.phone_description
                    FROM PM_OWNER.CALL_CENTRUM_LOG cca 
                    LEFT JOIN je69050.csob_phone_number csob
                        ON cca.too_final = csob.phone_number
                        AND cca.interaction_type = 'Inbound'
                    WHERE VALIDATE_CONVERSION(cca.too_final AS NUMBER) = 1
                        AND cca.event_dt < process_dt + 1
                        AND cca.event_dt >= ADD_MONTHS(process_dt + 1, -1)
                ) cc ON (
                    f.contact_value = LOWER(DECODE( cc.interaction_type,
                        'Inbound', cc.fromm_final,
                        'Outbound', cc.too_final
                    ))
                )
            )
            PIVOT (
                COUNT(technical_result)
                FOR technical_result IN (
                    'Completed' AS I_RESULT_COMPLETED,
                    'Redirected' AS I_RESULT_REDIRECTED,
                    'Conferenced' AS I_RESULT_CONFERENCED,
                    'Diverted' AS I_RESULT_DIVERTED,
                    'Abandoned' AS I_RESULT_ABANDONED,
                    'Transferred' AS I_RESULT_TRANSFERRED,
                    'DestinationBusy' AS I_RESULT_DESTINATIONBUSY,
                    'None' AS I_RESULT_NONE,
                    'CustomerAbandoned' AS I_RESULT_CUSTOMERABANDONED,
                    'AbnormalStop' AS I_RESULT_ABNORMALSTOP
                )
            )
        ;
        
        stat_ins(p_count => SQL%ROWCOUNT);
        commit;       

        step(p_stepname => l_proc_name || ' INSERT FEEDBACK_EVALUATION', p_source => 'N/A', p_target => 'FEEDBACK_EVALUATION');      
        INSERT INTO PM_OWNER.FEEDBACK_EVALUATION
    
            SELECT /*+ NO_PARALLEL ORDERED */
                /*  Transformation of incorrect structure of customerid, where we need to parse original customerid e.g.
                    - 123456789
                    
                    from possible values containg dates if format YYMMDD or repeated original value, e.g.
                    - 123456789
                    - 123456789231231
                    - 123456789123456789231231
                    - 123456789231231123456789231231
                */
                TO_NUMBER(CASE 
                    WHEN LENGTH(customerid) > 24 THEN SUBSTR(SUBSTR(customerid, 1, LENGTH(customerid)/2), 1, LENGTH(customerid)/2 - 6)
                    WHEN LENGTH(customerid) > 16 THEN SUBSTR(SUBSTR(customerid, 1, LENGTH(customerid) - 6), 1, LENGTH(SUBSTR(customerid, 1, LENGTH(customerid) - 6))/2)
                    WHEN LENGTH(customerid) > 12 THEN SUBSTR(customerid, 1, LENGTH(customerid) - 6)
                    ELSE customerid END) AS customerid,
                event_dt,
                feedback,
                source_table,
                NULL AS i_service_request
            FROM (
    
                --call centrum
    
                SELECT
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    ROUND(TO_NUMBER(odpoved_6)/MAX(TO_NUMBER(odpoved_6)) OVER () * 10) AS feedback,
                    'C_003189_CLF165_NETQUEST' as source_table
                FROM PM_OWNER.C_003189_CLF165_Netquest
                WHERE odpoved_6 is not null
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                UNION ALL
                 
                --loans
                
                select 
                TO_CHAR(customerid) AS customerid, 
                TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                ROUND((
                    2 * NVL(
                            DECODE(TRIM(odpoved_6),
                                'veľmi spokojný/á', 5,
                                'skôr spokojný/á', 4,
                                'neviem sa vyjadriť', 3,
                                'skôr nespokojný/á', 2,
                                'veľmi nespokojný/á', 1
                            ), 0) + NVL(odpoved_7, 0)
                    ) 
                    / (NVL2(odpoved_6, 1, 0) + NVL2(odpoved_7, 1, 0))
                ) as feedback,
                    'C_001651_CLF167_NETQUEST' as source_table
                from PM_OWNER.C_001651_CLF167_Netquest
                where not (odpoved_6 is null and odpoved_7 is null)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                            
                UNION ALL
                
                --digi products
                select 
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    TO_NUMBER(odporucili_by_ste) as feedback,
                    'C_006270_CLF329_NETQUEST' as source_table
                from PM_OWNER.C_006270_CLF329_Netquest
                where odporucili_by_ste is not null
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                    
                UNION ALL
                 
                --Smart account
                select
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    TO_NUMBER(odpoved_5) as feedback,
                    'C_001367_RET484_NETQUEST' as source_table
                from PM_OWNER.C_001367_RET484_Netquest a
                where odpoved_5 is not null
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                        
                UNION ALL
                
                --Smart account 30d
                 
                select 
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    ROUND(
                        2 * ((NVL(odpoved_1, 0) + NVL(odpoved_2, 0)) 
                        / (NVL2(odpoved_1, 1, 0) + NVL2(odpoved_2, 1, 0)))
                    ) as feedback,
                    'C_001367_RET484l_NETQUEST' as source_table
                from PM_OWNER.C_001367_RET484l_Netquest
                where not (odpoved_1 is null and odpoved_2 is null)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                        
                UNION ALL
                
                -- prieskum po navsteve pobocky
                 
                select 
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    ROUND(
                        (NVL(odpoved_1, 0) + NVL(odpoved_3, 0))
                        / (NVL2(odpoved_1, 1, 0) + NVL2(odpoved_3, 1, 0))
                    ) as feedback,
                    'C_001367_RET142E_NETQUEST' as source_table
                from PM_OWNER.C_001367_RET142E_NETQUEST
                where not (odpoved_1 is null and odpoved_3 is null)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                        
                UNION ALL
                
                -- prieskum vyriesenych staznosti
                 
                select 
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    2 * DECODE(LOWER(TRIM(odpoved_1)),
                                'veľmi spokojný', 5,
                                'skôr spokojný', 4,
                                'neviem sa vyjadriť', 3,
                                'skôr nespokojný', 2,
                                'veľmi nespokojný', 1
                    ) as feedback,
                    'C_006897_CLF336_NETQUEST' as source_table
                from PM_OWNER.C_006897_CLF336_Netquest
                where odpoved_1 is not null
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                        
                UNION ALL
                
                -- prieskum po prvom nakupe fondov
                 
                select 
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    ROUND(
                        (NVL(odpoved_1, 0) + NVL(odpoved_4, 0)) 
                        / (NVL2(odpoved_1, 1, 0) + NVL2(odpoved_4, 1, 0))
                    ) as feedback,
                    'C_003189_CLF73F_NETQUEST' as source_table
                from PM_OWNER.C_003189_CLF73f_Netquest
                where not (odpoved_1 is null and odpoved_4 is null)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                        
                UNION ALL
                
                -- prieskum po likvidacii poistnej udalosti
                 
                select 
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    ROUND((
                        2 * (NVL(
                                DECODE(TRIM(odpoved_1),
                                    'veľmi spokojný', 5,
                                    'skôr spokojný', 4,
                                    'neviem sa vyjadriť', 3,
                                    'skôr nespokojný', 2,
                                    'veľmi nespokojný', 1
                                ), 0) +
                            NVL(
                                DECODE(TRIM(odpoved_2),
                                    'veľmi spokojný', 5,
                                    'skôr spokojný', 4,
                                    'neviem sa vyjadriť', 3,
                                    'skôr nespokojný', 2,
                                    'veľmi nespokojný', 1
                                ), 0) +
                            NVL(
                                DECODE(TRIM(odpoved_3),
                                    'veľmi spokojný', 5,
                                    'skôr spokojný', 4,
                                    'neviem sa vyjadriť', 3,
                                    'skôr nespokojný', 2,
                                    'veľmi nespokojný', 1
                                ), 0) +
                            NVL(
                                DECODE(TRIM(odpoved_4),
                                    'veľmi spokojný', 5,
                                    'skôr spokojný', 4,
                                    'neviem sa vyjadriť', 3,
                                    'skôr nespokojný', 2,
                                    'veľmi nespokojný', 1
                                ), 0)
                            ) + NVL(odpoved_5, 0)
                        ) 
                        / (NVL2(odpoved_1, 1, 0) + NVL2(odpoved_2, 1, 0) + NVL2(odpoved_3, 1, 0) + NVL2(odpoved_4, 1, 0) + NVL2(odpoved_5, 1, 0))
                    ) as feedback,
                    'C_007880_CLF342_NETQUEST' as source_table
                from PM_OWNER.C_007880_CLF342_Netquest
                where not (odpoved_1 is null and odpoved_2 is null and odpoved_3 is null and odpoved_4 is null and odpoved_5 is null)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                        
                UNION ALL
                
                -- Splátka KK v SB
                 
                select 
                    TO_CHAR(customerid) AS customerid,
                    --datum_ukoncenia,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    2 * DECODE(LOWER(TRIM(odpoved_3)),
                            'veľmi spokojný', 5,
                            'skôr spokojný', 4,
                            'neviem sa vyjadriť', 3,
                            'skôr nespokojný', 2,
                            'veľmi nespokojný', 1
                    ) as feedback,
                    'C_008009_CLF344_NETQUEST' as source_table
                from PM_OWNER.c_008009_clf344_netquest
                where odpoved_3 is not null
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                        
                UNION ALL
                
                -- eMessage CLF73
                 
                select 
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    ROUND(
                        (NVL(odpoved_1, 0) + NVL(odpoved_3, 0)) 
                        / (NVL2(odpoved_1, 1, 0) + NVL2(odpoved_3, 1, 0))
                    ) as feedback,
                    'C_003189_CLF73_NETQUEST' as source_table
                from PM_OWNER.C_003189_CLF73_Netquest
                where not (odpoved_1 is null and odpoved_3 is null)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                        
                UNION ALL
                
                -- pravidelné investovanie
                 
                select 
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    ROUND(
                        (NVL(odpoved_2, 0) + NVL(odpoved_4, 0))
                        / (NVL2(odpoved_2, 1, 0) + NVL2(odpoved_4, 1, 0))
                    ) as feedback,
                    'C_008125_CLF345_NETQUEST' as source_table
                from PM_OWNER.c_008125_clf345_netquest
                where not (odpoved_2 is null and odpoved_4 is null)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                
                -- Smart ucet pre klientov bez BU 
                -- (EXCLUDED) UNICA_OWNER.c_008827_clf356_netquest - last record from 2023-05-08, no numeric feedback
                                
                UNION ALL
                
                -- pravidelné investovanie novy dotaznik
                 
                select 
                    TO_CHAR(customerid) AS customerid,
                    TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') as EVENT_DT,
                    ROUND(
                        (NVL(odpoved_2, 0) + NVL(odpoved_3, 0))
                        / (NVL2(odpoved_2, 1, 0) + NVL2(odpoved_3, 1, 0))
                    ) as feedback,
                    'C_008125_CLF345_NETQUEST_20231016' as source_table
                from PM_OWNER.C_008125_CLF345_Netquest_20231016
                where not (odpoved_2 is null and odpoved_3 is null)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_ukoncenia, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
    
                
                UNION ALL
    
                select
                    TO_CHAR(uid_cuidd.party_id) AS customeridd,
                    TO_DATE(datum_navstevy, 'YYYY-MM-DD') as EVENT_DTT,
                    ROUND(
                        (NVL(o1_spokojnost_s_obsluhou, 0) + NVL(o3_odporucenie_pobocka, 0) + 10 * NVL(CASE WHEN celkom BETWEEN 0 AND 1 THEN celkom END, 0))
                        / (NVL2(o1_spokojnost_s_obsluhou, 1, 0) + NVL2(o3_odporucenie_pobocka, 1, 0) + NVL2(CASE WHEN celkom BETWEEN 0 AND 1 THEN celkom END, 1, 0))
                    ) as feedbackk,
                    'EMESSAGE_DETAIL_POBOCKY' as source_tablee
                from JE69050.emessage_detail_pobocky nps
                
                --- adding customerid through cuid based on ETL_UNICA_UID
                JOIN L0_OWNER.PARTY P
                ON P.party_src_val = nps.cuid
                    AND P.src_syst_cd = 110 
                    AND P.party_subtp_cd IN (0,1,2,3)
                    AND P.party_src_key like 'PMC%'
                JOIN L0_OWNER.PARTY_RLTD uid_cuidd
                ON  uid_cuidd.child_party_id = P.party_id
                    AND uid_cuidd.party_rltd_rsn_cd = 4
                    AND uid_cuidd.party_rltd_start_dt <= process_dt
                    AND uid_cuidd.party_rltd_end_dt > process_dt
                
                WHERE not (o1_spokojnost_s_obsluhou is null and o3_odporucenie_pobocka is null)
                    AND TO_DATE(datum_navstevy, 'YYYY-MM-DD HH24:MI:SS') >= ADD_MONTHS(process_dt + 1, -1)
                    AND TO_DATE(datum_navstevy, 'YYYY-MM-DD HH24:MI:SS') < process_dt + 1
                
                GROUP BY uid_cuidd.party_id,
                         datum_navstevy,
                         ROUND(
                            (NVL(o1_spokojnost_s_obsluhou, 0) + NVL(o3_odporucenie_pobocka, 0) + 10 * NVL(CASE WHEN celkom BETWEEN 0 AND 1 THEN celkom END, 0))
                            / (NVL2(o1_spokojnost_s_obsluhou, 1, 0) + NVL2(o3_odporucenie_pobocka, 1, 0) + NVL2(CASE WHEN celkom BETWEEN 0 AND 1 THEN celkom END, 1, 0))
                        )
                
                UNION ALL
    
                -- Branch visits
                SELECT
                    TO_CHAR(customerid) AS customerid,
                    event_dt,
                    ROUND(2 * AVG(FEEDBACK_EVALUTION)) as FEEDBACK,
                    'OH_W_EVENT' as source_table
                FROM (
                    -- crm sessions
                    SELECT /* ORDERED*/
                        CCDB.CUSTOMERID,
                        CAST(E.DT_BUS_EFF_FROM AS DATE) AS EVENT_DT,
                        CASE E.CD_REC_VALUE_PROPERTY_2
                            WHEN '1' THEN 5 -- veľmi spokojný 
                            WHEN '2' THEN 4 
                            WHEN '3' THEN 3 
                            WHEN '4' THEN 2 
                            WHEN '5' THEN 1 -- veľmi nespokojný 
                            ELSE NULL
                        END FEEDBACK_EVALUTION,
                        E.CD_REC_VALUE_PROPERTY_2 as feed_orig
                
                    from CCDB_OWNER.OH_W_EVENT E
                    
                    --dotiahnutie klienta
                    JOIN CCDB_OWNER.OH_W_PARTY P
                        on P.cd_rec_party = E.cd_rec_party_1 
                        and P.cd_rec_source = 'CCDB.CRM'
                        and P.cd_rec_object_type = E.cd_rec_party_1_object_type 
                        and P.party_end_dt = date '9999-12-31'
                        AND P.DELETED_DT   = date '9999-12-31'
                    
                    --doplnenie CUID/CUSTOMERID
                    LEFT JOIN (
                        SELECT CCDB_ID, CUSTOMERID
                                ,PARTY_PARTY_START_DT
                                ,PARTY_PARTY_END_DT 
                            FROM (
                            SELECT
                                pp.cd_rec_party_1 as CCDB_ID,
                                TO_NUMBER(CASE WHEN pp.cd_rec_party_2_source='1' THEN P.party_id  ELSE NULL END) as CUSTOMERID, --1 - CDS
            --                    ROW_NUMBER() OVER (PARTITION BY TO_NUMBER(CASE WHEN pp.cd_rec_party_2_source='1' THEN P.party_id  ELSE NULL END) ORDER BY dt_bus_eff_from desc, pp.cd_rec_party_1) row_num,
                                PP.PARTY_PARTY_START_DT,
                                PP.PARTY_PARTY_END_DT
                            FROM CCDB_OWNER.oh_w_party_party PP
                            
                            LEFT JOIN L0_OWNER.PARTY P
                                ON P.party_src_key=pp.cd_rec_party_2
                                AND pp.cd_rec_party_2_source='1'
                                AND P.SRC_SYST_CD=1
                            
                            where 1=1
                                and trim(TRANSLATE(PP.cd_rec_party_1, '0123456789-,.', ' ')) is null
                                and PP.PARTY_PARTY_END_DT >= ADD_MONTHS(process_dt + 1, -1)
                                and PP.PARTY_PARTY_START_DT < process_dt + 1
                                and PP.cd_rec_relation_type = 'PARTY_INSTANCE'
                                and pp.cd_rec_relation_type_source = 'CCDB'
                                and pp.cd_rec_source = 'CCDB'
                                and pp.cd_rec_party_1_source = 'CCDB.CRM'
                                and TO_NUMBER(CASE WHEN pp.cd_rec_party_2_source='1' THEN P.party_id  ELSE NULL END) is not null)
            --            WHERE row_num = 1
                        ) CCDB
                        ON CCDB.CCDB_ID=P.CD_REC_PARTY
                            and CCDB.PARTY_PARTY_START_DT <= E.DT_BUS_EFF_FROM
                            and CCDB.PARTY_PARTY_END_DT > E.DT_BUS_EFF_FROM  
                    
                    where 1=1
                    AND E.CD_REC_VALUE_PROPERTY_2 <> 'XNA'
                    AND E.CD_REC_VALUE_PROPERTY_2 is not null
                    AND CAST(E.DT_BUS_EFF_FROM AS DATE) >= ADD_MONTHS(process_dt + 1, -1)
                    AND CAST(E.DT_BUS_EFF_FROM AS DATE) < process_dt + 1
                    AND E.event_end_dt = date '9999-12-31'
                    AND E.cd_rec_source = 'CCDB.CRM'
                    AND E.cd_rec_object_type='OBJECT~EVENT~SESSION'
                    and CCDB.CUSTOMERID is not null
                )
                
                GROUP BY TO_CHAR(customerid),
                    event_dt
            )
    
            UNION ALL
                            
            -- sťažnosti
                SELECT 
                    CUSTOMERID as CUSTOMERID,
                    SERVICE_REQUEST_FACT_DT as event_dt,
                    NULL AS feedback,
                    'OH_W_SERVICE_REQUEST_FACT_TICK' AS source_table,
                    1 AS i_service_request
                FROM 
                (
                    SELECT 
            --            row_number() OVER(PARTITION BY T_NAME||'~'||TO_CHAR(CD_REC_PARTY) ORDER BY DT_TEC_UPDATED_MASTER DESC) row_num,
                            CUSTOMERID,
                            SERVICE_REQUEST_FACT_DT,
                            CD_REC_PARTY
                    FROM 
                    (
                        SELECT 
                            SRF.T_NAME,
                                cust.party_id AS CUSTOMERID,
                                SRF.DT_TEC_UPDATED_MASTER, 
                                SRF.SERVICE_REQUEST_FACT_DT,
                                cuid.CD_REC_PARTY
                        FROM CCDB_OWNER.OH_W_SERVICE_REQUEST_FACT_TICK SRF
                        JOIN ccdb_owner.oh_w_event_tick ET
                        ON SRF.cd_rec_event = ET.cd_rec_event
                            AND SRF.cd_rec_event_source = ET.cd_rec_source
                            AND  SRF.cd_rec_event_source  = 'CCDB.CRM'
                            AND SRF.DELETED_DT = TO_DATE('9999-12-31', 'YYYY-MM-DD')
                            AND ET.DELETED_DT  = TO_DATE('9999-12-31', 'YYYY-MM-DD')
                            AND ET.CD_REC_OBJECT_TYPE != 'OBJECT~EVENT~SERVICE~REQUEST_EXECUTION'
                            AND ET.CD_REC_VALUE_PROPERTY_2 NOT IN ('1183', '1182')
                            
                        JOIN ccdb_owner.DH_S_CCD_PARTY cuid
                        ON ET.CD_REC_PARTY_1 = cuid.CD_REC_PARTY
                            AND  cuid.cd_rec_party_source  = 'CCDB.CRM'
                            AND  cuid.DELETED_DT  = TO_DATE('9999-12-31', 'YYYY-MM-DD')
                        
                        --- adding customerid through cuid based on ETL_UNICA_UID
                        JOIN L0_OWNER.PARTY P
                        ON P.party_src_val = cuid.CD_PARTY_LEGACY_CUID
                            AND P.src_syst_cd = 110 
                            AND P.party_subtp_cd IN (0,1,2,3)
                            AND P.party_src_key like 'PMC%'
                        JOIN L0_OWNER.PARTY_RLTD cust
                        ON  cust.child_party_id = P.party_id
                            AND cust.party_rltd_rsn_cd = 4
                            AND cust.party_rltd_start_dt <= process_dt
                            AND cust.party_rltd_end_dt > process_dt
                
                        WHERE 1=1
                            AND SRF.SERVICE_REQUEST_FACT_DT >= ADD_MONTHS(process_dt + 1, -1)
                            AND SRF.SERVICE_REQUEST_FACT_DT < process_dt + 1
                            AND SRF.T_NAME NOT IN (
                                'Vystavenie bankovej informácie pre účely auditu',
                                'BB majiteľ inštalácie - nastavenie',
                                'BB majiteľ účtu - nastavenie BB',
                                'IPPID - priradenie Tokenu DP770 pre službu BB Lite',
                                'Pridanie účtu do ELB'
                            )
                            AND SUBSTR(SRF.T_NAME, 3,1) != '-'
                    )
                )
                WHERE 1=1
            --        AND row_num = 1
            
                group by customerid, SERVICE_REQUEST_FACT_DT
    
        ;
        
        stat_ins(p_count => SQL%ROWCOUNT);
        commit;       
        
        -- ATTR_INTERACTION
        step(p_stepname => l_proc_name || ' START', p_source => 'N/A', p_target => 'N/A');   
        mng_partitions(l_owner_name, l_table_name, l_proc_name, process_dt);   
        step(p_stepname => l_proc_name || ' INSERT ' || l_table_name, p_source => 'L0.*', p_target => l_table_name);
        
        INSERT INTO pm_owner.ATTR_INTERACTION
        (
            SELECT 
                main.month_id,
                main.customerid,
                NVL(AVG_INBOUND_EMAIL_DURATION_M, 0) AS AVG_INBOUND_EMAIL_DURATION_M,
                ROUND((NVL(AVG_INBOUND_EMAIL_DURATION_M, 0) + NVL(AVG_INBOUND_EMAIL_DURATION_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0))/main.c_month_q) AS AVG_INBOUND_EMAIL_DURATION_Q,
                ROUND((NVL(AVG_INBOUND_EMAIL_DURATION_M, 0) + NVL(AVG_INBOUND_EMAIL_DURATION_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0))/main.c_month_y) AS AVG_INBOUND_EMAIL_DURATION_Y,
                NVL(AVG_INBOUND_VOICE_DURATION_M, 0) AS AVG_INBOUND_VOICE_DURATION_M,
                ROUND((NVL(AVG_INBOUND_VOICE_DURATION_M, 0) + NVL(AVG_INBOUND_VOICE_DURATION_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0))/main.c_month_q) AS AVG_INBOUND_VOICE_DURATION_Q,
                ROUND((NVL(AVG_INBOUND_VOICE_DURATION_M, 0) + NVL(AVG_INBOUND_VOICE_DURATION_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0))/main.c_month_y) AS AVG_INBOUND_VOICE_DURATION_Y,
                ROUND(DECODE(((NVL(AVG_INBOUND_VOICE_DURATION_M, 0) + NVL(AVG_INBOUND_VOICE_DURATION_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0))/main.c_month_q), 0, 1, NVL(AVG_INBOUND_VOICE_DURATION_M, 0)/((NVL(AVG_INBOUND_VOICE_DURATION_M, 0) + NVL(AVG_INBOUND_VOICE_DURATION_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0))/main.c_month_q)), 2) AS RATIO_DELTA_AVG_INBOUND_VOICE_DURATION_MQ,
                ROUND(DECODE(((NVL(AVG_INBOUND_VOICE_DURATION_M, 0) + NVL(AVG_INBOUND_VOICE_DURATION_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0))/main.c_month_y), 0, 1, NVL(AVG_INBOUND_VOICE_DURATION_M, 0)/((NVL(AVG_INBOUND_VOICE_DURATION_M, 0) + NVL(AVG_INBOUND_VOICE_DURATION_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0))/main.c_month_y)), 2) AS RATIO_DELTA_AVG_INBOUND_VOICE_DURATION_MY,
                NVL(AVG_OUTBOUND_EMAIL_DURATION_M, 0) AS AVG_OUTBOUND_EMAIL_DURATION_M,
                ROUND((NVL(AVG_OUTBOUND_EMAIL_DURATION_M, 0) + NVL(AVG_OUTBOUND_EMAIL_DURATION_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0))/main.c_month_q) AS AVG_OUTBOUND_EMAIL_DURATION_Q,
                ROUND((NVL(AVG_OUTBOUND_EMAIL_DURATION_M, 0) + NVL(AVG_OUTBOUND_EMAIL_DURATION_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0))/main.c_month_y) AS AVG_OUTBOUND_EMAIL_DURATION_Y,
                NVL(AVG_OUTBOUND_VOICE_DURATION_M, 0) AS AVG_OUTBOUND_VOICE_DURATION_M,
                ROUND((NVL(AVG_OUTBOUND_VOICE_DURATION_M, 0) + NVL(AVG_OUTBOUND_VOICE_DURATION_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0))/main.c_month_q) AS AVG_OUTBOUND_VOICE_DURATION_Q,
                ROUND((NVL(AVG_OUTBOUND_VOICE_DURATION_M, 0) + NVL(AVG_OUTBOUND_VOICE_DURATION_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0))/main.c_month_y) AS AVG_OUTBOUND_VOICE_DURATION_Y,
                NVL(SUM_INBOUND_EMAIL_DURATION_M, 0) AS SUM_INBOUND_EMAIL_DURATION_M,
                NVL(SUM_INBOUND_EMAIL_DURATION_M, 0) + NVL(SUM_INBOUND_EMAIL_DURATION_M2, 0) AS SUM_INBOUND_EMAIL_DURATION_Q,
                NVL(SUM_INBOUND_EMAIL_DURATION_M, 0) + NVL(SUM_INBOUND_EMAIL_DURATION_M11, 0) AS SUM_INBOUND_EMAIL_DURATION_Y,
                NVL(SUM_INBOUND_VOICE_DURATION_M, 0) AS SUM_INBOUND_VOICE_DURATION_M,
                NVL(SUM_INBOUND_VOICE_DURATION_M, 0) + NVL(SUM_INBOUND_VOICE_DURATION_M2, 0) AS SUM_INBOUND_VOICE_DURATION_Q,
                NVL(SUM_INBOUND_VOICE_DURATION_M, 0) + NVL(SUM_INBOUND_VOICE_DURATION_M11, 0) AS SUM_INBOUND_VOICE_DURATION_Y,
                NVL(SUM_OUTBOUND_EMAIL_DURATION_M, 0) AS SUM_OUTBOUND_EMAIL_DURATION_M,
                NVL(SUM_OUTBOUND_EMAIL_DURATION_M, 0) + NVL(SUM_OUTBOUND_EMAIL_DURATION_M2, 0) AS SUM_OUTBOUND_EMAIL_DURATION_Q,
                NVL(SUM_OUTBOUND_EMAIL_DURATION_M, 0) + NVL(SUM_OUTBOUND_EMAIL_DURATION_M11, 0) AS SUM_OUTBOUND_EMAIL_DURATION_Y,
                NVL(SUM_OUTBOUND_VOICE_DURATION_M, 0) AS SUM_OUTBOUND_VOICE_DURATION_M,
                NVL(SUM_OUTBOUND_VOICE_DURATION_M, 0) + NVL(SUM_OUTBOUND_VOICE_DURATION_M2, 0) AS SUM_OUTBOUND_VOICE_DURATION_Q,
                NVL(SUM_OUTBOUND_VOICE_DURATION_M, 0) + NVL(SUM_OUTBOUND_VOICE_DURATION_M11, 0) AS SUM_OUTBOUND_VOICE_DURATION_Y,
                NVL(C_INBOUND_EMAIL_M, 0) AS C_INBOUND_EMAIL_M,
                NVL(C_INBOUND_EMAIL_M, 0) + NVL(C_INBOUND_EMAIL_M2, 0) AS C_INBOUND_EMAIL_Q,
                NVL(C_INBOUND_EMAIL_M, 0) + NVL(C_INBOUND_EMAIL_M11, 0) AS C_INBOUND_EMAIL_Y,
                ROUND(DECODE(NVL(C_INBOUND_EMAIL_M, 0) + NVL(C_INBOUND_EMAIL_M2, 0), 0, 1/3, NVL(C_INBOUND_EMAIL_M, 0)/(NVL(C_INBOUND_EMAIL_M, 0) + NVL(C_INBOUND_EMAIL_M2, 0))), 2) AS RATIO_DELTA_C_INBOUND_EMAIL_MQ,
                ROUND(DECODE(NVL(C_INBOUND_EMAIL_M, 0) + NVL(C_INBOUND_EMAIL_M11, 0), 0, 1/12, NVL(C_INBOUND_EMAIL_M, 0)/(NVL(C_INBOUND_EMAIL_M, 0) + NVL(C_INBOUND_EMAIL_M11, 0))), 2) AS RATIO_DELTA_C_INBOUND_EMAIL_MY,
                NVL(C_INBOUND_VOICE_M, 0) AS C_INBOUND_VOICE_M,
                NVL(C_INBOUND_VOICE_M, 0) + NVL(C_INBOUND_VOICE_M2, 0) AS C_INBOUND_VOICE_Q,
                NVL(C_INBOUND_VOICE_M, 0) + NVL(C_INBOUND_VOICE_M11, 0) AS C_INBOUND_VOICE_Y,
                ROUND(DECODE(NVL(C_INBOUND_VOICE_M, 0) + NVL(C_INBOUND_VOICE_M2, 0), 0, 1/3, NVL(C_INBOUND_VOICE_M, 0)/(NVL(C_INBOUND_VOICE_M, 0) + NVL(C_INBOUND_VOICE_M2, 0))), 2) AS RATIO_DELTA_C_INBOUND_VOICE_MQ,
                ROUND(DECODE(NVL(C_INBOUND_VOICE_M, 0) + NVL(C_INBOUND_VOICE_M11, 0), 0, 1/12, NVL(C_INBOUND_VOICE_M, 0)/(NVL(C_INBOUND_VOICE_M, 0) + NVL(C_INBOUND_VOICE_M11, 0))), 2) AS RATIO_DELTA_C_INBOUND_VOICE_MY,
                NVL(C_OUTBOUND_EMAIL_M, 0) AS C_OUTBOUND_EMAIL_M,
                NVL(C_OUTBOUND_EMAIL_M, 0) + NVL(C_OUTBOUND_EMAIL_M2, 0) AS C_OUTBOUND_EMAIL_Q,
                NVL(C_OUTBOUND_EMAIL_M, 0) + NVL(C_OUTBOUND_EMAIL_M11, 0) AS C_OUTBOUND_EMAIL_Y,
                ROUND(DECODE(NVL(C_OUTBOUND_EMAIL_M, 0) + NVL(C_OUTBOUND_EMAIL_M2, 0), 0, 1/3, NVL(C_OUTBOUND_EMAIL_M, 0)/(NVL(C_OUTBOUND_EMAIL_M, 0) + NVL(C_OUTBOUND_EMAIL_M2, 0))), 2) AS RATIO_DELTA_C_OUTBOUND_EMAIL_MQ,
                ROUND(DECODE(NVL(C_OUTBOUND_EMAIL_M, 0) + NVL(C_OUTBOUND_EMAIL_M11, 0), 0, 1/12, NVL(C_OUTBOUND_EMAIL_M, 0)/(NVL(C_OUTBOUND_EMAIL_M, 0) + NVL(C_OUTBOUND_EMAIL_M11, 0))), 2) AS RATIO_DELTA_C_OUTBOUND_EMAIL_MY,
                NVL(C_OUTBOUND_VOICE_M, 0) AS C_OUTBOUND_VOICE_M,
                NVL(C_OUTBOUND_VOICE_M, 0) + NVL(C_OUTBOUND_VOICE_M2, 0) AS C_OUTBOUND_VOICE_Q,
                NVL(C_OUTBOUND_VOICE_M, 0) + NVL(C_OUTBOUND_VOICE_M11, 0) AS C_OUTBOUND_VOICE_Y,
                ROUND(DECODE(NVL(C_OUTBOUND_VOICE_M, 0) + NVL(C_OUTBOUND_VOICE_M2, 0), 0, 1/3, NVL(C_OUTBOUND_VOICE_M, 0)/(NVL(C_OUTBOUND_VOICE_M, 0) + NVL(C_OUTBOUND_VOICE_M2, 0))), 2) AS RATIO_DELTA_C_OUTBOUND_VOICE_MQ,
                ROUND(DECODE(NVL(C_OUTBOUND_VOICE_M, 0) + NVL(C_OUTBOUND_VOICE_M11, 0), 0, 1/12, NVL(C_OUTBOUND_VOICE_M, 0)/(NVL(C_OUTBOUND_VOICE_M, 0) + NVL(C_OUTBOUND_VOICE_M11, 0))), 2) AS RATIO_DELTA_C_OUTBOUND_VOICE_MY,
                NVL(I_INBOUND_EMAIL_M, 0) AS I_INBOUND_EMAIL_M,
                GREATEST(NVL(I_INBOUND_EMAIL_M, 0), NVL(I_INBOUND_EMAIL_M2, 0)) AS I_INBOUND_EMAIL_Q,
                GREATEST(NVL(I_INBOUND_EMAIL_M, 0), NVL(I_INBOUND_EMAIL_M11, 0)) AS I_INBOUND_EMAIL_Y,
                NVL(I_INBOUND_VOICE_M, 0) AS I_INBOUND_VOICE_M,
                GREATEST(NVL(I_INBOUND_VOICE_M, 0), NVL(I_INBOUND_VOICE_M2, 0)) AS I_INBOUND_VOICE_Q,
                GREATEST(NVL(I_INBOUND_VOICE_M, 0), NVL(I_INBOUND_VOICE_M11, 0)) AS I_INBOUND_VOICE_Y,
                NVL(I_OUTBOUND_EMAIL_M, 0) AS I_OUTBOUND_EMAIL_M,
                GREATEST(NVL(I_OUTBOUND_EMAIL_M, 0), NVL(I_OUTBOUND_EMAIL_M2, 0)) AS I_OUTBOUND_EMAIL_Q,
                GREATEST(NVL(I_OUTBOUND_EMAIL_M, 0), NVL(I_OUTBOUND_EMAIL_M11, 0)) AS I_OUTBOUND_EMAIL_Y,
                NVL(I_OUTBOUND_VOICE_M, 0) AS I_OUTBOUND_VOICE_M,
                GREATEST(NVL(I_OUTBOUND_VOICE_M, 0), NVL(I_OUTBOUND_VOICE_M2, 0)) AS I_OUTBOUND_VOICE_Q,
                GREATEST(NVL(I_OUTBOUND_VOICE_M, 0), NVL(I_OUTBOUND_VOICE_M11, 0)) AS I_OUTBOUND_VOICE_Y,
                NVL(C_INBOUND_RESULT_COMPLETED_M, 0) AS C_INBOUND_RESULT_COMPLETED_M,
                NVL(C_INBOUND_RESULT_COMPLETED_M, 0) + NVL(C_INBOUND_RESULT_COMPLETED_M2, 0) AS C_INBOUND_RESULT_COMPLETED_Q,
                NVL(C_INBOUND_RESULT_COMPLETED_M, 0) + NVL(C_INBOUND_RESULT_COMPLETED_M11, 0) AS C_INBOUND_RESULT_COMPLETED_Y,
                NVL(C_INBOUND_RESULT_REDIRECTED_M, 0) AS C_INBOUND_RESULT_REDIRECTED_M,
                NVL(C_INBOUND_RESULT_REDIRECTED_M, 0) + NVL(C_INBOUND_RESULT_REDIRECTED_M2, 0) AS C_INBOUND_RESULT_REDIRECTED_Q,
                NVL(C_INBOUND_RESULT_REDIRECTED_M, 0) + NVL(C_INBOUND_RESULT_REDIRECTED_M11, 0) AS C_INBOUND_RESULT_REDIRECTED_Y,
                NVL(C_INBOUND_RESULT_CONFERENCED_M, 0) AS C_INBOUND_RESULT_CONFERENCED_M,
                NVL(C_INBOUND_RESULT_CONFERENCED_M, 0) + NVL(C_INBOUND_RESULT_CONFERENCED_M2, 0) AS C_INBOUND_RESULT_CONFERENCED_Q,
                NVL(C_INBOUND_RESULT_CONFERENCED_M, 0) + NVL(C_INBOUND_RESULT_CONFERENCED_M11, 0) AS C_INBOUND_RESULT_CONFERENCED_Y,
                NVL(C_INBOUND_RESULT_DIVERTED_M, 0) AS C_INBOUND_RESULT_DIVERTED_M,
                NVL(C_INBOUND_RESULT_DIVERTED_M, 0) + NVL(C_INBOUND_RESULT_DIVERTED_M2, 0) AS C_INBOUND_RESULT_DIVERTED_Q,
                NVL(C_INBOUND_RESULT_DIVERTED_M, 0) + NVL(C_INBOUND_RESULT_DIVERTED_M11, 0) AS C_INBOUND_RESULT_DIVERTED_Y,
                NVL(C_INBOUND_RESULT_ABANDONED_M, 0) AS C_INBOUND_RESULT_ABANDONED_M,
                NVL(C_INBOUND_RESULT_ABANDONED_M, 0) + NVL(C_INBOUND_RESULT_ABANDONED_M2, 0) AS C_INBOUND_RESULT_ABANDONED_Q,
                NVL(C_INBOUND_RESULT_ABANDONED_M, 0) + NVL(C_INBOUND_RESULT_ABANDONED_M11, 0) AS C_INBOUND_RESULT_ABANDONED_Y,
                NVL(C_INBOUND_RESULT_TRANSFERRED_M, 0) AS C_INBOUND_RESULT_TRANSFERRED_M,
                NVL(C_INBOUND_RESULT_TRANSFERRED_M, 0) + NVL(C_INBOUND_RESULT_TRANSFERRED_M2, 0) AS C_INBOUND_RESULT_TRANSFERRED_Q,
                NVL(C_INBOUND_RESULT_TRANSFERRED_M, 0) + NVL(C_INBOUND_RESULT_TRANSFERRED_M11, 0) AS C_INBOUND_RESULT_TRANSFERRED_Y,
                NVL(C_INBOUND_RESULT_DESTINATIONBUSY_M, 0) AS C_INBOUND_RESULT_DESTINATIONBUSY_M,
                NVL(C_INBOUND_RESULT_DESTINATIONBUSY_M, 0) + NVL(C_INBOUND_RESULT_DESTINATIONBUSY_M2, 0) AS C_INBOUND_RESULT_DESTINATIONBUSY_Q,
                NVL(C_INBOUND_RESULT_DESTINATIONBUSY_M, 0) + NVL(C_INBOUND_RESULT_DESTINATIONBUSY_M11, 0) AS C_INBOUND_RESULT_DESTINATIONBUSY_Y,
                NVL(C_INBOUND_RESULT_CUSTOMERABANDONED_M, 0) AS C_INBOUND_RESULT_CUSTOMERABANDONED_M,
                NVL(C_INBOUND_RESULT_CUSTOMERABANDONED_M, 0) + NVL(C_INBOUND_RESULT_CUSTOMERABANDONED_M2, 0) AS C_INBOUND_RESULT_CUSTOMERABANDONED_Q,
                NVL(C_INBOUND_RESULT_CUSTOMERABANDONED_M, 0) + NVL(C_INBOUND_RESULT_CUSTOMERABANDONED_M11, 0) AS C_INBOUND_RESULT_CUSTOMERABANDONED_Y,
                NVL(C_INBOUND_RESULT_ABNORMALSTOP_M, 0) AS C_INBOUND_RESULT_ABNORMALSTOP_M,
                NVL(C_INBOUND_RESULT_ABNORMALSTOP_M, 0) + NVL(C_INBOUND_RESULT_ABNORMALSTOP_M2, 0) AS C_INBOUND_RESULT_ABNORMALSTOP_Q,
                NVL(C_INBOUND_RESULT_ABNORMALSTOP_M, 0) + NVL(C_INBOUND_RESULT_ABNORMALSTOP_M11, 0) AS C_INBOUND_RESULT_ABNORMALSTOP_Y,
                NVL(C_OUTBOUND_RESULT_COMPLETED_M, 0) AS C_OUTBOUND_RESULT_COMPLETED_M,
                NVL(C_OUTBOUND_RESULT_COMPLETED_M, 0) + NVL(C_OUTBOUND_RESULT_COMPLETED_M2, 0) AS C_OUTBOUND_RESULT_COMPLETED_Q,
                NVL(C_OUTBOUND_RESULT_COMPLETED_M, 0) + NVL(C_OUTBOUND_RESULT_COMPLETED_M11, 0) AS C_OUTBOUND_RESULT_COMPLETED_Y,
                NVL(C_OUTBOUND_RESULT_REDIRECTED_M, 0) AS C_OUTBOUND_RESULT_REDIRECTED_M,
                NVL(C_OUTBOUND_RESULT_REDIRECTED_M, 0) + NVL(C_OUTBOUND_RESULT_REDIRECTED_M2, 0) AS C_OUTBOUND_RESULT_REDIRECTED_Q,
                NVL(C_OUTBOUND_RESULT_REDIRECTED_M, 0) + NVL(C_OUTBOUND_RESULT_REDIRECTED_M11, 0) AS C_OUTBOUND_RESULT_REDIRECTED_Y,
                NVL(C_OUTBOUND_RESULT_CONFERENCED_M, 0) AS C_OUTBOUND_RESULT_CONFERENCED_M,
                NVL(C_OUTBOUND_RESULT_CONFERENCED_M, 0) + NVL(C_OUTBOUND_RESULT_CONFERENCED_M2, 0) AS C_OUTBOUND_RESULT_CONFERENCED_Q,
                NVL(C_OUTBOUND_RESULT_CONFERENCED_M, 0) + NVL(C_OUTBOUND_RESULT_CONFERENCED_M11, 0) AS C_OUTBOUND_RESULT_CONFERENCED_Y,
                NVL(C_OUTBOUND_RESULT_DIVERTED_M, 0) AS C_OUTBOUND_RESULT_DIVERTED_M,
                NVL(C_OUTBOUND_RESULT_DIVERTED_M, 0) + NVL(C_OUTBOUND_RESULT_DIVERTED_M2, 0) AS C_OUTBOUND_RESULT_DIVERTED_Q,
                NVL(C_OUTBOUND_RESULT_DIVERTED_M, 0) + NVL(C_OUTBOUND_RESULT_DIVERTED_M11, 0) AS C_OUTBOUND_RESULT_DIVERTED_Y,
                NVL(C_OUTBOUND_RESULT_ABANDONED_M, 0) AS C_OUTBOUND_RESULT_ABANDONED_M,
                NVL(C_OUTBOUND_RESULT_ABANDONED_M, 0) + NVL(C_OUTBOUND_RESULT_ABANDONED_M2, 0) AS C_OUTBOUND_RESULT_ABANDONED_Q,
                NVL(C_OUTBOUND_RESULT_ABANDONED_M, 0) + NVL(C_OUTBOUND_RESULT_ABANDONED_M11, 0) AS C_OUTBOUND_RESULT_ABANDONED_Y,
                NVL(C_OUTBOUND_RESULT_TRANSFERRED_M, 0) AS C_OUTBOUND_RESULT_TRANSFERRED_M,
                NVL(C_OUTBOUND_RESULT_TRANSFERRED_M, 0) + NVL(C_OUTBOUND_RESULT_TRANSFERRED_M2, 0) AS C_OUTBOUND_RESULT_TRANSFERRED_Q,
                NVL(C_OUTBOUND_RESULT_TRANSFERRED_M, 0) + NVL(C_OUTBOUND_RESULT_TRANSFERRED_M11, 0) AS C_OUTBOUND_RESULT_TRANSFERRED_Y,
                NVL(C_OUTBOUND_RESULT_DESTINATIONBUSY_M, 0) AS C_OUTBOUND_RESULT_DESTINATIONBUSY_M,
                NVL(C_OUTBOUND_RESULT_DESTINATIONBUSY_M, 0) + NVL(C_OUTBOUND_RESULT_DESTINATIONBUSY_M2, 0) AS C_OUTBOUND_RESULT_DESTINATIONBUSY_Q,
                NVL(C_OUTBOUND_RESULT_DESTINATIONBUSY_M, 0) + NVL(C_OUTBOUND_RESULT_DESTINATIONBUSY_M11, 0) AS C_OUTBOUND_RESULT_DESTINATIONBUSY_Y,
                NVL(C_OUTBOUND_RESULT_CUSTOMERABANDONED_M, 0) AS C_OUTBOUND_RESULT_CUSTOMERABANDONED_M,
                NVL(C_OUTBOUND_RESULT_CUSTOMERABANDONED_M, 0) + NVL(C_OUTBOUND_RESULT_CUSTOMERABANDONED_M2, 0) AS C_OUTBOUND_RESULT_CUSTOMERABANDONED_Q,
                NVL(C_OUTBOUND_RESULT_CUSTOMERABANDONED_M, 0) + NVL(C_OUTBOUND_RESULT_CUSTOMERABANDONED_M11, 0) AS C_OUTBOUND_RESULT_CUSTOMERABANDONED_Y,
                NVL(C_OUTBOUND_RESULT_ABNORMALSTOP_M, 0) AS C_OUTBOUND_RESULT_ABNORMALSTOP_M,
                NVL(C_OUTBOUND_RESULT_ABNORMALSTOP_M, 0) + NVL(C_OUTBOUND_RESULT_ABNORMALSTOP_M2, 0) AS C_OUTBOUND_RESULT_ABNORMALSTOP_Q,
                NVL(C_OUTBOUND_RESULT_ABNORMALSTOP_M, 0) + NVL(C_OUTBOUND_RESULT_ABNORMALSTOP_M11, 0) AS C_OUTBOUND_RESULT_ABNORMALSTOP_Y,
                NVL(I_INBOUND_RESULT_COMPLETED_M, 0) AS I_INBOUND_RESULT_COMPLETED_M,
                GREATEST(NVL(I_INBOUND_RESULT_COMPLETED_M, 0), NVL(I_INBOUND_RESULT_COMPLETED_M2, 0)) AS I_INBOUND_RESULT_COMPLETED_Q,
                GREATEST(NVL(I_INBOUND_RESULT_COMPLETED_M, 0), NVL(I_INBOUND_RESULT_COMPLETED_M2, 0), NVL(I_INBOUND_RESULT_COMPLETED_M11, 0)) AS I_INBOUND_RESULT_COMPLETED_Y,
                NVL(I_INBOUND_RESULT_REDIRECTED_M, 0) AS I_INBOUND_RESULT_REDIRECTED_M,
                GREATEST(NVL(I_INBOUND_RESULT_REDIRECTED_M, 0), NVL(I_INBOUND_RESULT_REDIRECTED_M2, 0)) AS I_INBOUND_RESULT_REDIRECTED_Q,
                GREATEST(NVL(I_INBOUND_RESULT_REDIRECTED_M, 0), NVL(I_INBOUND_RESULT_REDIRECTED_M2, 0), NVL(I_INBOUND_RESULT_REDIRECTED_M11, 0)) AS I_INBOUND_RESULT_REDIRECTED_Y,
                NVL(I_INBOUND_RESULT_CONFERENCED_M, 0) AS I_INBOUND_RESULT_CONFERENCED_M,
                GREATEST(NVL(I_INBOUND_RESULT_CONFERENCED_M, 0), NVL(I_INBOUND_RESULT_CONFERENCED_M2, 0)) AS I_INBOUND_RESULT_CONFERENCED_Q,
                GREATEST(NVL(I_INBOUND_RESULT_CONFERENCED_M, 0), NVL(I_INBOUND_RESULT_CONFERENCED_M2, 0), NVL(I_INBOUND_RESULT_CONFERENCED_M11, 0)) AS I_INBOUND_RESULT_CONFERENCED_Y,
                NVL(I_INBOUND_RESULT_DIVERTED_M, 0) AS I_INBOUND_RESULT_DIVERTED_M,
                GREATEST(NVL(I_INBOUND_RESULT_DIVERTED_M, 0), NVL(I_INBOUND_RESULT_DIVERTED_M2, 0)) AS I_INBOUND_RESULT_DIVERTED_Q,
                GREATEST(NVL(I_INBOUND_RESULT_DIVERTED_M, 0), NVL(I_INBOUND_RESULT_DIVERTED_M2, 0), NVL(I_INBOUND_RESULT_DIVERTED_M11, 0)) AS I_INBOUND_RESULT_DIVERTED_Y,
                NVL(I_INBOUND_RESULT_ABANDONED_M, 0) AS I_INBOUND_RESULT_ABANDONED_M,
                GREATEST(NVL(I_INBOUND_RESULT_ABANDONED_M, 0), NVL(I_INBOUND_RESULT_ABANDONED_M2, 0)) AS I_INBOUND_RESULT_ABANDONED_Q,
                GREATEST(NVL(I_INBOUND_RESULT_ABANDONED_M, 0), NVL(I_INBOUND_RESULT_ABANDONED_M2, 0), NVL(I_INBOUND_RESULT_ABANDONED_M11, 0)) AS I_INBOUND_RESULT_ABANDONED_Y,
                NVL(I_INBOUND_RESULT_TRANSFERRED_M, 0) AS I_INBOUND_RESULT_TRANSFERRED_M,
                GREATEST(NVL(I_INBOUND_RESULT_TRANSFERRED_M, 0), NVL(I_INBOUND_RESULT_TRANSFERRED_M2, 0)) AS I_INBOUND_RESULT_TRANSFERRED_Q,
                GREATEST(NVL(I_INBOUND_RESULT_TRANSFERRED_M, 0), NVL(I_INBOUND_RESULT_TRANSFERRED_M2, 0), NVL(I_INBOUND_RESULT_TRANSFERRED_M11, 0)) AS I_INBOUND_RESULT_TRANSFERRED_Y,
                NVL(I_INBOUND_RESULT_DESTINATIONBUSY_M, 0) AS I_INBOUND_RESULT_DESTINATIONBUSY_M,
                GREATEST(NVL(I_INBOUND_RESULT_DESTINATIONBUSY_M, 0), NVL(I_INBOUND_RESULT_DESTINATIONBUSY_M2, 0)) AS I_INBOUND_RESULT_DESTINATIONBUSY_Q,
                GREATEST(NVL(I_INBOUND_RESULT_DESTINATIONBUSY_M, 0), NVL(I_INBOUND_RESULT_DESTINATIONBUSY_M2, 0), NVL(I_INBOUND_RESULT_DESTINATIONBUSY_M11, 0)) AS I_INBOUND_RESULT_DESTINATIONBUSY_Y,
                NVL(I_INBOUND_RESULT_CUSTOMERABANDONED_M, 0) AS I_INBOUND_RESULT_CUSTOMERABANDONED_M,
                GREATEST(NVL(I_INBOUND_RESULT_CUSTOMERABANDONED_M, 0), NVL(I_INBOUND_RESULT_CUSTOMERABANDONED_M2, 0)) AS I_INBOUND_RESULT_CUSTOMERABANDONED_Q,
                GREATEST(NVL(I_INBOUND_RESULT_CUSTOMERABANDONED_M, 0), NVL(I_INBOUND_RESULT_CUSTOMERABANDONED_M2, 0), NVL(I_INBOUND_RESULT_CUSTOMERABANDONED_M11, 0)) AS I_INBOUND_RESULT_CUSTOMERABANDONED_Y,
                NVL(I_INBOUND_RESULT_ABNORMALSTOP_M, 0) AS I_INBOUND_RESULT_ABNORMALSTOP_M,
                GREATEST(NVL(I_INBOUND_RESULT_ABNORMALSTOP_M, 0), NVL(I_INBOUND_RESULT_ABNORMALSTOP_M2, 0)) AS I_INBOUND_RESULT_ABNORMALSTOP_Q,
                GREATEST(NVL(I_INBOUND_RESULT_ABNORMALSTOP_M, 0), NVL(I_INBOUND_RESULT_ABNORMALSTOP_M2, 0), NVL(I_INBOUND_RESULT_ABNORMALSTOP_M11, 0)) AS I_INBOUND_RESULT_ABNORMALSTOP_Y,
                NVL(I_OUTBOUND_RESULT_COMPLETED_M, 0) AS I_OUTBOUND_RESULT_COMPLETED_M,
                GREATEST(NVL(I_OUTBOUND_RESULT_COMPLETED_M, 0), NVL(I_OUTBOUND_RESULT_COMPLETED_M2, 0)) AS I_OUTBOUND_RESULT_COMPLETED_Q,
                GREATEST(NVL(I_OUTBOUND_RESULT_COMPLETED_M, 0), NVL(I_OUTBOUND_RESULT_COMPLETED_M2, 0), NVL(I_OUTBOUND_RESULT_COMPLETED_M11, 0)) AS I_OUTBOUND_RESULT_COMPLETED_Y,
                NVL(I_OUTBOUND_RESULT_REDIRECTED_M, 0) AS I_OUTBOUND_RESULT_REDIRECTED_M,
                GREATEST(NVL(I_OUTBOUND_RESULT_REDIRECTED_M, 0), NVL(I_OUTBOUND_RESULT_REDIRECTED_M2, 0)) AS I_OUTBOUND_RESULT_REDIRECTED_Q,
                GREATEST(NVL(I_OUTBOUND_RESULT_REDIRECTED_M, 0), NVL(I_OUTBOUND_RESULT_REDIRECTED_M2, 0), NVL(I_OUTBOUND_RESULT_REDIRECTED_M11, 0)) AS I_OUTBOUND_RESULT_REDIRECTED_Y,
                NVL(I_OUTBOUND_RESULT_CONFERENCED_M, 0) AS I_OUTBOUND_RESULT_CONFERENCED_M,
                GREATEST(NVL(I_OUTBOUND_RESULT_CONFERENCED_M, 0), NVL(I_OUTBOUND_RESULT_CONFERENCED_M2, 0)) AS I_OUTBOUND_RESULT_CONFERENCED_Q,
                GREATEST(NVL(I_OUTBOUND_RESULT_CONFERENCED_M, 0), NVL(I_OUTBOUND_RESULT_CONFERENCED_M2, 0), NVL(I_OUTBOUND_RESULT_CONFERENCED_M11, 0)) AS I_OUTBOUND_RESULT_CONFERENCED_Y,
                NVL(I_OUTBOUND_RESULT_DIVERTED_M, 0) AS I_OUTBOUND_RESULT_DIVERTED_M,
                GREATEST(NVL(I_OUTBOUND_RESULT_DIVERTED_M, 0), NVL(I_OUTBOUND_RESULT_DIVERTED_M2, 0)) AS I_OUTBOUND_RESULT_DIVERTED_Q,
                GREATEST(NVL(I_OUTBOUND_RESULT_DIVERTED_M, 0), NVL(I_OUTBOUND_RESULT_DIVERTED_M2, 0), NVL(I_OUTBOUND_RESULT_DIVERTED_M11, 0)) AS I_OUTBOUND_RESULT_DIVERTED_Y,
                NVL(I_OUTBOUND_RESULT_ABANDONED_M, 0) AS I_OUTBOUND_RESULT_ABANDONED_M,
                GREATEST(NVL(I_OUTBOUND_RESULT_ABANDONED_M, 0), NVL(I_OUTBOUND_RESULT_ABANDONED_M2, 0)) AS I_OUTBOUND_RESULT_ABANDONED_Q,
                GREATEST(NVL(I_OUTBOUND_RESULT_ABANDONED_M, 0), NVL(I_OUTBOUND_RESULT_ABANDONED_M2, 0), NVL(I_OUTBOUND_RESULT_ABANDONED_M11, 0)) AS I_OUTBOUND_RESULT_ABANDONED_Y,
                NVL(I_OUTBOUND_RESULT_TRANSFERRED_M, 0) AS I_OUTBOUND_RESULT_TRANSFERRED_M,
                GREATEST(NVL(I_OUTBOUND_RESULT_TRANSFERRED_M, 0), NVL(I_OUTBOUND_RESULT_TRANSFERRED_M2, 0)) AS I_OUTBOUND_RESULT_TRANSFERRED_Q,
                GREATEST(NVL(I_OUTBOUND_RESULT_TRANSFERRED_M, 0), NVL(I_OUTBOUND_RESULT_TRANSFERRED_M2, 0), NVL(I_OUTBOUND_RESULT_TRANSFERRED_M11, 0)) AS I_OUTBOUND_RESULT_TRANSFERRED_Y,
                NVL(I_OUTBOUND_RESULT_DESTINATIONBUSY_M, 0) AS I_OUTBOUND_RESULT_DESTINATIONBUSY_M,
                GREATEST(NVL(I_OUTBOUND_RESULT_DESTINATIONBUSY_M, 0), NVL(I_OUTBOUND_RESULT_DESTINATIONBUSY_M2, 0)) AS I_OUTBOUND_RESULT_DESTINATIONBUSY_Q,
                GREATEST(NVL(I_OUTBOUND_RESULT_DESTINATIONBUSY_M, 0), NVL(I_OUTBOUND_RESULT_DESTINATIONBUSY_M2, 0), NVL(I_OUTBOUND_RESULT_DESTINATIONBUSY_M11, 0)) AS I_OUTBOUND_RESULT_DESTINATIONBUSY_Y,
                NVL(I_OUTBOUND_RESULT_CUSTOMERABANDONED_M, 0) AS I_OUTBOUND_RESULT_CUSTOMERABANDONED_M,
                GREATEST(NVL(I_OUTBOUND_RESULT_CUSTOMERABANDONED_M, 0), NVL(I_OUTBOUND_RESULT_CUSTOMERABANDONED_M2, 0)) AS I_OUTBOUND_RESULT_CUSTOMERABANDONED_Q,
                GREATEST(NVL(I_OUTBOUND_RESULT_CUSTOMERABANDONED_M, 0), NVL(I_OUTBOUND_RESULT_CUSTOMERABANDONED_M2, 0), NVL(I_OUTBOUND_RESULT_CUSTOMERABANDONED_M11, 0)) AS I_OUTBOUND_RESULT_CUSTOMERABANDONED_Y,
                NVL(I_OUTBOUND_RESULT_ABNORMALSTOP_M, 0) AS I_OUTBOUND_RESULT_ABNORMALSTOP_M,
                GREATEST(NVL(I_OUTBOUND_RESULT_ABNORMALSTOP_M, 0), NVL(I_OUTBOUND_RESULT_ABNORMALSTOP_M2, 0)) AS I_OUTBOUND_RESULT_ABNORMALSTOP_Q,
                GREATEST(NVL(I_OUTBOUND_RESULT_ABNORMALSTOP_M, 0), NVL(I_OUTBOUND_RESULT_ABNORMALSTOP_M2, 0), NVL(I_OUTBOUND_RESULT_ABNORMALSTOP_M11, 0)) AS I_OUTBOUND_RESULT_ABNORMALSTOP_Y,
                NVL(RATIO_INBOUND_VOICE_COMPLETED_M, 0) AS RATIO_INBOUND_VOICE_COMPLETED_M,
                ROUND((NVL(RATIO_INBOUND_VOICE_COMPLETED_M, 0) + NVL(RATIO_INBOUND_VOICE_COMPLETED_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0)) / main.c_month_q, 2)  AS RATIO_INBOUND_VOICE_COMPLETED_Q,
                ROUND((NVL(RATIO_INBOUND_VOICE_COMPLETED_M, 0) + NVL(RATIO_INBOUND_VOICE_COMPLETED_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0)) / main.c_month_y, 2)  AS RATIO_INBOUND_VOICE_COMPLETED_Y,
                NVL(RATIO_INBOUND_VOICE_ABANDONED_M, 0) AS RATIO_INBOUND_VOICE_ABANDONED_M,
                ROUND((NVL(RATIO_INBOUND_VOICE_ABANDONED_M, 0) + NVL(RATIO_INBOUND_VOICE_ABANDONED_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0)) / main.c_month_q, 2) AS RATIO_INBOUND_VOICE_ABANDONED_Q,
                ROUND((NVL(RATIO_INBOUND_VOICE_ABANDONED_M, 0) + NVL(RATIO_INBOUND_VOICE_ABANDONED_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0)) / main.c_month_y, 2) AS RATIO_INBOUND_VOICE_ABANDONED_Y,
                NVL(RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M, 0) AS RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M,
                ROUND((NVL(RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M, 0) + NVL(RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0)) / main.c_month_q, 2) AS RATIO_INBOUND_VOICE_CUSTOMERABANDONED_Q,
                ROUND((NVL(RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M, 0) + NVL(RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0)) / main.c_month_y, 2) AS RATIO_INBOUND_VOICE_CUSTOMERABANDONED_Y,
                NVL(RATIO_OUTBOUND_VOICE_COMPLETED_M, 0) AS RATIO_OUTBOUND_VOICE_COMPLETED_M,
                ROUND((NVL(RATIO_OUTBOUND_VOICE_COMPLETED_M, 0) + NVL(RATIO_OUTBOUND_VOICE_COMPLETED_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0)) / main.c_month_q, 2) AS RATIO_OUTBOUND_VOICE_COMPLETED_Q,
                ROUND((NVL(RATIO_OUTBOUND_VOICE_COMPLETED_M, 0) + NVL(RATIO_OUTBOUND_VOICE_COMPLETED_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0)) / main.c_month_y, 2) AS RATIO_OUTBOUND_VOICE_COMPLETED_Y,
                NVL(RATIO_OUTBOUND_VOICE_ABANDONED_M, 0) AS RATIO_OUTBOUND_VOICE_ABANDONED_M,
                ROUND((NVL(RATIO_OUTBOUND_VOICE_ABANDONED_M, 0) + NVL(RATIO_OUTBOUND_VOICE_ABANDONED_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0)) / main.c_month_q, 2) AS RATIO_OUTBOUND_VOICE_ABANDONED_Q,
                ROUND((NVL(RATIO_OUTBOUND_VOICE_ABANDONED_M, 0) + NVL(RATIO_OUTBOUND_VOICE_ABANDONED_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0)) / main.c_month_y, 2) AS RATIO_OUTBOUND_VOICE_ABANDONED_Y,
                NVL(RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M, 0) AS RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M,
                ROUND((NVL(RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M, 0) + NVL(RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0)) / main.c_month_q, 2) AS RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_Q,
                ROUND((NVL(RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M, 0) + NVL(RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0)) / main.c_month_y, 2) AS RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_Y,
                NVL(RATIO_INBOUND_EMAIL_M, 0) AS RATIO_INBOUND_EMAIL_M,
                ROUND((NVL(RATIO_INBOUND_EMAIL_M, 0) + NVL(RATIO_INBOUND_EMAIL_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0)) / main.c_month_q, 2) AS RATIO_INBOUND_EMAIL_Q,
                ROUND((NVL(RATIO_INBOUND_EMAIL_M, 0) + NVL(RATIO_INBOUND_EMAIL_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0)) / main.c_month_y, 2) AS RATIO_INBOUND_EMAIL_Y,
                NVL(RATIO_INBOUND_VOICE_M, 0) AS RATIO_INBOUND_VOICE_M,
                ROUND((NVL(RATIO_INBOUND_VOICE_M, 0) + NVL(RATIO_INBOUND_VOICE_M2, 0) * GREATEST(LEAST(main.c_month_q - 1, 2), 0)) / main.c_month_q, 2) AS RATIO_INBOUND_VOICE_Q,
                ROUND((NVL(RATIO_INBOUND_VOICE_M, 0) + NVL(RATIO_INBOUND_VOICE_M11, 0) * GREATEST(LEAST(main.c_month_y - 1, 11), 0)) / main.c_month_y, 2) AS RATIO_INBOUND_VOICE_Y,
                COALESCE(RECENCY_INBOUND_EMAIL, RECENCY_INBOUND_EMAIL_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_INBOUND_EMAIL,
                COALESCE(RECENCY_INBOUND_VOICE, RECENCY_INBOUND_VOICE_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_INBOUND_VOICE,
                COALESCE(RECENCY_OUTBOUND_EMAIL, RECENCY_OUTBOUND_EMAIL_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_OUTBOUND_EMAIL,
                COALESCE(RECENCY_OUTBOUND_VOICE, RECENCY_OUTBOUND_VOICE_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_OUTBOUND_VOICE,
                NVL(AVG_FEEDBACK_M, 10) AS AVG_FEEDBACK_M,
                ROUND((NVL(AVG_FEEDBACK_M, 10) * NVL(I_FEEDBACK_M, 0) + NVL(AVG_FEEDBACK_M2, 0)) / NVL(NULLIF(NVL(SUM_I_FEEDBACK_M2, 0) + NVL(I_FEEDBACK_M, 0), 0), 1)) AS AVG_FEEDBACK_Q,
                ROUND((NVL(AVG_FEEDBACK_M, 10) * NVL(I_FEEDBACK_M, 0) + NVL(AVG_FEEDBACK_M11, 0)) / NVL(NULLIF(NVL(SUM_I_FEEDBACK_M11, 0) + NVL(I_FEEDBACK_M, 0), 0), 1)) AS AVG_FEEDBACK_Y,
                NVL(MIN_FEEDBACK_M, 10) AS MIN_FEEDBACK_M,
                COALESCE(LEAST(MIN_FEEDBACK_M, MIN_FEEDBACK_M2), MIN_FEEDBACK_M, MIN_FEEDBACK_M2, 10) AS MIN_FEEDBACK_Q,
                COALESCE(LEAST(MIN_FEEDBACK_M, MIN_FEEDBACK_M11), MIN_FEEDBACK_M, MIN_FEEDBACK_M11, 10) AS MIN_FEEDBACK_Y,
                NVL(MAX_FEEDBACK_M, 10) AS MAX_FEEDBACK_M,
                COALESCE(GREATEST(MAX_FEEDBACK_M, MAX_FEEDBACK_M2), MAX_FEEDBACK_M, MAX_FEEDBACK_M2, 10) AS MAX_FEEDBACK_Q,
                COALESCE(GREATEST(MAX_FEEDBACK_M, MAX_FEEDBACK_M11), MAX_FEEDBACK_M, MAX_FEEDBACK_M11, 10) AS MAX_FEEDBACK_Y,
                NVL(C_FEEDBACK_M, 0) AS C_FEEDBACK_M,
                NVL(C_FEEDBACK_M, 0) + NVL(C_FEEDBACK_M2, 0) AS C_FEEDBACK_Q,
                NVL(C_FEEDBACK_M, 0) + NVL(C_FEEDBACK_M11, 0) AS C_FEEDBACK_Y,
                NVL(I_FEEDBACK_M, 0) AS I_FEEDBACK_M,
                GREATEST(NVL(I_FEEDBACK_M, 0), NVL(I_FEEDBACK_M2, 0)) AS I_FEEDBACK_Q,
                GREATEST(NVL(I_FEEDBACK_M, 0), NVL(I_FEEDBACK_M11, 0)) AS I_FEEDBACK_Y,
                COALESCE(RECENCY_FEEDBACK, RECENCY_FEEDBACK_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_FEEDBACK,
                NVL(C_SERVICE_REQUEST_M, 0) AS C_SERVICE_REQUEST_M,
                NVL(C_SERVICE_REQUEST_M, 0) + NVL(C_SERVICE_REQUEST_M2, 0) AS C_SERVICE_REQUEST_Q,
                NVL(C_SERVICE_REQUEST_M, 0) + NVL(C_SERVICE_REQUEST_M11, 0) AS C_SERVICE_REQUEST_Y,
                ROUND(DECODE(NVL(C_SERVICE_REQUEST_M, 0) + NVL(C_SERVICE_REQUEST_M2, 0), 0, 1/3, NVL(C_SERVICE_REQUEST_M, 0)/(NVL(C_SERVICE_REQUEST_M, 0) + NVL(C_SERVICE_REQUEST_M2, 0))), 2) AS RATIO_DELTA_C_SERVICE_REQUEST_MQ,
                ROUND(DECODE(NVL(C_SERVICE_REQUEST_M, 0) + NVL(C_SERVICE_REQUEST_M11, 0), 0, 1/12, NVL(C_SERVICE_REQUEST_M, 0)/(NVL(C_SERVICE_REQUEST_M, 0) + NVL(C_SERVICE_REQUEST_M11, 0))), 2) AS RATIO_DELTA_C_SERVICE_REQUEST_MY,
                NVL(I_SERVICE_REQUEST_M, 0) AS I_SERVICE_REQUEST_M,
                GREATEST(NVL(I_SERVICE_REQUEST_M, 0), NVL(I_SERVICE_REQUEST_M2, 0)) AS I_SERVICE_REQUEST_Q,
                GREATEST(NVL(I_SERVICE_REQUEST_M, 0), NVL(I_SERVICE_REQUEST_M11, 0)) AS I_SERVICE_REQUEST_Y,
                NVL(I_BRANCH_VISIT_SALE_M, 0) AS I_BRANCH_VISIT_SALE_M,
                GREATEST(NVL(I_BRANCH_VISIT_SALE_M, 0), NVL(I_BRANCH_VISIT_SALE_M2, 0)) AS I_BRANCH_VISIT_SALE_Q,
                GREATEST(NVL(I_BRANCH_VISIT_SALE_M, 0), NVL(I_BRANCH_VISIT_SALE_M11, 0)) AS I_BRANCH_VISIT_SALE_Y,
                NVL(I_BRANCH_VISIT_CARE_M, 0) AS I_BRANCH_VISIT_CARE_M,
                GREATEST(NVL(I_BRANCH_VISIT_CARE_M, 0), NVL(I_BRANCH_VISIT_CARE_M2, 0)) AS I_BRANCH_VISIT_CARE_Q,
                GREATEST(NVL(I_BRANCH_VISIT_CARE_M, 0), NVL(I_BRANCH_VISIT_CARE_M11, 0)) AS I_BRANCH_VISIT_CARE_Y,
                NVL(I_BRANCH_VISIT_INFORMATION_M, 0) AS I_BRANCH_VISIT_INFORMATION_M,
                GREATEST(NVL(I_BRANCH_VISIT_INFORMATION_M, 0), NVL(I_BRANCH_VISIT_INFORMATION_M2, 0)) AS I_BRANCH_VISIT_INFORMATION_Q,
                GREATEST(NVL(I_BRANCH_VISIT_INFORMATION_M, 0), NVL(I_BRANCH_VISIT_INFORMATION_M11, 0)) AS I_BRANCH_VISIT_INFORMATION_Y,
                NVL(I_BRANCH_VISIT_CASH_M, 0) AS I_BRANCH_VISIT_CASH_M,
                GREATEST(NVL(I_BRANCH_VISIT_CASH_M, 0), NVL(I_BRANCH_VISIT_CASH_M2, 0)) AS I_BRANCH_VISIT_CASH_Q,
                GREATEST(NVL(I_BRANCH_VISIT_CASH_M, 0), NVL(I_BRANCH_VISIT_CASH_M11, 0)) AS I_BRANCH_VISIT_CASH_Y,
                NVL(I_BRANCH_VISIT_OTHER_M, 0) AS I_BRANCH_VISIT_OTHER_M,
                GREATEST(NVL(I_BRANCH_VISIT_OTHER_M, 0), NVL(I_BRANCH_VISIT_OTHER_M2, 0)) AS I_BRANCH_VISIT_OTHER_Q,
                GREATEST(NVL(I_BRANCH_VISIT_OTHER_M, 0), NVL(I_BRANCH_VISIT_OTHER_M11, 0)) AS I_BRANCH_VISIT_OTHER_Y,
                NVL(C_BRANCH_VISIT_SALE_M, 0) AS C_BRANCH_VISIT_SALE_M,
                NVL(C_BRANCH_VISIT_SALE_M, 0) + NVL(C_BRANCH_VISIT_SALE_M2, 0) AS C_BRANCH_VISIT_SALE_Q,
                NVL(C_BRANCH_VISIT_SALE_M, 0) + NVL(C_BRANCH_VISIT_SALE_M11, 0) AS C_BRANCH_VISIT_SALE_Y,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_SALE_M, 0) + NVL(C_BRANCH_VISIT_SALE_M2, 0), 0, 1/3, NVL(C_BRANCH_VISIT_SALE_M, 0)/(NVL(C_BRANCH_VISIT_SALE_M, 0) + NVL(C_BRANCH_VISIT_SALE_M2, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_SALE_MQ,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_SALE_M, 0) + NVL(C_BRANCH_VISIT_SALE_M11, 0), 0, 1/12, NVL(C_BRANCH_VISIT_SALE_M, 0)/(NVL(C_BRANCH_VISIT_SALE_M, 0) + NVL(C_BRANCH_VISIT_SALE_M11, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_SALE_MY,
                NVL(C_BRANCH_VISIT_CARE_M, 0) AS C_BRANCH_VISIT_CARE_M,
                NVL(C_BRANCH_VISIT_CARE_M, 0) + NVL(C_BRANCH_VISIT_CARE_M2, 0) AS C_BRANCH_VISIT_CARE_Q,
                NVL(C_BRANCH_VISIT_CARE_M, 0) + NVL(C_BRANCH_VISIT_CARE_M11, 0) AS C_BRANCH_VISIT_CARE_Y,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_CARE_M, 0) + NVL(C_BRANCH_VISIT_CARE_M2, 0), 0, 1/3, NVL(C_BRANCH_VISIT_CARE_M, 0)/(NVL(C_BRANCH_VISIT_CARE_M, 0) + NVL(C_BRANCH_VISIT_CARE_M2, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_CARE_MQ,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_CARE_M, 0) + NVL(C_BRANCH_VISIT_CARE_M11, 0), 0, 1/12, NVL(C_BRANCH_VISIT_CARE_M, 0)/(NVL(C_BRANCH_VISIT_CARE_M, 0) + NVL(C_BRANCH_VISIT_CARE_M11, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_CARE_MY,
                NVL(C_BRANCH_VISIT_INFORMATION_M, 0) AS C_BRANCH_VISIT_INFORMATION_M,
                NVL(C_BRANCH_VISIT_INFORMATION_M, 0) + NVL(C_BRANCH_VISIT_INFORMATION_M2, 0) AS C_BRANCH_VISIT_INFORMATION_Q,
                NVL(C_BRANCH_VISIT_INFORMATION_M, 0) + NVL(C_BRANCH_VISIT_INFORMATION_M11, 0) AS C_BRANCH_VISIT_INFORMATION_Y,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_INFORMATION_M, 0) + NVL(C_BRANCH_VISIT_INFORMATION_M2, 0), 0, 1/3, NVL(C_BRANCH_VISIT_INFORMATION_M, 0)/(NVL(C_BRANCH_VISIT_INFORMATION_M, 0) + NVL(C_BRANCH_VISIT_INFORMATION_M2, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_INFORMATION_MQ,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_INFORMATION_M, 0) + NVL(C_BRANCH_VISIT_INFORMATION_M11, 0), 0, 1/12, NVL(C_BRANCH_VISIT_INFORMATION_M, 0)/(NVL(C_BRANCH_VISIT_INFORMATION_M, 0) + NVL(C_BRANCH_VISIT_INFORMATION_M11, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_INFORMATION_MY,
                NVL(C_BRANCH_VISIT_CASH_M, 0) AS C_BRANCH_VISIT_CASH_M,
                NVL(C_BRANCH_VISIT_CASH_M, 0) + NVL(C_BRANCH_VISIT_CASH_M2, 0) AS C_BRANCH_VISIT_CASH_Q,
                NVL(C_BRANCH_VISIT_CASH_M, 0) + NVL(C_BRANCH_VISIT_CASH_M11, 0) AS C_BRANCH_VISIT_CASH_Y,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_CASH_M, 0) + NVL(C_BRANCH_VISIT_CASH_M2, 0), 0, 1/3, NVL(C_BRANCH_VISIT_CASH_M, 0)/(NVL(C_BRANCH_VISIT_CASH_M, 0) + NVL(C_BRANCH_VISIT_CASH_M2, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_CASH_MQ,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_CASH_M, 0) + NVL(C_BRANCH_VISIT_CASH_M11, 0), 0, 1/12, NVL(C_BRANCH_VISIT_CASH_M, 0)/(NVL(C_BRANCH_VISIT_CASH_M, 0) + NVL(C_BRANCH_VISIT_CASH_M11, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_CASH_MY,
                NVL(C_BRANCH_VISIT_OTHER_M, 0) AS C_BRANCH_VISIT_OTHER_M,
                NVL(C_BRANCH_VISIT_OTHER_M, 0) + NVL(C_BRANCH_VISIT_OTHER_M2, 0) AS C_BRANCH_VISIT_OTHER_Q,
                NVL(C_BRANCH_VISIT_OTHER_M, 0) + NVL(C_BRANCH_VISIT_OTHER_M11, 0) AS C_BRANCH_VISIT_OTHER_Y,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_OTHER_M, 0) + NVL(C_BRANCH_VISIT_OTHER_M2, 0), 0, 1/3, NVL(C_BRANCH_VISIT_OTHER_M, 0)/(NVL(C_BRANCH_VISIT_OTHER_M, 0) + NVL(C_BRANCH_VISIT_OTHER_M2, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_OTHER_MQ,
                ROUND(DECODE(NVL(C_BRANCH_VISIT_OTHER_M, 0) + NVL(C_BRANCH_VISIT_OTHER_M11, 0), 0, 1/12, NVL(C_BRANCH_VISIT_OTHER_M, 0)/(NVL(C_BRANCH_VISIT_OTHER_M, 0) + NVL(C_BRANCH_VISIT_OTHER_M11, 0))), 2) AS RATIO_DELTA_C_BRANCH_VISIT_OTHER_MY,
                COALESCE(RECENCY_BRANCH_VISIT_SALE, RECENCY_BRANCH_VISIT_SALE_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_BRANCH_VISIT_SALE,
                COALESCE(RECENCY_BRANCH_VISIT_CARE, RECENCY_BRANCH_VISIT_CARE_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_BRANCH_VISIT_CARE,
                COALESCE(RECENCY_BRANCH_VISIT_INFORMATION, RECENCY_BRANCH_VISIT_INFORMATION_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_BRANCH_VISIT_INFORMATION,
                COALESCE(RECENCY_BRANCH_VISIT_CASH, RECENCY_BRANCH_VISIT_CASH_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_BRANCH_VISIT_CASH,
                COALESCE(RECENCY_BRANCH_VISIT_OTHER, RECENCY_BRANCH_VISIT_OTHER_PREV + process_dt - TRUNC(process_dt, 'MM') + 1, process_dt - process_dt_hist) AS RECENCY_BRANCH_VISIT_OTHER
            FROM ( -- main base
                        SELECT
                            base.month_id,
                            base.customerid,
                            base.bank_tenure,
                            LEAST(GREATEST(base.bank_tenure/(process_dt - ADD_MONTHS(process_dt, -3)),1)*3,
                                  COALESCE(int_q.c_month, 0)+1) c_month_q,
                            LEAST(GREATEST(base.bank_tenure/(process_dt - ADD_MONTHS(process_dt, -12)),1)*12,
                                  COALESCE(int_y.c_month, 0)+1) c_month_y       
                        FROM pm_owner.attr_client_base base
                        LEFT JOIN (
                            SELECT
                                customerid,
                                COUNT(DISTINCT month_id) c_month
                            FROM PM_OWNER.attr_interaction
                            WHERE month_id BETWEEN TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt,-2), 'YYYYMM'))
                                                AND TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt,-1), 'YYYYMM'))
                            GROUP BY customerid) int_q
                            ON int_q.customerid = base.customerid
    
                        LEFT JOIN (
                            SELECT
                                customerid,
                                COUNT(DISTINCT month_id) c_month
                            FROM PM_OWNER.attr_interaction
                            WHERE month_id BETWEEN TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt,-11), 'YYYYMM'))
                                                AND TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt,-1), 'YYYYMM'))
                            GROUP BY customerid) int_y
                            ON int_y.customerid = base.customerid                   
                        WHERE base.month_id = TO_NUMBER(TO_CHAR(process_dt, 'YYYYMM'))
                        ) main
    
            LEFT JOIN ( -- Aggregated call_centrum_history
                SELECT
                    customerid,
                    TO_NUMBER(TO_CHAR(event_dt, 'YYYYMM')) as month_id,
                    ROUND(AVG(DECODE(interaction_type, 'Inbound', EMAIL_DURATION))) AS AVG_INBOUND_EMAIL_DURATION_M,
                    ROUND(AVG(DECODE(interaction_type, 'Inbound', VOICE_DURATION))) AS AVG_INBOUND_VOICE_DURATION_M,
                    ROUND(AVG(DECODE(interaction_type, 'Outbound', EMAIL_DURATION))) AS AVG_OUTBOUND_EMAIL_DURATION_M,
                    ROUND(AVG(DECODE(interaction_type, 'Outbound', VOICE_DURATION))) AS AVG_OUTBOUND_VOICE_DURATION_M,
                    SUM(DECODE(interaction_type, 'Inbound', EMAIL_DURATION)) AS SUM_INBOUND_EMAIL_DURATION_M,
                    SUM(DECODE(interaction_type, 'Inbound', VOICE_DURATION)) AS SUM_INBOUND_VOICE_DURATION_M,
                    SUM(DECODE(interaction_type, 'Outbound', EMAIL_DURATION)) AS SUM_OUTBOUND_EMAIL_DURATION_M,
                    SUM(DECODE(interaction_type, 'Outbound', VOICE_DURATION)) AS SUM_OUTBOUND_VOICE_DURATION_M,
                    COUNT(I_INBOUND_EMAIL) AS C_INBOUND_EMAIL_M,
                    COUNT(I_INBOUND_VOICE) AS C_INBOUND_VOICE_M,
                    COUNT(I_OUTBOUND_EMAIL) AS C_OUTBOUND_EMAIL_M,
                    COUNT(I_OUTBOUND_VOICE) AS C_OUTBOUND_VOICE_M,
                    MAX(I_INBOUND_EMAIL) AS I_INBOUND_EMAIL_M,
                    MAX(I_INBOUND_VOICE) AS I_INBOUND_VOICE_M,
                    MAX(I_OUTBOUND_EMAIL) AS I_OUTBOUND_EMAIL_M,
                    MAX(I_OUTBOUND_VOICE) AS I_OUTBOUND_VOICE_M,
                    SUM(I_INBOUND_RESULT_COMPLETED) AS C_INBOUND_RESULT_COMPLETED_M,
                    SUM(I_INBOUND_RESULT_REDIRECTED) AS C_INBOUND_RESULT_REDIRECTED_M,
                    SUM(I_INBOUND_RESULT_CONFERENCED) AS C_INBOUND_RESULT_CONFERENCED_M,
                    SUM(I_INBOUND_RESULT_DIVERTED) AS C_INBOUND_RESULT_DIVERTED_M,
                    SUM(I_INBOUND_RESULT_ABANDONED) AS C_INBOUND_RESULT_ABANDONED_M,
                    SUM(I_INBOUND_RESULT_TRANSFERRED) AS C_INBOUND_RESULT_TRANSFERRED_M,
                    SUM(I_INBOUND_RESULT_DESTINATIONBUSY) AS C_INBOUND_RESULT_DESTINATIONBUSY_M,
                    SUM(I_INBOUND_RESULT_CUSTOMERABANDONED) AS C_INBOUND_RESULT_CUSTOMERABANDONED_M,
                    SUM(I_INBOUND_RESULT_ABNORMALSTOP) AS C_INBOUND_RESULT_ABNORMALSTOP_M,
                    SUM(I_OUTBOUND_RESULT_COMPLETED) AS C_OUTBOUND_RESULT_COMPLETED_M,
                    SUM(I_OUTBOUND_RESULT_REDIRECTED) AS C_OUTBOUND_RESULT_REDIRECTED_M,
                    SUM(I_OUTBOUND_RESULT_CONFERENCED) AS C_OUTBOUND_RESULT_CONFERENCED_M,
                    SUM(I_OUTBOUND_RESULT_DIVERTED) AS C_OUTBOUND_RESULT_DIVERTED_M,
                    SUM(I_OUTBOUND_RESULT_ABANDONED) AS C_OUTBOUND_RESULT_ABANDONED_M,
                    SUM(I_OUTBOUND_RESULT_TRANSFERRED) AS C_OUTBOUND_RESULT_TRANSFERRED_M,
                    SUM(I_OUTBOUND_RESULT_DESTINATIONBUSY) AS C_OUTBOUND_RESULT_DESTINATIONBUSY_M,
                    SUM(I_OUTBOUND_RESULT_CUSTOMERABANDONED) AS C_OUTBOUND_RESULT_CUSTOMERABANDONED_M,
                    SUM(I_OUTBOUND_RESULT_ABNORMALSTOP) AS C_OUTBOUND_RESULT_ABNORMALSTOP_M,
                    MAX(I_INBOUND_RESULT_COMPLETED) AS I_INBOUND_RESULT_COMPLETED_M,
                    MAX(I_INBOUND_RESULT_REDIRECTED) AS I_INBOUND_RESULT_REDIRECTED_M,
                    MAX(I_INBOUND_RESULT_CONFERENCED) AS I_INBOUND_RESULT_CONFERENCED_M,
                    MAX(I_INBOUND_RESULT_DIVERTED) AS I_INBOUND_RESULT_DIVERTED_M,
                    MAX(I_INBOUND_RESULT_ABANDONED) AS I_INBOUND_RESULT_ABANDONED_M,
                    MAX(I_INBOUND_RESULT_TRANSFERRED) AS I_INBOUND_RESULT_TRANSFERRED_M,
                    MAX(I_INBOUND_RESULT_DESTINATIONBUSY) AS I_INBOUND_RESULT_DESTINATIONBUSY_M,
                    MAX(I_INBOUND_RESULT_CUSTOMERABANDONED) AS I_INBOUND_RESULT_CUSTOMERABANDONED_M,
                    MAX(I_INBOUND_RESULT_ABNORMALSTOP) AS I_INBOUND_RESULT_ABNORMALSTOP_M,
                    MAX(I_OUTBOUND_RESULT_COMPLETED) AS I_OUTBOUND_RESULT_COMPLETED_M,
                    MAX(I_OUTBOUND_RESULT_REDIRECTED) AS I_OUTBOUND_RESULT_REDIRECTED_M,
                    MAX(I_OUTBOUND_RESULT_CONFERENCED) AS I_OUTBOUND_RESULT_CONFERENCED_M,
                    MAX(I_OUTBOUND_RESULT_DIVERTED) AS I_OUTBOUND_RESULT_DIVERTED_M,
                    MAX(I_OUTBOUND_RESULT_ABANDONED) AS I_OUTBOUND_RESULT_ABANDONED_M,
                    MAX(I_OUTBOUND_RESULT_TRANSFERRED) AS I_OUTBOUND_RESULT_TRANSFERRED_M,
                    MAX(I_OUTBOUND_RESULT_DESTINATIONBUSY) AS I_OUTBOUND_RESULT_DESTINATIONBUSY_M,
                    MAX(I_OUTBOUND_RESULT_CUSTOMERABANDONED) AS I_OUTBOUND_RESULT_CUSTOMERABANDONED_M,
                    MAX(I_OUTBOUND_RESULT_ABNORMALSTOP) AS I_OUTBOUND_RESULT_ABNORMALSTOP_M,
                    ROUND(SUM(DECODE(media_type, 'Voice', I_INBOUND_RESULT_COMPLETED))/SUM(I_INBOUND_VOICE), 2) AS RATIO_INBOUND_VOICE_COMPLETED_M,
                    ROUND(SUM(DECODE(media_type, 'Voice', I_INBOUND_RESULT_ABANDONED))/SUM(I_INBOUND_VOICE), 2) AS RATIO_INBOUND_VOICE_ABANDONED_M,
                    ROUND(SUM(DECODE(media_type, 'Voice', I_INBOUND_RESULT_CUSTOMERABANDONED))/SUM(I_INBOUND_VOICE), 2) AS RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M,
                    ROUND(SUM(DECODE(media_type, 'Voice', I_OUTBOUND_RESULT_COMPLETED))/SUM(I_OUTBOUND_VOICE), 2) AS RATIO_OUTBOUND_VOICE_COMPLETED_M,
                    ROUND(SUM(DECODE(media_type, 'Voice', I_OUTBOUND_RESULT_ABANDONED))/SUM(I_OUTBOUND_VOICE), 2) AS RATIO_OUTBOUND_VOICE_ABANDONED_M,
                    ROUND(SUM(DECODE(media_type, 'Voice', I_OUTBOUND_RESULT_CUSTOMERABANDONED))/SUM(I_OUTBOUND_VOICE), 2) AS RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M,
                    ROUND(SUM(I_INBOUND_EMAIL)/SUM(DECODE(media_type, 'Email', 1)), 2) AS RATIO_INBOUND_EMAIL_M,
                    ROUND(SUM(I_INBOUND_VOICE)/SUM(DECODE(media_type, 'Voice', 1)), 2) AS RATIO_INBOUND_VOICE_M,
                    MIN(process_dt + 1 - DECODE(I_INBOUND_EMAIL, 1, TRUNC(event_dt))) AS RECENCY_INBOUND_EMAIL,
                    MIN(process_dt + 1 - DECODE(I_INBOUND_VOICE, 1, TRUNC(event_dt))) AS RECENCY_INBOUND_VOICE,
                    MIN(process_dt + 1 - DECODE(I_OUTBOUND_EMAIL, 1, TRUNC(event_dt))) AS RECENCY_OUTBOUND_EMAIL,
                    MIN(process_dt + 1 - DECODE(I_OUTBOUND_VOICE, 1, TRUNC(event_dt))) AS RECENCY_OUTBOUND_VOICE
                FROM (
                    select 
                        cch.*,
                        DECODE(media_type, 'Email', total_duration) AS EMAIL_DURATION,
                        DECODE(media_type, 'Voice', total_duration) AS VOICE_DURATION,
                        DECODE(interaction_type, 'Inbound', DECODE(media_type, 'Email', 1)) AS I_INBOUND_EMAIL,
                        DECODE(interaction_type, 'Inbound', DECODE(media_type, 'Voice', 1)) AS I_INBOUND_VOICE,
                        DECODE(interaction_type, 'Outbound', DECODE(media_type, 'Email', 1)) AS I_OUTBOUND_EMAIL,
                        DECODE(interaction_type, 'Outbound', DECODE(media_type, 'Voice', 1)) AS I_OUTBOUND_VOICE,
                        DECODE(interaction_type, 'Inbound', I_RESULT_COMPLETED, 0) AS I_INBOUND_RESULT_COMPLETED,
                        DECODE(interaction_type, 'Inbound', I_RESULT_REDIRECTED, 0) AS I_INBOUND_RESULT_REDIRECTED,
                        DECODE(interaction_type, 'Inbound', I_RESULT_CONFERENCED, 0) AS I_INBOUND_RESULT_CONFERENCED,
                        DECODE(interaction_type, 'Inbound', I_RESULT_DIVERTED, 0) AS I_INBOUND_RESULT_DIVERTED,
                        DECODE(interaction_type, 'Inbound', I_RESULT_ABANDONED, 0) AS I_INBOUND_RESULT_ABANDONED,
                        DECODE(interaction_type, 'Inbound', I_RESULT_TRANSFERRED, 0) AS I_INBOUND_RESULT_TRANSFERRED,
                        DECODE(interaction_type, 'Inbound', I_RESULT_DESTINATIONBUSY, 0) AS I_INBOUND_RESULT_DESTINATIONBUSY,
                        DECODE(interaction_type, 'Inbound', I_RESULT_CUSTOMERABANDONED, 0) AS I_INBOUND_RESULT_CUSTOMERABANDONED,
                        DECODE(interaction_type, 'Inbound', I_RESULT_ABNORMALSTOP, 0) AS I_INBOUND_RESULT_ABNORMALSTOP,
                        DECODE(interaction_type, 'Outbound', I_RESULT_COMPLETED, 0) AS I_OUTBOUND_RESULT_COMPLETED,
                        DECODE(interaction_type, 'Outbound', I_RESULT_REDIRECTED, 0) AS I_OUTBOUND_RESULT_REDIRECTED,
                        DECODE(interaction_type, 'Outbound', I_RESULT_CONFERENCED, 0) AS I_OUTBOUND_RESULT_CONFERENCED,
                        DECODE(interaction_type, 'Outbound', I_RESULT_DIVERTED, 0) AS I_OUTBOUND_RESULT_DIVERTED,
                        DECODE(interaction_type, 'Outbound', I_RESULT_ABANDONED, 0) AS I_OUTBOUND_RESULT_ABANDONED,
                        DECODE(interaction_type, 'Outbound', I_RESULT_TRANSFERRED, 0) AS I_OUTBOUND_RESULT_TRANSFERRED,
                        DECODE(interaction_type, 'Outbound', I_RESULT_DESTINATIONBUSY, 0) AS I_OUTBOUND_RESULT_DESTINATIONBUSY,
                        DECODE(interaction_type, 'Outbound', I_RESULT_CUSTOMERABANDONED, 0) AS I_OUTBOUND_RESULT_CUSTOMERABANDONED,
                        DECODE(interaction_type, 'Outbound', I_RESULT_ABNORMALSTOP, 0) AS I_OUTBOUND_RESULT_ABNORMALSTOP
                    FROM PM_OWNER.call_centrum_history cch
                    WHERE event_dt >= ADD_MONTHS(process_dt + 1, -1)
                        AND event_dt < process_dt + 1
                ) group by customerid, TO_NUMBER(TO_CHAR(event_dt, 'YYYYMM'))
            ) cch ON main.customerid = cch.customerid
    
            LEFT JOIN ( -- Agregated feedbacks from surveys, NPS, branch visits
                SELECT
                    customerid,
                    TO_NUMBER(TO_CHAR(event_dt, 'YYYYMM')) as month_id,
                    ROUND(AVG(feedback), 2) AS AVG_FEEDBACK_M,
                    MIN(feedback) AS MIN_FEEDBACK_M,
                    MAX(feedback) AS MAX_FEEDBACK_M,
                    COUNT(feedback) AS C_FEEDBACK_M,
                    SIGN(COUNT(feedback)) AS I_FEEDBACK_M,        
                    process_dt + 1 - TRUNC(MAX(event_dt)) AS RECENCY_FEEDBACK,
                    NVL(SUM(i_service_request), 0) AS C_SERVICE_REQUEST_M,
                    SIGN(MAX(i_service_request)) AS I_SERVICE_REQUEST_M
    
                FROM PM_OWNER.feedback_evaluation
                WHERE event_dt >= ADD_MONTHS(process_dt + 1, -1)
                    AND event_dt < process_dt + 1
                GROUP BY customerid, TO_NUMBER(TO_CHAR(event_dt, 'YYYYMM'))
            ) fe ON main.customerid = fe.customerid
    
            LEFT JOIN ( -- Categorized branch visits purpose
                SELECT
                    customerid,
                    TO_NUMBER(TO_CHAR(event_dt, 'YYYYMM')) AS month_id,
                    LEAST(MAX(CATEGORY_SALE), 1) as I_BRANCH_VISIT_SALE_M,
                    LEAST(MAX(CATEGORY_CARE), 1) AS I_BRANCH_VISIT_CARE_M,
                    LEAST(MAX(CATEGORY_INFORMATION), 1) AS I_BRANCH_VISIT_INFORMATION_M,
                    LEAST(MAX(CATEGORY_CASH), 1) AS I_BRANCH_VISIT_CASH_M,
                    LEAST(MAX(CATEGORY_OTHER), 1) AS I_BRANCH_VISIT_OTHER_M,
                    SUM(CATEGORY_SALE) AS C_BRANCH_VISIT_SALE_M,
                    SUM(CATEGORY_CARE) AS C_BRANCH_VISIT_CARE_M,
                    SUM(CATEGORY_INFORMATION) AS C_BRANCH_VISIT_INFORMATION_M,
                    SUM(CATEGORY_CASH) AS C_BRANCH_VISIT_CASH_M,
                    SUM(CATEGORY_OTHER) AS C_BRANCH_VISIT_OTHER_M,
                    process_dt + 1 - MAX(DECODE(CATEGORY_SALE, 1, TRUNC(event_dt))) AS RECENCY_BRANCH_VISIT_SALE,
                    process_dt + 1 - MAX(DECODE(CATEGORY_CARE, 1, TRUNC(event_dt))) AS RECENCY_BRANCH_VISIT_CARE,
                    process_dt + 1 - MAX(DECODE(CATEGORY_INFORMATION, 1, TRUNC(event_dt))) AS RECENCY_BRANCH_VISIT_INFORMATION,
                    process_dt + 1 - MAX(DECODE(CATEGORY_CASH, 1, TRUNC(event_dt))) AS RECENCY_BRANCH_VISIT_CASH,
                    process_dt + 1 - MAX(DECODE(CATEGORY_OTHER, 1, TRUNC(event_dt))) AS RECENCY_BRANCH_VISIT_OTHER
                 FROM(
                    SELECT
                        customerid,
                        event_dt,
                        LEAST(MAX(CATEGORY_SALE), 1) CATEGORY_SALE,
                        LEAST(MAX(CATEGORY_CARE), 1) CATEGORY_CARE,
                        LEAST(MAX(CATEGORY_INFORMATION), 1) CATEGORY_INFORMATION,
                        LEAST(MAX(CATEGORY_CASH), 1) CATEGORY_CASH,
                        LEAST(MAX(CATEGORY_OTHER), 1) CATEGORY_OTHER
    
                    FROM (
                        -- Scube sessions
                        select
                            PR.party_id customerid,
                            scl.event_log_date event_dt,
                            0 CATEGORY_SALE,
                            0 CATEGORY_CARE,
                            0 CATEGORY_INFORMATION,
                            0 CATEGORY_CASH,
                            1 CATEGORY_OTHER
    
                        FROM l0_owner.scl_identif_log scl
    
                        JOIN L0_OWNER.PARTY P
                            ON P.party_src_val = to_char(scl.cuid)
                            AND	P.src_syst_cd = 110
                            AND	P.party_src_key LIKE 'PMC%'
    
                        JOIN L0_OWNER.PARTY_RLTD PR
                            ON  PR.child_party_id = P.party_id
                            AND PR.party_rltd_rsn_cd = 4
                            AND PR.party_rltd_start_dt < process_dt + 1 
                            AND PR.party_rltd_end_dt >= ADD_MONTHS(process_dt + 1, -1)
    
                        where 1 = 1
                            -- time horizont
                            and scl.event_log_date >= ADD_MONTHS(process_dt + 1, -1)
                            AND scl.event_log_date < process_dt + 1
                            and scl.device_type_id in (1,2)   
                            and scl.cuid is not null
    
                        UNION ALL
    
                        -- crm sessions
                        SELECT
                            CCDB.CUSTOMERID,
                            CAST(E.DT_BUS_EFF_FROM AS DATE) EVENT_DT,
    
                            CASE WHEN E.CD_REC_VALUE_PROPERTY_1='100' THEN 1 ELSE 0 END CATEGORY_SALE,
                            CASE WHEN E.CD_REC_VALUE_PROPERTY_1='200' THEN 1 ELSE 0 END CATEGORY_CARE,
                            CASE WHEN E.CD_REC_VALUE_PROPERTY_1='300' THEN 1 ELSE 0 END CATEGORY_INFORMATION,
                            CASE WHEN E.CD_REC_VALUE_PROPERTY_1='400' THEN 1 ELSE 0 END CATEGORY_CASH,
                            CASE WHEN E.CD_REC_VALUE_PROPERTY_1='500' THEN 1 ELSE 0 END CATEGORY_OTHER
    
                        from CCDB_OWNER.OH_W_EVENT E 
    
                        --dotiahnutie klienta
                        JOIN CCDB_OWNER.OH_W_PARTY P
                        on P.cd_rec_party = E.cd_rec_party_1 
                            and P.cd_rec_source = 'CCDB.CRM'
                            and P.cd_rec_object_type = E.cd_rec_party_1_object_type 
                            and P.party_end_dt = date '9999-12-31'
                            AND P.DELETED_DT   = date '9999-12-31'
    
                        --doplnenie CUID/CUSTOMERID
                        LEFT JOIN (
                            SELECT CCDB_ID, CUSTOMERID 
                                    ,PARTY_PARTY_START_DT
                                    ,PARTY_PARTY_END_DT 
                                FROM (
                                SELECT
                                    pp.cd_rec_party_1 as CCDB_ID,
                                    TO_NUMBER(CASE WHEN pp.cd_rec_party_2_source='1' THEN P.party_id  ELSE NULL END) as CUSTOMERID, --1 - CDS
                                    ROW_NUMBER() OVER (PARTITION BY TO_NUMBER(CASE WHEN pp.cd_rec_party_2_source='1' THEN P.party_id  ELSE NULL END) ORDER BY dt_bus_eff_from desc, pp.cd_rec_party_1) row_num
                                    ,PP.PARTY_PARTY_START_DT
                                    ,PP.PARTY_PARTY_END_DT
                                FROM CCDB_OWNER.oh_w_party_party PP
    
                                LEFT JOIN L0_OWNER.PARTY P
                                    ON P.party_src_key=pp.cd_rec_party_2
                                    AND pp.cd_rec_party_2_source='1'
                                    AND P.SRC_SYST_CD=1
    
                                where 1=1
                                    and trim(TRANSLATE(PP.cd_rec_party_1, '0123456789-,.', ' ')) is null
                                    and PP.PARTY_PARTY_START_DT < process_dt + 1
                                    and PP.PARTY_PARTY_END_DT >= ADD_MONTHS(process_dt + 1, -1)
                                    and PP.cd_rec_relation_type = 'PARTY_INSTANCE'
                                    and pp.cd_rec_relation_type_source = 'CCDB'
                                    and pp.cd_rec_source = 'CCDB'
                                    and pp.cd_rec_party_1_source = 'CCDB.CRM'
                                    and TO_NUMBER(CASE WHEN pp.cd_rec_party_2_source='1' THEN P.party_id  ELSE NULL END) is not null)
                            WHERE row_num = 1) CCDB
                            ON CCDB.CCDB_ID=P.CD_REC_PARTY
                                and CCDB.PARTY_PARTY_START_DT <= E.DT_BUS_EFF_FROM
                                and CCDB.PARTY_PARTY_END_DT > E.DT_BUS_EFF_FROM  
    
                        where 1=1
                            AND E.CD_REC_VALUE_PROPERTY_2 <> 'XNA'
                            AND E.CD_REC_VALUE_PROPERTY_2 is not null
                            AND CAST(E.DT_BUS_EFF_FROM AS DATE) >= ADD_MONTHS(process_dt + 1, -1)
                            AND CAST(E.DT_BUS_EFF_FROM AS DATE) < process_dt + 1
                            AND E.event_end_dt = date '9999-12-31'
                            AND E.cd_rec_source = 'CCDB.CRM'
                            AND E.cd_rec_object_type='OBJECT~EVENT~SESSION'
                            and CCDB.CUSTOMERID is not null
                    ) GROUP BY customerid, event_dt
                ) GROUP BY customerid, TO_NUMBER(TO_CHAR(event_dt, 'YYYYMM'))
            ) bv ON main.customerid = bv.customerid
    
            LEFT JOIN ( -- Data for month_id between M-1 and M-2
                SELECT
                    customerid,
                    AVG(AVG_INBOUND_EMAIL_DURATION_M) AS AVG_INBOUND_EMAIL_DURATION_M2,
                    AVG(AVG_INBOUND_VOICE_DURATION_M) AS AVG_INBOUND_VOICE_DURATION_M2,
                    AVG(AVG_OUTBOUND_EMAIL_DURATION_M) AS AVG_OUTBOUND_EMAIL_DURATION_M2,
                    AVG(AVG_OUTBOUND_VOICE_DURATION_M) AS AVG_OUTBOUND_VOICE_DURATION_M2,
                    SUM(SUM_INBOUND_EMAIL_DURATION_M) AS SUM_INBOUND_EMAIL_DURATION_M2,
                    SUM(SUM_INBOUND_VOICE_DURATION_M) AS SUM_INBOUND_VOICE_DURATION_M2,
                    SUM(SUM_OUTBOUND_EMAIL_DURATION_M) AS SUM_OUTBOUND_EMAIL_DURATION_M2,
                    SUM(SUM_OUTBOUND_VOICE_DURATION_M) AS SUM_OUTBOUND_VOICE_DURATION_M2,
                    SUM(C_INBOUND_EMAIL_M) AS C_INBOUND_EMAIL_M2,
                    SUM(C_INBOUND_VOICE_M) AS C_INBOUND_VOICE_M2,
                    SUM(C_OUTBOUND_EMAIL_M) AS C_OUTBOUND_EMAIL_M2,
                    SUM(C_OUTBOUND_VOICE_M) AS C_OUTBOUND_VOICE_M2,
                    MAX(I_INBOUND_EMAIL_M) AS I_INBOUND_EMAIL_M2,
                    MAX(I_INBOUND_VOICE_M) AS I_INBOUND_VOICE_M2,
                    MAX(I_OUTBOUND_EMAIL_M) AS I_OUTBOUND_EMAIL_M2,
                    MAX(I_OUTBOUND_VOICE_M) AS I_OUTBOUND_VOICE_M2,
                    SUM(C_INBOUND_RESULT_COMPLETED_M) AS C_INBOUND_RESULT_COMPLETED_M2,
                    SUM(C_INBOUND_RESULT_REDIRECTED_M) AS C_INBOUND_RESULT_REDIRECTED_M2,
                    SUM(C_INBOUND_RESULT_CONFERENCED_M) AS C_INBOUND_RESULT_CONFERENCED_M2,
                    SUM(C_INBOUND_RESULT_DIVERTED_M) AS C_INBOUND_RESULT_DIVERTED_M2,
                    SUM(C_INBOUND_RESULT_ABANDONED_M) AS C_INBOUND_RESULT_ABANDONED_M2,
                    SUM(C_INBOUND_RESULT_TRANSFERRED_M) AS C_INBOUND_RESULT_TRANSFERRED_M2,
                    SUM(C_INBOUND_RESULT_DESTINATIONBUSY_M) AS C_INBOUND_RESULT_DESTINATIONBUSY_M2,
                    SUM(C_INBOUND_RESULT_CUSTOMERABANDONED_M) AS C_INBOUND_RESULT_CUSTOMERABANDONED_M2,
                    SUM(C_INBOUND_RESULT_ABNORMALSTOP_M) AS C_INBOUND_RESULT_ABNORMALSTOP_M2,
                    SUM(C_OUTBOUND_RESULT_COMPLETED_M) AS C_OUTBOUND_RESULT_COMPLETED_M2,
                    SUM(C_OUTBOUND_RESULT_REDIRECTED_M) AS C_OUTBOUND_RESULT_REDIRECTED_M2,
                    SUM(C_OUTBOUND_RESULT_CONFERENCED_M) AS C_OUTBOUND_RESULT_CONFERENCED_M2,
                    SUM(C_OUTBOUND_RESULT_DIVERTED_M) AS C_OUTBOUND_RESULT_DIVERTED_M2,
                    SUM(C_OUTBOUND_RESULT_ABANDONED_M) AS C_OUTBOUND_RESULT_ABANDONED_M2,
                    SUM(C_OUTBOUND_RESULT_TRANSFERRED_M) AS C_OUTBOUND_RESULT_TRANSFERRED_M2,
                    SUM(C_OUTBOUND_RESULT_DESTINATIONBUSY_M) AS C_OUTBOUND_RESULT_DESTINATIONBUSY_M2,
                    SUM(C_OUTBOUND_RESULT_CUSTOMERABANDONED_M) AS C_OUTBOUND_RESULT_CUSTOMERABANDONED_M2,
                    SUM(C_OUTBOUND_RESULT_ABNORMALSTOP_M) AS C_OUTBOUND_RESULT_ABNORMALSTOP_M2,
                    MAX(I_INBOUND_RESULT_COMPLETED_M) AS I_INBOUND_RESULT_COMPLETED_M2,
                    MAX(I_INBOUND_RESULT_REDIRECTED_M) AS I_INBOUND_RESULT_REDIRECTED_M2,
                    MAX(I_INBOUND_RESULT_CONFERENCED_M) AS I_INBOUND_RESULT_CONFERENCED_M2,
                    MAX(I_INBOUND_RESULT_DIVERTED_M) AS I_INBOUND_RESULT_DIVERTED_M2,
                    MAX(I_INBOUND_RESULT_ABANDONED_M) AS I_INBOUND_RESULT_ABANDONED_M2,
                    MAX(I_INBOUND_RESULT_TRANSFERRED_M) AS I_INBOUND_RESULT_TRANSFERRED_M2,
                    MAX(I_INBOUND_RESULT_DESTINATIONBUSY_M) AS I_INBOUND_RESULT_DESTINATIONBUSY_M2,
                    MAX(I_INBOUND_RESULT_CUSTOMERABANDONED_M) AS I_INBOUND_RESULT_CUSTOMERABANDONED_M2,
                    MAX(I_INBOUND_RESULT_ABNORMALSTOP_M) AS I_INBOUND_RESULT_ABNORMALSTOP_M2,
                    MAX(I_OUTBOUND_RESULT_COMPLETED_M) AS I_OUTBOUND_RESULT_COMPLETED_M2,
                    MAX(I_OUTBOUND_RESULT_REDIRECTED_M) AS I_OUTBOUND_RESULT_REDIRECTED_M2,
                    MAX(I_OUTBOUND_RESULT_CONFERENCED_M) AS I_OUTBOUND_RESULT_CONFERENCED_M2,
                    MAX(I_OUTBOUND_RESULT_DIVERTED_M) AS I_OUTBOUND_RESULT_DIVERTED_M2,
                    MAX(I_OUTBOUND_RESULT_ABANDONED_M) AS I_OUTBOUND_RESULT_ABANDONED_M2,
                    MAX(I_OUTBOUND_RESULT_TRANSFERRED_M) AS I_OUTBOUND_RESULT_TRANSFERRED_M2,
                    MAX(I_OUTBOUND_RESULT_DESTINATIONBUSY_M) AS I_OUTBOUND_RESULT_DESTINATIONBUSY_M2,
                    MAX(I_OUTBOUND_RESULT_CUSTOMERABANDONED_M) AS I_OUTBOUND_RESULT_CUSTOMERABANDONED_M2,
                    MAX(I_OUTBOUND_RESULT_ABNORMALSTOP_M) AS I_OUTBOUND_RESULT_ABNORMALSTOP_M2,
                    AVG(RATIO_INBOUND_VOICE_COMPLETED_M) AS RATIO_INBOUND_VOICE_COMPLETED_M2,
                    AVG(RATIO_INBOUND_VOICE_ABANDONED_M) AS RATIO_INBOUND_VOICE_ABANDONED_M2,
                    AVG(RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M) AS RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M2,
                    AVG(RATIO_OUTBOUND_VOICE_COMPLETED_M) AS RATIO_OUTBOUND_VOICE_COMPLETED_M2,
                    AVG(RATIO_OUTBOUND_VOICE_ABANDONED_M) AS RATIO_OUTBOUND_VOICE_ABANDONED_M2,
                    AVG(RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M) AS RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M2,
                    AVG(RATIO_INBOUND_EMAIL_M) AS RATIO_INBOUND_EMAIL_M2,
                    AVG(RATIO_INBOUND_VOICE_M) AS RATIO_INBOUND_VOICE_M2,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_INBOUND_EMAIL / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_INBOUND_EMAIL END)) AS RECENCY_INBOUND_EMAIL_PREV,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_INBOUND_VOICE / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_INBOUND_VOICE END)) AS RECENCY_INBOUND_VOICE_PREV,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_OUTBOUND_EMAIL / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_OUTBOUND_EMAIL END)) AS RECENCY_OUTBOUND_EMAIL_PREV,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_OUTBOUND_VOICE / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_OUTBOUND_VOICE END)) AS RECENCY_OUTBOUND_VOICE_PREV,
                    AVG(DECODE(I_FEEDBACK_M, 1, AVG_FEEDBACK_M)) * SUM(I_FEEDBACK_M) AS AVG_FEEDBACK_M2,
                    MIN(MIN_FEEDBACK_M) AS MIN_FEEDBACK_M2,
                    MAX(MAX_FEEDBACK_M) AS MAX_FEEDBACK_M2,
                    SUM(C_FEEDBACK_M) AS C_FEEDBACK_M2,
                    MAX(I_FEEDBACK_M) AS I_FEEDBACK_M2,
                    SUM(I_FEEDBACK_M) AS SUM_I_FEEDBACK_M2,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_FEEDBACK / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_FEEDBACK END)) AS RECENCY_FEEDBACK_PREV,
                    SUM(C_SERVICE_REQUEST_M) AS C_SERVICE_REQUEST_M2,
                    MAX(I_SERVICE_REQUEST_M) AS I_SERVICE_REQUEST_M2,
                    MAX(I_BRANCH_VISIT_SALE_M) AS I_BRANCH_VISIT_SALE_M2,
                    MAX(I_BRANCH_VISIT_CARE_M) AS I_BRANCH_VISIT_CARE_M2,
                    MAX(I_BRANCH_VISIT_INFORMATION_M) AS I_BRANCH_VISIT_INFORMATION_M2,
                    MAX(I_BRANCH_VISIT_CASH_M) AS I_BRANCH_VISIT_CASH_M2,
                    MAX(I_BRANCH_VISIT_OTHER_M) AS I_BRANCH_VISIT_OTHER_M2,
                    SUM(C_BRANCH_VISIT_SALE_M) AS C_BRANCH_VISIT_SALE_M2,
                    SUM(C_BRANCH_VISIT_CARE_M) AS C_BRANCH_VISIT_CARE_M2,
                    SUM(C_BRANCH_VISIT_INFORMATION_M) AS C_BRANCH_VISIT_INFORMATION_M2,
                    SUM(C_BRANCH_VISIT_CASH_M) AS C_BRANCH_VISIT_CASH_M2,
                    SUM(C_BRANCH_VISIT_OTHER_M) AS C_BRANCH_VISIT_OTHER_M2,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_BRANCH_VISIT_SALE / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_BRANCH_VISIT_SALE END)) AS RECENCY_BRANCH_VISIT_SALE_PREV,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_BRANCH_VISIT_CARE / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_BRANCH_VISIT_CARE END)) AS RECENCY_BRANCH_VISIT_CARE_PREV,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_BRANCH_VISIT_INFORMATION / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_BRANCH_VISIT_INFORMATION END)) AS RECENCY_BRANCH_VISIT_INFORMATION_PREV,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_BRANCH_VISIT_CASH / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_BRANCH_VISIT_CASH END)) AS RECENCY_BRANCH_VISIT_CASH_PREV,
                    MIN(DECODE(month_id, TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM')), CASE WHEN RECENCY_BRANCH_VISIT_OTHER / (process_dt - process_dt_hist) < 0.9 THEN RECENCY_BRANCH_VISIT_OTHER END)) AS RECENCY_BRANCH_VISIT_OTHER_PREV
                FROM PM_OWNER.attr_interaction
                WHERE month_id BETWEEN TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -2), 'YYYYMM')) AND TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM'))
                GROUP BY customerid
            ) int_q ON main.customerid = int_q.customerid
    
            LEFT JOIN ( -- Data for month_id between M-1 and M-11
                SELECT
                    customerid,
                    AVG(AVG_INBOUND_EMAIL_DURATION_M) AS AVG_INBOUND_EMAIL_DURATION_M11,
                    AVG(AVG_INBOUND_VOICE_DURATION_M) AS AVG_INBOUND_VOICE_DURATION_M11,
                    AVG(AVG_OUTBOUND_EMAIL_DURATION_M) AS AVG_OUTBOUND_EMAIL_DURATION_M11,
                    AVG(AVG_OUTBOUND_VOICE_DURATION_M) AS AVG_OUTBOUND_VOICE_DURATION_M11,
                    SUM(SUM_INBOUND_EMAIL_DURATION_M) AS SUM_INBOUND_EMAIL_DURATION_M11,
                    SUM(SUM_INBOUND_VOICE_DURATION_M) AS SUM_INBOUND_VOICE_DURATION_M11,
                    SUM(SUM_OUTBOUND_EMAIL_DURATION_M) AS SUM_OUTBOUND_EMAIL_DURATION_M11,
                    SUM(SUM_OUTBOUND_VOICE_DURATION_M) AS SUM_OUTBOUND_VOICE_DURATION_M11,
                    SUM(C_INBOUND_EMAIL_M) AS C_INBOUND_EMAIL_M11,
                    SUM(C_INBOUND_VOICE_M) AS C_INBOUND_VOICE_M11,
                    SUM(C_OUTBOUND_EMAIL_M) AS C_OUTBOUND_EMAIL_M11,
                    SUM(C_OUTBOUND_VOICE_M) AS C_OUTBOUND_VOICE_M11,
                    MAX(I_INBOUND_EMAIL_M) AS I_INBOUND_EMAIL_M11,
                    MAX(I_INBOUND_VOICE_M) AS I_INBOUND_VOICE_M11,
                    MAX(I_OUTBOUND_EMAIL_M) AS I_OUTBOUND_EMAIL_M11,
                    MAX(I_OUTBOUND_VOICE_M) AS I_OUTBOUND_VOICE_M11,
                    SUM(C_INBOUND_RESULT_COMPLETED_M) AS C_INBOUND_RESULT_COMPLETED_M11,
                    SUM(C_INBOUND_RESULT_REDIRECTED_M) AS C_INBOUND_RESULT_REDIRECTED_M11,
                    SUM(C_INBOUND_RESULT_CONFERENCED_M) AS C_INBOUND_RESULT_CONFERENCED_M11,
                    SUM(C_INBOUND_RESULT_DIVERTED_M) AS C_INBOUND_RESULT_DIVERTED_M11,
                    SUM(C_INBOUND_RESULT_ABANDONED_M) AS C_INBOUND_RESULT_ABANDONED_M11,
                    SUM(C_INBOUND_RESULT_TRANSFERRED_M) AS C_INBOUND_RESULT_TRANSFERRED_M11,
                    SUM(C_INBOUND_RESULT_DESTINATIONBUSY_M) AS C_INBOUND_RESULT_DESTINATIONBUSY_M11,
                    SUM(C_INBOUND_RESULT_CUSTOMERABANDONED_M) AS C_INBOUND_RESULT_CUSTOMERABANDONED_M11,
                    SUM(C_INBOUND_RESULT_ABNORMALSTOP_M) AS C_INBOUND_RESULT_ABNORMALSTOP_M11,
                    SUM(C_OUTBOUND_RESULT_COMPLETED_M) AS C_OUTBOUND_RESULT_COMPLETED_M11,
                    SUM(C_OUTBOUND_RESULT_REDIRECTED_M) AS C_OUTBOUND_RESULT_REDIRECTED_M11,
                    SUM(C_OUTBOUND_RESULT_CONFERENCED_M) AS C_OUTBOUND_RESULT_CONFERENCED_M11,
                    SUM(C_OUTBOUND_RESULT_DIVERTED_M) AS C_OUTBOUND_RESULT_DIVERTED_M11,
                    SUM(C_OUTBOUND_RESULT_ABANDONED_M) AS C_OUTBOUND_RESULT_ABANDONED_M11,
                    SUM(C_OUTBOUND_RESULT_TRANSFERRED_M) AS C_OUTBOUND_RESULT_TRANSFERRED_M11,
                    SUM(C_OUTBOUND_RESULT_DESTINATIONBUSY_M) AS C_OUTBOUND_RESULT_DESTINATIONBUSY_M11,
                    SUM(C_OUTBOUND_RESULT_CUSTOMERABANDONED_M) AS C_OUTBOUND_RESULT_CUSTOMERABANDONED_M11,
                    SUM(C_OUTBOUND_RESULT_ABNORMALSTOP_M) AS C_OUTBOUND_RESULT_ABNORMALSTOP_M11,
                    MAX(I_INBOUND_RESULT_COMPLETED_M) AS I_INBOUND_RESULT_COMPLETED_M11,
                    MAX(I_INBOUND_RESULT_REDIRECTED_M) AS I_INBOUND_RESULT_REDIRECTED_M11,
                    MAX(I_INBOUND_RESULT_CONFERENCED_M) AS I_INBOUND_RESULT_CONFERENCED_M11,
                    MAX(I_INBOUND_RESULT_DIVERTED_M) AS I_INBOUND_RESULT_DIVERTED_M11,
                    MAX(I_INBOUND_RESULT_ABANDONED_M) AS I_INBOUND_RESULT_ABANDONED_M11,
                    MAX(I_INBOUND_RESULT_TRANSFERRED_M) AS I_INBOUND_RESULT_TRANSFERRED_M11,
                    MAX(I_INBOUND_RESULT_DESTINATIONBUSY_M) AS I_INBOUND_RESULT_DESTINATIONBUSY_M11,
                    MAX(I_INBOUND_RESULT_CUSTOMERABANDONED_M) AS I_INBOUND_RESULT_CUSTOMERABANDONED_M11,
                    MAX(I_INBOUND_RESULT_ABNORMALSTOP_M) AS I_INBOUND_RESULT_ABNORMALSTOP_M11,
                    MAX(I_OUTBOUND_RESULT_COMPLETED_M) AS I_OUTBOUND_RESULT_COMPLETED_M11,
                    MAX(I_OUTBOUND_RESULT_REDIRECTED_M) AS I_OUTBOUND_RESULT_REDIRECTED_M11,
                    MAX(I_OUTBOUND_RESULT_CONFERENCED_M) AS I_OUTBOUND_RESULT_CONFERENCED_M11,
                    MAX(I_OUTBOUND_RESULT_DIVERTED_M) AS I_OUTBOUND_RESULT_DIVERTED_M11,
                    MAX(I_OUTBOUND_RESULT_ABANDONED_M) AS I_OUTBOUND_RESULT_ABANDONED_M11,
                    MAX(I_OUTBOUND_RESULT_TRANSFERRED_M) AS I_OUTBOUND_RESULT_TRANSFERRED_M11,
                    MAX(I_OUTBOUND_RESULT_DESTINATIONBUSY_M) AS I_OUTBOUND_RESULT_DESTINATIONBUSY_M11,
                    MAX(I_OUTBOUND_RESULT_CUSTOMERABANDONED_M) AS I_OUTBOUND_RESULT_CUSTOMERABANDONED_M11,
                    MAX(I_OUTBOUND_RESULT_ABNORMALSTOP_M) AS I_OUTBOUND_RESULT_ABNORMALSTOP_M11,
                    AVG(RATIO_INBOUND_VOICE_COMPLETED_M) AS RATIO_INBOUND_VOICE_COMPLETED_M11,
                    AVG(RATIO_INBOUND_VOICE_ABANDONED_M) AS RATIO_INBOUND_VOICE_ABANDONED_M11,
                    AVG(RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M) AS RATIO_INBOUND_VOICE_CUSTOMERABANDONED_M11,
                    AVG(RATIO_OUTBOUND_VOICE_COMPLETED_M) AS RATIO_OUTBOUND_VOICE_COMPLETED_M11,
                    AVG(RATIO_OUTBOUND_VOICE_ABANDONED_M) AS RATIO_OUTBOUND_VOICE_ABANDONED_M11,
                    AVG(RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M) AS RATIO_OUTBOUND_VOICE_CUSTOMERABANDONED_M11,
                    AVG(RATIO_INBOUND_EMAIL_M) AS RATIO_INBOUND_EMAIL_M11,
                    AVG(RATIO_INBOUND_VOICE_M) AS RATIO_INBOUND_VOICE_M11,
                    AVG(DECODE(I_FEEDBACK_M, 1, AVG_FEEDBACK_M)) * SUM(I_FEEDBACK_M) AS AVG_FEEDBACK_M11,
                    MIN(MIN_FEEDBACK_M) AS MIN_FEEDBACK_M11,
                    MAX(MAX_FEEDBACK_M) AS MAX_FEEDBACK_M11,
                    SUM(C_FEEDBACK_M) AS C_FEEDBACK_M11,
                    MAX(I_FEEDBACK_M) AS I_FEEDBACK_M11,
                    SUM(I_FEEDBACK_M) AS SUM_I_FEEDBACK_M11,
                    SUM(C_SERVICE_REQUEST_M) AS C_SERVICE_REQUEST_M11,
                    MAX(I_SERVICE_REQUEST_M) AS I_SERVICE_REQUEST_M11,
                    MAX(I_BRANCH_VISIT_SALE_M) AS I_BRANCH_VISIT_SALE_M11,
                    MAX(I_BRANCH_VISIT_CARE_M) AS I_BRANCH_VISIT_CARE_M11,
                    MAX(I_BRANCH_VISIT_INFORMATION_M) AS I_BRANCH_VISIT_INFORMATION_M11,
                    MAX(I_BRANCH_VISIT_CASH_M) AS I_BRANCH_VISIT_CASH_M11,
                    MAX(I_BRANCH_VISIT_OTHER_M) AS I_BRANCH_VISIT_OTHER_M11,
                    SUM(C_BRANCH_VISIT_SALE_M) AS C_BRANCH_VISIT_SALE_M11,
                    SUM(C_BRANCH_VISIT_CARE_M) AS C_BRANCH_VISIT_CARE_M11,
                    SUM(C_BRANCH_VISIT_INFORMATION_M) AS C_BRANCH_VISIT_INFORMATION_M11,
                    SUM(C_BRANCH_VISIT_CASH_M) AS C_BRANCH_VISIT_CASH_M11,
                    SUM(C_BRANCH_VISIT_OTHER_M) AS C_BRANCH_VISIT_OTHER_M11
                FROM PM_OWNER.attr_interaction
                WHERE month_id BETWEEN TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -11), 'YYYYMM')) AND TO_NUMBER(TO_CHAR(ADD_MONTHS(process_dt, -1), 'YYYYMM'))
                GROUP BY customerid
            ) int_y ON main.customerid = int_y.customerid
            --WHERE COALESCE(cch.customerid, fe.customerid, bv.customerid) IS NOT NULL
        )
    """)

    return df_attr_interaction