from q1g_common.pipelines.csob_pipeline import CSOBPipeline
from attr_interaction.pipelines.transformations import transform

sources_master = {
    'ccdb__dh__s_ccd_party': [],
    'ccdb__dh__s_ccd_party_contact': [],
    'ccdb__oh__w_event': [],
    'ccdb__oh__w_event_tick': [], 
    'ccdb__oh__w_party': [],
    'ccdb__oh__w_party_party': [],
    'ccdb__oh__w_service_request_fact_tick': [],
    'dmsk__l0_owner__call_centrum_log': [], 
    'dmsk__l0_owner__contct_type_gen': [],
    'dmsk__l0_owner__party': [],
    'dmsk__l0_owner__party_rltd': [],
    'dmsk__l0_owner__scl_identif_log': [],
    'dmsk__unica_owner__c_008827_clf356_netquest': [],
    'dmsk__unica_owner__unica_list_int_dial_codes': []
}
sources_feature = {
    'attr_client_base': [],
    'dmsk__pm_owner__c_001367_ret484_netquest': [],
    'dmsk__pm_owner__call_centrum_history': [],
    'dmsk__pm_owner__call_centrum_log': [], 
    'dmsk__pm_owner__customer_contact': []
}
sources = {
    'feature': sources_feature,
    'master': sources_master
}


tkn_policies = {}


class AttrInteraction(CSOBPipeline):

    def get_initial_configuration(self):
        self.modelling_date = self.business_date
        # l_month_start_dt    date  := trunc(process_dt,'MM');
        # l_month_end_dt      date  := last_day(process_dt);
        # --Date of initial load, necessary for computation of complete CUSTOMER_CONTACT
        # initial_load_dt		date  := DATE '2019-01-01'; 
        # -- Only contacts started from this date are included
        # min_contct_start    date  := DATE '2005-01-01';
        return sources, tkn_policies

    def transform_sources(self, sources_df: dict) -> DataFrame:
        final_df = transform(sources_df, self.modelling_date, self.spark)

        return final_df
