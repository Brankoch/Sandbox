## Overview
This project is designed to process and transform data using PySpark. The main components include reading source data, transforming it, and writing the results back to a data lake.

## Folder Structure
The repository is organized as follows:

### `src/main/python/attr_afp/pipelines`
- `attr_afp_pipeline.py`: Contains the `AttrAfp` class which extends `CSOBPipeline` and defines the pipeline for processing data. Note: `CSOBPipeline` is located in repository https://agit.kbc.be:6088/scm/q1g/q1g_common.git.
- `transformations.py`: Contains the `transform` function and other helper functions to perform data transformations.

### `src/test/python/attr_afp`
- `test_attr_afp_pipeline.py`: Contains unit tests for the `AttrAfp` pipeline.

### `script`
- Contains scripts used to call this functionality from Airflow or the local environment.

### `environment.yaml`
- Environment dependency configuration. Lists all the required libraries for the project.

### `Jenkinsfile`
- CI/CD configuration for Jenkins.

## Getting Started
To get started with this project, follow these steps:

1. Clone the repository:
    ```sh
    git clone https://agit.kbc.be:6088/scm/q1g/q1g_feature_attr_afp.git
    ```
=======
# feature-attr-afp ETL pipeline -
