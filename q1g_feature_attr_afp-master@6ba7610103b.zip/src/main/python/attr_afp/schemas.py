from pyspark.sql.types import StructType, StructField, IntegerType, StringType

# replace with you real schemas
example_schema = StructType(
    [

    ]
)
