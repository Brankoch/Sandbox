def transform(sources_df, modelling_date, spark):
    """
    transform
    :param sources_df: Dictionary containing source DataFrames
    :param modelling_date: The modelling date for processing
    :param spark: Spark session
    :return df_attr_afp_new: Transformed DataFrame
    """
    ccdb__oh__w_event = sources_df['master']['ccdb__oh__w_event']
    ccdb__oh__w_event_tick = sources_df['master']['ccdb__oh__w_event_tick ']
    ccdb__oh__w_party = sources_df['master']['ccdb__oh__w_party']
    ccdb__oh__w_person_fact = sources_df["master"]["ccdb__oh__w_person_fact"]
    ccdb__oh__w_property_value = sources_df["master"]["ccdb__oh__w_property_value"]
    ccdb__oh__w_real_estate_fact = sources_df["master"]["ccdb__oh__w_real_estate_fact"]
    ccdb__oh__w_vehicle_fact = sources_df["master"]["ccdb__oh__w_vehicle_fact"]
    dmsk__l0_owner__party = sources_df['master']['dmsk__l0_owner__party']
    dmsk__l0_owner__party_rltd = sources_df['master']['dmsk__l0_owner__party_rltd']
    feature__attr_client_base = sources_df['feature']['pm_owner__attr_client_base']

    # Create STG_AFP data
    df_stg_afp = get_stg_afp(
        feature__attr_client_base,
        dmsk__l0_owner__party,
        dmsk__l0_owner__party_rltd,
        ccdb__oh__w_person_fact,
        ccdb__oh__w_party,
        ccdb__oh__w_property_value,
        ccdb__oh__w_real_estate_fact,
        ccdb__oh__w_vehicle_fact, 
        ccdb__oh__w_event,
        modelling_date,
        spark
    )
    
    # Create STG_PRODUCT_INTEREST_AFP data
    df_stg_product_interest_afp = get_stg_product_interest_afp(
        feature__attr_client_base,
        dmsk__l0_owner__party,
        dmsk__l0_owner__party_rltd,
        ccdb__oh__w_event_tick,
        modelling_date,
        spark
    )
    
    # Create STG_EXTRA_INFO data
    df_stg_extra_info = get_stg_extra_info(
        feature__attr_client_base,
        dmsk__l0_owner__party,
        dmsk__l0_owner__party_rltd,
        modelling_date,
        spark
    )
    
    # Create final ATTR_AFP result
    df_attr_afp_new = get_final_attr_afp(
        feature__attr_client_base,
        df_stg_afp,
        df_stg_product_interest_afp,
        df_stg_extra_info,
        dmsk__l0_owner__party,
        modelling_date,
        spark
    )
    
    return df_attr_afp_new


def get_stg_afp(feature__attr_client_base, dmsk__l0_owner__party,
               dmsk__l0_owner__party_rltd, ccdb__oh__w_person_fact, ccdb__oh__w_party,
               ccdb__oh__w_property_value, ccdb__oh__w_real_estate_fact,
               ccdb__oh__w_vehicle_fact, ccdb__oh__w_event, modelling_date, spark):
    """
    Create STG_AFP data with person facts and related information
    """
    # Create temporary views for SQL processing
    feature__attr_client_base.createOrReplaceTempView("ATTR_CLIENT_BASE")
    dmsk__l0_owner__party.createOrReplaceTempView("L0_OWNER__PARTY")
    dmsk__l0_owner__party_rltd.createOrReplaceTempView("L0_OWNER__PARTY_RLTD")
    
    # Create views for CCDB tables (if available)
    if ccdb__oh__w_person_fact:
        ccdb__oh__w_person_fact.createOrReplaceTempView("CCDB_OWNER__OH_W_PERSON_FACT")
    if ccdb__oh__w_party:
        ccdb__oh__w_party.createOrReplaceTempView("CCDB_OWNER__OH_W_PARTY") 
    if ccdb__oh__w_property_value:
        ccdb__oh__w_property_value.createOrReplaceTempView("CCDB_OWNER__OH_W_PROPERTY_VALUE")
    if ccdb__oh__w_real_estate_fact:
        ccdb__oh__w_real_estate_fact.createOrReplaceTempView("CCDB_OWNER__OH_W_REAL_ESTATE_FACT")
    if ccdb__oh__w_vehicle_fact:
        ccdb__oh__w_vehicle_fact.createOrReplaceTempView("CCDB_OWNER__OH_W_VEHICLE_FACT")
    if ccdb__oh__w_event:
        ccdb__oh__w_event.createOrReplaceTempView("CCDB_OWNER__OH_W_EVENT")

    df_stg_afp = spark.sql("""
    SELECT DISTINCT
        ${process_dt} AS INSERT_DT,
        CLB.CUSTOMERID,
        PEF.CD_REC_PARTY,
        MAX(PEF.PERSON_FACT_START_DT) OVER (PARTITION BY CLB.CUSTOMERID) AFP_MOST_RECENT_DT,
        PEF.PERSON_FACT_START_DT,
        ROUND(${process_dt} - PEF.PERSON_FACT_START_DT) AS RECENCY_AFP,
        ROUND(${process_dt} - MIN(PEF.PERSON_FACT_START_DT) OVER (PARTITION BY CLB.CUSTOMERID)) AS DAYS_SINCE_FIRST_AFP,
        COALESCE(PEF.VL_NET_INCOME, 0) + COALESCE(PEF.VL_OTHER_INCOME, 0) AS AFP_NET_INCOME,
        COALESCE(PEF.VL_LIABILITIES, 0) AS AFP_LIABILITIES,
        COALESCE(PEF.VL_SAVINGS, 0) AS AFP_SAVINGS,

        CASE WHEN (COALESCE(PEF.VL_NET_INCOME, 0) + COALESCE(PEF.VL_OTHER_INCOME, 0)) > 0 
             THEN ROUND(COALESCE(PEF.VL_SAVINGS, 0) / (COALESCE(PEF.VL_NET_INCOME, 0) + COALESCE(PEF.VL_OTHER_INCOME, 0)), 4) 
             ELSE 0 END AS AFP_INCOME_RATIO_SAVED,
        CASE WHEN (COALESCE(PEF.VL_NET_INCOME, 0) + COALESCE(PEF.VL_OTHER_INCOME, 0)) > 0
             THEN ROUND(COALESCE(PEF.VL_LIABILITIES, 0) / (COALESCE(PEF.VL_NET_INCOME, 0) + COALESCE(PEF.VL_OTHER_INCOME, 0)), 4)
             ELSE 0 END AS AFP_INCOME_RATIO_LIABILITIES,

        PEF.CD_REC_VALUE_HOUSING_TYPE,

        CASE WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_01' THEN 1 ELSE 0 END AS AFP_MAIN_BANK,
        CASE WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_01' THEN 1 ELSE 0 END AS AFP_EMPLOYEE,
        CASE WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_07' THEN 1 ELSE 0 END AS AFP_PARENTALLEAVE,
        CASE WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_04' THEN 1 ELSE 0 END AS AFP_STUDENT,
        CASE WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_05' THEN 1 ELSE 0 END AS AFP_PENSION,
        CASE WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_02' THEN 1 ELSE 0 END AS AFP_ENTREPRENEUR,
        CASE WHEN INCOME_TYPE.CD_REC_VALUE NOT IN ('ET_01', 'ET_02', 'ET_04', 'ET_05', 'ET_07') 
             THEN 1 ELSE 0 END AS AFP_OTHERINCOME,

        --COALESCE(NM_CHILDREN, 0) AS NM_CHILDREN,
        PEF.CD_REC_VALUE_MARITAL_STATUS,

        CASE WHEN PEF.CD_REC_VALUE_HOUSING_TYPE = 'HT_01' THEN 'APARTMENT'
             WHEN PEF.CD_REC_VALUE_HOUSING_TYPE = 'HT_02' THEN 'RENTED APARTMENT'
             WHEN PEF.CD_REC_VALUE_HOUSING_TYPE = 'HT_03' THEN 'HOUSE'
             WHEN PEF.CD_REC_VALUE_HOUSING_TYPE = 'HT_04' THEN 'RENTED HOUSE'
             WHEN PEF.CD_REC_VALUE_HOUSING_TYPE = 'HT_08' THEN 'PARENTS'
             ELSE 'UNKNOWN' END AS AFP_HOUSING_TYPE,
        CASE WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_01' THEN 'EMPLOYEE'
             WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_07' THEN 'PARENTALLEAVE'
             WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_04' THEN 'STUDENT'
             WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_05' THEN 'PENSION'
             WHEN INCOME_TYPE.CD_REC_VALUE = 'ET_02' THEN 'ENTREPRENEUR'
             ELSE 'UNKNOWN' END AS AFP_INCOME_TYPE,
         CASE WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_01' THEN 'CSOB'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_02' THEN 'SLSP'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_03' THEN 'VUB'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_04' THEN 'TB'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_05' THEN 'PRIMA'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_10' THEN '365'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_12' THEN 'MBANK'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_21' THEN 'FIO'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_06' THEN 'UNICREDIT BANK'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_09' THEN 'RAIFFEISEN'
             WHEN PEF.CD_REC_VALUE_MAIN_BANK = 'PB_00' THEN 'UNKNOWN'
             ELSE 'OTHER' END AS AFP_PRIMARY_BANK,

        COALESCE(${process_dt} - RST.MOST_RECENT_REAL_ESTATE_DT_AFP, 1826) AS RECENCY_REAL_ESTATE_AFP,
        COALESCE(RST.C_HOUSE, 0) AS C_HOUSE, -- RODINNY DOM
        COALESCE(RST.C_APARTMENT, 0) AS C_APARTMENT, -- BYT
        COALESCE(RST.C_COTTAGE, 0) AS C_COTTAGE, -- CHATA
        COALESCE(RST.C_BUILDING_LOT, 0) AS C_BUILDING_LOT, -- STAVEBNY POZEMOK
        COALESCE(RST.C_COMMERCIAL_SPACE, 0) AS C_COMMERCIAL_SPACE, -- PODNIKATELSKY PRIESTOR
        COALESCE(RST.C_NON_RESIDENTIAL_SPACE, 0) AS C_NON_RESIDENTIAL_SPACE, -- NEBYTOVY PRIESTOR
        COALESCE(RST.C_GARAGE, 0) AS C_GARAGE, -- GARAZ/PARK. MIESTO
        COALESCE(RST.REFUSE_ANSWER_REAL_ESTATE, 0) AS REFUSE_ANSWER_REAL_ESTATE, -- KLIENT NECHCE UVIEST
        COALESCE(RST.C_HOUSE + RST.C_APARTMENT + RST.C_COTTAGE + RST.C_BUILDING_LOT 
                 + RST.C_COMMERCIAL_SPACE + RST.C_NON_RESIDENTIAL_SPACE + RST.C_GARAGE, 0) C_TOTAL_REAL_ESTATE,
        COALESCE(RST.CAT_REAL_ESTATE, 'UNKNOWN') AS CAT_REAL_ESTATE,
        COALESCE(${process_dt} - VEH.MOST_RECENT_VEHICLE_DT_AFP, 1826) AS RECENCY_VEHICLE_AFP,
        COALESCE(VEH.C_OWN_CAR, 0) AS C_OWN_CAR, -- VLASTNI AUTO BEZ UVERU
        COALESCE(VEH.C_LOAN_CAR, 0) AS C_LOAN_CAR, -- VLASTNI AUTO KUPENE NA UVER
        COALESCE(VEH.C_WORK_CAR, 0) AS C_WORK_CAR, -- MA K DISPOZICII SLUZOBNE AUTO
        COALESCE(VEH.C_MOTORCYCLE, 0) AS C_MOTORCYCLE, -- VLASTNI MOTOCYKEL / SKUTER
        COALESCE(VEH.NO_OWN_VEHICLE, 0) AS NO_OWN_VEHICLE, -- NEVLASTNI DOPRAVNY PROSTRIEDOK
        COALESCE(VEH.REFUSE_ANSWER_VEHICLE, 0) AS REFUSE_ANSWER_VEHICLE,
        COALESCE(VEH.C_OWN_CAR + VEH.C_LOAN_CAR + VEH.C_WORK_CAR + VEH.C_MOTORCYCLE, 0) AS C_TOTAL_VEHICLE,
        COALESCE(VEH.CAT_VEHICLE, 'UNKNOWN') AS CAT_VEHICLE     
    
    FROM CCDB_OWNER__OH_W_PERSON_FACT PEF
    
    JOIN CCDB_OWNER__OH_W_PARTY P
        ON PEF.CD_REC_PARTY = P.CD_REC_PARTY
        AND PEF.CD_REC_PARTY_OBJECT_TYPE = P.CD_REC_OBJECT_TYPE
        AND PEF.CD_REC_PARTY_OBJECT_TYPE_SOURCE = P.CD_REC_OBJECT_TYPE_SOURCE
        AND PEF.CD_REC_PARTY_SOURCE = P.CD_REC_SOURCE
        AND P.PARTY_END_DT > ${process_dt}
        AND P.PARTY_START_DT <= ${process_dt}
        AND P.DELETED_DT > ${process_dt}

    LEFT JOIN CCDB_OWNER__OH_W_PROPERTY_VALUE INCOME_TYPE
        ON PEF.CD_REC_VALUE_INCOME_TYPE = INCOME_TYPE.CD_REC_VALUE
        AND PEF.CD_REC_VALUE_INCOME_TYPE_SOURCE = INCOME_TYPE.CD_REC_VALUE_SOURCE
        AND INCOME_TYPE.CD_REC_PROPERTY = 'INCOME_TYPE'
        AND INCOME_TYPE.CD_REC_PROPERTY_SOURCE = 'CCDB'
        AND INCOME_TYPE.CD_REC_SOURCE = 'CUSTOMER_DIAGNOSTICS'
        AND INCOME_TYPE.PROPERTY_VALUE_END_DT > ${process_dt}
        AND INCOME_TYPE.PROPERTY_VALUE_START_DT <= ${process_dt}
        AND INCOME_TYPE.DELETED_DT > ${process_dt}

    JOIN L0_OWNER__PARTY P1
        ON P.CD_LGC_ORN_ARF_KEY = P1.PARTY_SRC_VAL
        AND P1.SRC_SYST_CD = 110
        AND P1.PARTY_SRC_KEY LIKE 'PMC%'
    
    JOIN L0_OWNER__PARTY_RLTD PR
        ON PR.CHILD_PARTY_ID = P1.PARTY_ID
        AND PR.PARTY_RLTD_RSN_CD = 4
        AND PR.PARTY_RLTD_START_DT <= ${process_dt}
        AND PR.PARTY_RLTD_END_DT > ${process_dt}
    
    JOIN (SELECT CUSTOMERID FROM ATTR_CLIENT_BASE
          WHERE MONTH_ID = CAST(DATE_FORMAT(${process_dt}, 'yyyyMM') AS INT) ) CLB
        ON PR.PARTY_ID = CLB.CUSTOMERID

    LEFT JOIN (
                SELECT 
                    CUID,
                    MAX(START_DT) AS MOST_RECENT_REAL_ESTATE_DT_AFP,
                    SUM(CASE WHEN CD_REC_VALUE_REAL_ESTATE_TYPE = 'RE_TY_02' THEN 1 ELSE 0 END) AS C_HOUSE, -- RODINNY DOM
                    SUM(CASE WHEN CD_REC_VALUE_REAL_ESTATE_TYPE = 'RE_TY_01' THEN 1 ELSE 0 END) AS C_APARTMENT, -- BYT
                    SUM(CASE WHEN CD_REC_VALUE_REAL_ESTATE_TYPE = 'RE_TY_03' THEN 1 ELSE 0 END) AS C_COTTAGE, -- CHATA
                    SUM(CASE WHEN CD_REC_VALUE_REAL_ESTATE_TYPE = 'RE_TY_04' THEN 1 ELSE 0 END) AS C_BUILDING_LOT, -- STAVEBNY POZEMOK
                    SUM(CASE WHEN CD_REC_VALUE_REAL_ESTATE_TYPE = 'RE_TY_05' THEN 1 ELSE 0 END) AS C_COMMERCIAL_SPACE, -- PODNIKATELSKY PRIESTOR
                    SUM(CASE WHEN CD_REC_VALUE_REAL_ESTATE_TYPE = 'RE_TY_06' THEN 1 ELSE 0 END) AS C_NON_RESIDENTIAL_SPACE, -- NEBYTOVY PRIESTOR
                    SUM(CASE WHEN CD_REC_VALUE_REAL_ESTATE_TYPE = 'RE_TY_07' THEN 1 ELSE 0 END) AS C_GARAGE, -- GARAZ/PARK. MIESTO
                    MAX(CASE WHEN CD_REC_VALUE_REAL_ESTATE_TYPE = 'RE_TY_00' THEN 1 ELSE 0 END) AS REFUSE_ANSWER_REAL_ESTATE, -- KLIENT NECHCE UVIEST
                    CASE WHEN LISTAGG(CD_REC_VALUE_REAL_ESTATE_TYPE) LIKE '%RE_TY_01%' AND LISTAGG(CD_REC_VALUE_REAL_ESTATE_TYPE) LIKE '%RE_TY_02%' THEN 'OWNER_HOUSE_AND_APARTMENT'
                         WHEN LISTAGG(CD_REC_VALUE_REAL_ESTATE_TYPE) LIKE '%RE_TY_02%' THEN 'OWNER_HOUSE'
                         WHEN LISTAGG(CD_REC_VALUE_REAL_ESTATE_TYPE) LIKE '%RE_TY_01%' THEN 'OWNER_APARTMENT'
                         WHEN LISTAGG(CD_REC_VALUE_REAL_ESTATE_TYPE) LIKE '%RE_TY_03%' THEN 'OWNER_COTTAGE'
                         WHEN LISTAGG(CD_REC_VALUE_REAL_ESTATE_TYPE) LIKE '%RE_TY_04%' THEN 'OWNER_BUILDING_LOT'
                         WHEN LISTAGG(CD_REC_VALUE_REAL_ESTATE_TYPE) LIKE '%RE_TY_05%' THEN 'OWNER_COMMERCIAL_SPACE'
                         WHEN LISTAGG(CD_REC_VALUE_REAL_ESTATE_TYPE) LIKE '%RE_TY_06%' OR LISTAGG(CD_REC_VALUE_REAL_ESTATE_TYPE) LIKE '%RE_TY_07%' THEN 'OTHER'
                         ELSE 'UNKNOWN' END AS CAT_REAL_ESTATE
                FROM
                (
                    SELECT
                        RES.CD_REC_VALUE_REAL_ESTATE_TYPE,
                        MAX(RES.REAL_ESTATE_FACT_START_DT) OVER (PARTITION BY EVT.CUID) RE_MOST_RECENT_DT,
                        EVT.CUID AS CUID,
                        RES.REAL_ESTATE_FACT_START_DT AS START_DT,
                        RES.REAL_ESTATE_FACT_END_DT

                    FROM CCDB_OWNER__OH_W_REAL_ESTATE_FACT RES
                    
                    JOIN (SELECT
                            CD_REC_THING_1,
                            MAX(SUBSTR (EVT.CD_REC_PARTY_1, 5, 10)) AS CUID
                          FROM CCDB_OWNER__OH_W_EVENT EVT
                            WHERE 1=1
                            AND EVT.CD_REC_OBJECT_TYPE_SOURCE = 'CCDB'
                            AND EVT.CD_REC_SOURCE = 'CUSTOMER_DIAGNOSTICS'
                            AND EVT.EVENT_START_DT <= ${process_dt}
                            AND EVT.EVENT_END_DT > ${process_dt}
                            AND EVT.DELETED_DT > ${process_dt}
                            AND EVT.CD_REC_THING_1_OBJECT_TYPE = 'OBJECT~THING~REAL_ESTATE'
                            AND EVT.CD_REC_PARTY_1_SOURCE = '110'
                            GROUP BY CD_REC_THING_1
                    ) EVT
                        ON RES.CD_REC_THING = EVT.CD_REC_THING_1
                        AND RES.CD_REC_THING_OBJECT_TYPE_SOURCE = 'CCDB'
                        AND RES.CD_REC_SOURCE = 'CUSTOMER_DIAGNOSTICS'
                        AND RES.REAL_ESTATE_FACT_START_DT <= ${process_dt}
                        AND RES.REAL_ESTATE_FACT_END_DT > ${process_dt}
                        AND RES.DELETED_DT > ${process_dt}
                        AND RES.CD_REC_THING_OBJECT_TYPE = 'OBJECT~THING~REAL_ESTATE'        
                )                            
                WHERE START_DT = RE_MOST_RECENT_DT
                GROUP BY CUID
    ) RST
        ON RST.CUID = P1.PARTY_SRC_VAL
    
    LEFT JOIN (
                SELECT 
                    CUID,
                    MAX(START_DT) AS MOST_RECENT_VEHICLE_DT_AFP,
                    SUM(CASE WHEN CD_REC_VALUE_VEHICLE_OWNERSHIP = 'VO_01' THEN 1 ELSE 0 END) AS C_OWN_CAR, -- VLASTNI AUTO BEZ UVERU
                    SUM(CASE WHEN CD_REC_VALUE_VEHICLE_OWNERSHIP = 'VO_02' THEN 1 ELSE 0 END) AS C_LOAN_CAR, -- VLASTNI AUTO KUPENE NA UVER
                    SUM(CASE WHEN CD_REC_VALUE_VEHICLE_OWNERSHIP = 'VO_03' THEN 1 ELSE 0 END) AS C_WORK_CAR, -- MA K DISPOZICII SLUZOBNE AUTO
                    SUM(CASE WHEN CD_REC_VALUE_VEHICLE_OWNERSHIP = 'VO_04' THEN 1 ELSE 0 END) AS C_MOTORCYCLE, -- VLASTNI MOTOCYKEL / SKUTER
                    MAX(CASE WHEN CD_REC_VALUE_VEHICLE_OWNERSHIP = 'VO_05' THEN 1 ELSE 0 END) AS NO_OWN_VEHICLE, -- NEVLASTNI DOPRAVNY PROSTRIEDOK
                    SUM(CASE WHEN CD_REC_VALUE_VEHICLE_OWNERSHIP = 'VO_00' THEN 1 ELSE 0 END) AS REFUSE_ANSWER_VEHICLE, -- KLIENT NECHCE UVIEST
                    CASE WHEN LISTAGG(CD_REC_VALUE_VEHICLE_OWNERSHIP) LIKE '%VO_01%' AND LISTAGG(CD_REC_VALUE_VEHICLE_OWNERSHIP) LIKE '%VO_04%' THEN 'OWNER_CAR_AND_MOTORCYCLE'
                         WHEN LISTAGG(CD_REC_VALUE_VEHICLE_OWNERSHIP) LIKE '%VO_01%' THEN 'OWNER_CAR'
                         WHEN LISTAGG(CD_REC_VALUE_VEHICLE_OWNERSHIP) LIKE '%VO_02%' THEN 'OWNER_LOANED_CAR'
                         WHEN LISTAGG(CD_REC_VALUE_VEHICLE_OWNERSHIP) LIKE '%VO_03%' THEN 'WORK_CAR'
                         WHEN LISTAGG(CD_REC_VALUE_VEHICLE_OWNERSHIP) LIKE '%VO_04%' THEN 'OWNER_MOTORCYCLE'
                         WHEN LISTAGG(CD_REC_VALUE_VEHICLE_OWNERSHIP) LIKE '%VO_05%' THEN 'NO_VEHICLE'
                         ELSE 'UNKNOWN' END AS CAT_VEHICLE
                FROM
                (
                    SELECT
                        VEH.CD_REC_VALUE_VEHICLE_OWNERSHIP,
                        MAX(VEH.VEHICLE_FACT_START_DT) OVER (PARTITION BY EVT.CUID) VEH_MOST_RECENT_DT,
                        EVT.CUID AS CUID,
                        VEH.VEHICLE_FACT_START_DT AS START_DT,
                        VEH.VEHICLE_FACT_END_DT

                    FROM CCDB_OWNER__OH_W_VEHICLE_FACT VEH
                    
                    JOIN (SELECT
                            CD_REC_THING_1,
                            MAX(SUBSTR (EVT.CD_REC_PARTY_1, 5, 10)) AS CUID
                          FROM CCDB_OWNER__OH_W_EVENT EVT
                            WHERE 1=1
                            AND EVT.CD_REC_OBJECT_TYPE_SOURCE = 'CCDB'
                            AND EVT.CD_REC_SOURCE = 'CUSTOMER_DIAGNOSTICS'
                            AND EVT.EVENT_START_DT <= ${process_dt}
                            AND EVT.EVENT_END_DT > ${process_dt}
                            AND EVT.DELETED_DT > ${process_dt}
                            AND EVT.CD_REC_THING_1_OBJECT_TYPE = 'OBJECT~THING~VEHICLE'
                            AND EVT.CD_REC_PARTY_1_SOURCE = '110'
                            GROUP BY CD_REC_THING_1
                    ) EVT
                        ON VEH.CD_REC_THING = EVT.CD_REC_THING_1
                        AND VEH.CD_REC_THING_OBJECT_TYPE_SOURCE = 'CCDB'
                        AND VEH.CD_REC_SOURCE = 'CUSTOMER_DIAGNOSTICS'
                        AND VEH.VEHICLE_FACT_START_DT <= ${process_dt}
                        AND VEH.VEHICLE_FACT_END_DT > ${process_dt}
                        AND VEH.DELETED_DT > ${process_dt}
                        AND VEH.CD_REC_THING_OBJECT_TYPE = 'OBJECT~THING~VEHICLE'
                )
                WHERE START_DT = VEH_MOST_RECENT_DT
                GROUP BY CUID
    ) VEH
        ON VEH.CUID = P1.PARTY_SRC_VAL
    
    WHERE 1=1
        AND PEF.CD_REC_SOURCE = 'CUSTOMER_DIAGNOSTICS'
        AND PEF.CD_REC_PARTY_SOURCE = '110'
        AND PEF.CD_REC_PARTY_OBJECT_TYPE = 'OBJECT~PARTY'
        AND PEF.PERSON_FACT_END_DT > ${process_dt}
        AND PEF.PERSON_FACT_START_DT <= ${process_dt}
        AND PEF.PERSON_FACT_START_DT > ${process_dt_hist}
        AND PEF.DELETED_DT > ${process_dt}
    """)
    
    return df_stg_afp


def get_stg_product_interest_afp(feature__attr_client_base, dmsk__l0_owner__party,
                                dmsk__l0_owner__party_rltd, ccdb__oh__w_event_tick,
                                modelling_date, spark):
    """
    Create STG_PRODUCT_INTEREST_AFP data with customer product interests
    """
    feature__attr_client_base.createOrReplaceTempView("ATTR_CLIENT_BASE")
    dmsk__l0_owner__party.createOrReplaceTempView("L0_OWNER__PARTY")
    dmsk__l0_owner__party_rltd.createOrReplaceTempView("L0_OWNER__PARTY_RLTD")
    
    # Create views for CCDB tables
    if ccdb__oh__w_event_tick:
        ccdb__oh__w_event_tick.createOrReplaceTempView("CCDB_OWNER__OH_W_EVENT_TICK")

    df_stg_product_interest_afp = spark.sql("""
        SELECT
            MAX(${process_dt}) AS INSERT_DT,
            CUSTOMERID,
            MAX(CASE WHEN PRODUCT = 'PROD_01' THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END ) AS RECENCY_WANT_CA_AFP,
            MAX(CASE WHEN PRODUCT = 'PROD_02' THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END ) AS RECENCY_WANT_STUDENTACC_AFP,
            MAX(CASE WHEN PRODUCT IN ('PROD_03', 'PROD_28') THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END ) AS RECENCY_WANT_CHILDACC_AFP,
            MAX(CASE WHEN PRODUCT IN ('PROD_04', 'PROD_28') THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_SA_AFP,
            MAX(CASE WHEN PRODUCT = 'PROD_07' THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_MTG_AFP,
            MAX(CASE WHEN PRODUCT = 'PROD_09' THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_CL_AFP,
            MAX(CASE WHEN PRODUCT = 'PROD_10' THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_CC_AFP,
            MAX(CASE WHEN PRODUCT = 'PROD_11' THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_OVD_AFP,
            MAX(CASE WHEN PRODUCT IN ('PROD_13', 'PROD_26', 'PROD_27') THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_FUND_AFP,
            MAX(CASE WHEN PRODUCT IN ('PROD_15', 'PROD_16') THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_TRAVELINS_AFP,
            MAX(CASE WHEN PRODUCT IN ('PROD_17', 'PROD_24', 'PROD_33') THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_LIFEINS_AFP,
            MAX(CASE WHEN PRODUCT = 'PROD_18' THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_HOMEINS_AFP,
            MAX(CASE WHEN PRODUCT = 'PROD_22' THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_MTPL_AFP,
            MAX(CASE WHEN PRODUCT = 'PROD_21' THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN ROUND(EVENT_DT - ${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_CASCO_AFP,
            MAX(CASE WHEN PRODUCT IN ('PROD_23', 'PROD_30') THEN ( CASE WHEN INTEREST_SHOWN = 'INTERESTED' THEN TRUNC(EVENT_DT) - TRUNC(${process_dt_hist})
                                                          WHEN INTEREST_SHOWN = 'NOT_INTERESTED' THEN ROUND(${process_dt_hist} - EVENT_DT)
                                                          WHEN INTEREST_SHOWN = 'LATER' THEN GREATEST(ROUND(EVENT_DT - ${process_dt_hist}) - 120, 0)
                                                          ELSE NULL END )
                     ELSE NULL END) AS RECENCY_WANT_PENSION_AFP
        FROM
        ( ---- ZAUJEM/NEZAUJEM O PRODUKT
            SELECT
               CLB.CUSTOMERID,
               --SUBSTR (A.CD_REC_PARTY_1, 5, 10) AS CUID,
               MAX(TRUNC(A.DT_BUS_EFF_FROM)) OVER (PARTITION BY CLB.CUSTOMERID, A.CD_REC_VALUE_PURPOSE) AS MOST_RECENT_AFP_PROD_INT_DT,
               TRUNC(A.DT_BUS_EFF_FROM) AS EVENT_DT,
               A.CD_VARIABLE AS INTEREST_SHOWN,
               A.CD_REC_VALUE_PURPOSE AS PRODUCT
            FROM CCDB_OWNER__OH_W_EVENT_TICK A
            
            LEFT JOIN L0_OWNER__PARTY P
            ON P.PARTY_SRC_VAL = SUBSTR(A.CD_REC_PARTY_1, 5, 10)
            AND P.SRC_SYST_CD = 110
            AND P.PARTY_SRC_KEY LIKE 'PMC%'
            
            LEFT JOIN L0_OWNER__PARTY_RLTD PR
            ON  PR.CHILD_PARTY_ID = P.PARTY_ID
            AND PR.PARTY_RLTD_RSN_CD = 4
            AND PR.PARTY_RLTD_START_DT <= ${process_dt}
            AND PR.PARTY_RLTD_END_DT > ${process_dt}
            
            JOIN (SELECT CUSTOMERID
                  FROM ATTR_CLIENT_BASE 
                  WHERE MONTH_ID = CAST(DATE_FORMAT(${process_dt}, 'yyyyMM') AS INT)
                ) CLB
            ON CLB.CUSTOMERID = PR.PARTY_ID
            
            WHERE A.CD_REC_SOURCE = 'CUSTOMER_DIAGNOSTICS'
            AND A.CD_REC_OBJECT_TYPE = 'OBJECT~EVENT~OPPORTUNITY'
            AND A.DT_BUS_EFF_FROM <= ${process_dt}
            AND A.DT_BUS_EFF_FROM > ${process_dt_hist}
            AND A.DELETED_DT > ${process_dt}
            AND A.CD_VARIABLE IN ('INTERESTED', 'LATER', 'NOT_INTERESTED')
        )
        
        WHERE EVENT_DT = MOST_RECENT_AFP_PROD_INT_DT
        GROUP BY CUSTOMERID
    """)
    
    return df_stg_product_interest_afp


def get_stg_extra_info(feature__attr_client_base, dmsk__l0_owner__party,
                      dmsk__l0_owner__party_rltd, modelling_date, spark):
    """
    Create STG_EXTRA_INFO data with marital status and company information
    """
    feature__attr_client_base.createOrReplaceTempView("ATTR_CLIENT_BASE")
    dmsk__l0_owner__party.createOrReplaceTempView("L0_OWNER__PARTY")
    dmsk__l0_owner__party_rltd.createOrReplaceTempView("L0_OWNER__PARTY_RLTD")

    df_stg_extra_info = spark.sql("""
        SELECT DISTINCT
                MAX(${process_dt}) AS INSERT_DT,
                ZAKLAD.CUSTOMERID,
                MAX(IP.INVESTICNY_PROFIL) INVESTICNY_PROFIL, --2019-09-13 - NOVY STLPEC
                MAX(ZAKLAD.ROD_STAV_DRUH) ROD_STAV_DRUH,
                MAX(ZAKLAD.ROD_STAV_ROZVEDENY) ROD_STAV_ROZVEDENY,
                MAX(ZAKLAD.ROD_STAV_SLOBODNY) ROD_STAV_SLOBODNY,
                MAX(ZAKLAD.ROD_STAV_VDOVEC) ROD_STAV_VDOVEC,
                MAX(ZAKLAD.ROD_STAV_NIE_JE_ZNAME) ROD_STAV_NIE_JE_ZNAME,
                MAX(ZAKLAD.ROD_STAV_ZENATY) ROD_STAV_ZENATY,
                MAX(ZAKLAD.ROD_STAV_REG_PAR) ROD_STAV_REG_PAR,
                
                MAX(ZAKLAD.P_STAV_LIKVIDACIA) P_STAV_LIKVIDACIA,
                MAX(ZAKLAD.P_STAV_ZANIKLY_SUBJEKT) P_STAV_ZANIKLY_SUBJEKT,
                MAX(ZAKLAD.P_STAV_KONKURZ) P_STAV_KONKURZ,
                MAX(ZAKLAD.P_STAV_UKONCENE_PODNIKANIE) P_STAV_UKONCENE_PODNIKANIE
                
            FROM
            ( ---- RODINNY STAV
                SELECT
                    CLB.CUSTOMERID,
                    P.PARTY_ID AS PARTY_ID_CUID,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 79 AND PARTY_STAT_TYPE_CD = 10013 THEN 1 ELSE 0 END) AS ROD_STAV_DRUH,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 79 AND PARTY_STAT_TYPE_CD = 10015 THEN 1 ELSE 0 END) AS ROD_STAV_ROZVEDENY,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 79 AND PARTY_STAT_TYPE_CD = 10016 THEN 1 ELSE 0 END) AS ROD_STAV_SLOBODNY,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 79 AND PARTY_STAT_TYPE_CD = 10017 THEN 1 ELSE 0 END) AS ROD_STAV_VDOVEC,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 79 AND PARTY_STAT_TYPE_CD = 10018 THEN 1 ELSE 0 END) AS ROD_STAV_NIE_JE_ZNAME,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 79 AND PARTY_STAT_TYPE_CD = 10019 THEN 1 ELSE 0 END) AS ROD_STAV_ZENATY,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 79 AND PARTY_STAT_TYPE_CD = 10145 THEN 1 ELSE 0 END) AS ROD_STAV_REG_PAR,
                    -- INFO O PRAVNICKYCH OSOBACH
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 81 AND PARTY_STAT_TYPE_CD = 10006 THEN 1 ELSE 0 END) AS P_STAV_LIKVIDACIA,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 81 AND PARTY_STAT_TYPE_CD = 10007 THEN 1 ELSE 0 END) AS P_STAV_ZANIKLY_SUBJEKT,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 81 AND PARTY_STAT_TYPE_CD IN (10009, 10027) THEN 1 ELSE 0 END) AS P_STAV_KONKURZ,
                    MAX(CASE WHEN PRS.PARTY_ROLE_CD = 81 AND PARTY_STAT_TYPE_CD = 10146 THEN 1 ELSE 0 END) AS P_STAV_UKONCENE_PODNIKANIE
            
                FROM (SELECT
                        CUSTOMERID
                      FROM ATTR_CLIENT_BASE
                      WHERE MONTH_ID = CAST(DATE_FORMAT(${process_dt}, 'yyyyMM') AS INT)
                ) CLB
                
                JOIN L0_OWNER__PARTY_RLTD PR
                    ON  PR.PARTY_ID = CLB.CUSTOMERID
                    AND PR.PARTY_RLTD_RSN_CD = 4
                    AND PR.PARTY_RLTD_START_DT <= ${process_dt}
                    AND PR.PARTY_RLTD_END_DT > ${process_dt}
                
                JOIN L0_OWNER__PARTY P
                    ON PR.CHILD_PARTY_ID = P.PARTY_ID
                    AND P.SRC_SYST_CD = 110
                    AND P.PARTY_SRC_KEY LIKE 'PMC%'
                
                -----   STAVY
                JOIN L0_OWNER__PARTY_ROLE_STAT PRS
                    ON  PRS.PARTY_ID = P.PARTY_ID
                    AND PRS.PARTY_ROLE_STAT_START_DT <= ${process_dt}
                    AND PRS.PARTY_ROLE_STAT_END_DT > ${process_dt}
                    AND PRS.PARTY_STAT_RSN_CD = 1 --JINY
                    AND PRS.PARTY_ROLE_CD IN (79,81,256)  
                GROUP BY
                    CLB.CUSTOMERID, P.PARTY_ID
            
            ) ZAKLAD
            
            --2019-09-13 - START
            LEFT JOIN (
                      SELECT
                      PS.PARTY_ID,
                      MAX(SG.SEG_GEN_DS) AS INVESTICNY_PROFIL
                      FROM L0_OWNER__PARTY_SEG PS
                      
                      JOIN L0_OWNER__SEG_GEN SG
                      ON SG.SEG_CD = PS.SEG_CD
                      AND SG.SEG_GEN_END_DT > ${process_dt}   
                      AND SG.SEG_GEN_START_DT <= ${process_dt}
                      
                      WHERE 
                      PS.MODEL_ID IN (520,213) AND
                      PS.PARTY_SEG_END_DT > ${process_dt} AND
                      PS.PARTY_SEG_START_DT <= ${process_dt}
                      
                      GROUP BY PS.PARTY_ID
            ) IP
                ON IP.PARTY_ID = ZAKLAD.PARTY_ID_CUID
                
                            GROUP BY ZAKLAD.CUSTOMERID
    """)
    
    return df_stg_extra_info


def get_final_attr_afp(feature__attr_client_base, df_stg_afp, df_stg_product_interest_afp,
                      df_stg_extra_info, dmsk__l0_owner__party, modelling_date, spark):
    """
    Create final ATTR_AFP result by combining all staging tables
    """
    feature__attr_client_base.createOrReplaceTempView("ATTR_CLIENT_BASE")
    df_stg_afp.createOrReplaceTempView("STG_AFP")
    df_stg_product_interest_afp.createOrReplaceTempView("STG_PRODUCT_INTEREST_AFP")
    df_stg_extra_info.createOrReplaceTempView("STG_EXTRA_INFO")
    dmsk__l0_owner__party.createOrReplaceTempView("L0_OWNER__PARTY")

    df_final_attr_afp = spark.sql("""
        SELECT
            MONTH_ID,
            CUSTOMERID,
            I_AFP_Y,
            I_AFP_5Y,
            RECENCY_AFP,
            CAT_HOUSING_TYPE_AFP_Y,
            CAT_INCOME_TYPE_AFP_Y,
            CAT_HOUSING_TYPE_AFP,
            CAT_INCOME_TYPE_AFP,
            CAT_MARITAL_STATUS,
            CAT_PRIMARY_BANK_AFP,
            CAT_REAL_ESTATE_AFP,
            CAT_VEHICLE_AFP,
            CAT_TITLE_PD,
            LEN_STUDY_Y_PD,
            NET_INCOME_AFP_Y,
            LIABILITIES_AFP_Y,
            SAVINGS_AFP_Y,
            INCOME_RATIO_SAVED_AFP_Y,
            INCOME_RATIO_LIABILITIES_AFP_Y,
            I_MAIN_BANK_AFP_Y,
            I_EMPLOYEE_AFP_Y,
            I_PARENTALLEAVE_AFP_Y,
            I_STUDENT_AFP_Y,
            I_ENTREPRENEUR_AFP_Y,
            I_OTHERINCOME_AFP_Y,
            NET_INCOME_AFP,
            LIABILITIES_AFP,
            SAVINGS_AFP,
            INCOME_RATIO_SAVED_AFP,
            INCOME_RATIO_LIABILITIES_AFP,
            I_MAIN_BANK_AFP,
            I_EMPLOYEE_AFP,
            I_PARENTALLEAVE_AFP,
            I_STUDENT_AFP,
            I_PENSION_AFP,
            I_ENTREPRENEUR_AFP,
            I_OTHERINCOME_AFP,
            RECENCY_WANT_BANK_PRODUCT_AFP,
            RECENCY_WANT_INS_PRODUCT_AFP,
            RECENCY_WANT_LOAN_AFP,
            RECENCY_WANT_DDA_AFP,
            RECENCY_WANT_DEPOSIT_AFP,
            RECENCY_WANT_INS_CAR_AFP,
            RECENCY_WANT_CA_AFP,
            RECENCY_WANT_STUDENTACC_AFP,
            RECENCY_WANT_CHILDACC_AFP,
            RECENCY_WANT_SA_AFP,
            RECENCY_WANT_MTG_AFP,
            RECENCY_WANT_CL_AFP,
            RECENCY_WANT_CC_AFP,
            RECENCY_WANT_OVD_AFP,
            RECENCY_WANT_FUND_AFP,
            RECENCY_WANT_TRAVELINS_AFP,
            RECENCY_WANT_LIFEINS_AFP,
            RECENCY_WANT_HOMEINS_AFP,
            RECENCY_WANT_MTPL_AFP,
            RECENCY_WANT_CASCO_AFP,
            RECENCY_WANT_PENSION_AFP,
            I_WANT_BANK_PRODUCT_AFP_M,
            I_WANT_INS_PRODUCT_AFP_M,
            I_WANT_LOAN_AFP_M,
            I_WANT_DDA_AFP_M,
            I_WANT_DEPOSIT_AFP_M,
            I_WANT_INS_CAR_AFP_M,
            I_WANT_CA_AFP_M,
            I_WANT_STUDENTACC_AFP_M,
            I_WANT_CHILDACC_AFP_M,
            I_WANT_SA_AFP_M,
            I_WANT_MTG_AFP_M,
            I_WANT_CL_AFP_M,
            I_WANT_CC_AFP_M,
            I_WANT_OVD_AFP_M,
            I_WANT_FUND_AFP_M,
            I_WANT_TRAVELINS_AFP_M,
            I_WANT_LIFEINS_AFP_M,
            I_WANT_HOMEINS_AFP_M,
            I_WANT_MTPL_AFP_M,
            I_WANT_CASCO_AFP_M,
            I_WANT_PENSION_AFP_M,
            I_WANT_BANK_PRODUCT_AFP_Q,
            I_WANT_INS_PRODUCT_AFP_Q,
            I_WANT_LOAN_AFP_Q,
            I_WANT_DDA_AFP_Q,
            I_WANT_DEPOSIT_AFP_Q,
            I_WANT_INS_CAR_AFP_Q,
            I_WANT_CA_AFP_Q,
            I_WANT_STUDENTACC_AFP_Q,
            I_WANT_CHILDACC_AFP_Q,
            I_WANT_SA_AFP_Q,
            I_WANT_MTG_AFP_Q,
            I_WANT_CL_AFP_Q,
            I_WANT_CC_AFP_Q,
            I_WANT_OVD_AFP_Q,
            I_WANT_FUND_AFP_Q,
            I_WANT_TRAVELINS_AFP_Q,
            I_WANT_LIFEINS_AFP_Q,
            I_WANT_HOMEINS_AFP_Q,
            I_WANT_MTPL_AFP_Q,
            I_WANT_CASCO_AFP_Q,
            I_WANT_PENSION_AFP_Q,
            INVESTING_PROFILE,
            I_MARITAL_STATUS_COMPANION,
            I_MARITAL_STATUS_DIVORCED,
            I_MARITAL_STATUS_SINGLE,
            I_MARITAL_STATUS_WIDOWED,
            I_MARITAL_STATUS_UNKNOWN,
            I_MARITAL_STATUS_MARRIED,
            I_COMPANY_LIQ_OR_BANKRUPT,
            I_COMPANY_OUT_OF_BUSINESS,
            I_COMPANY_LIQ_BANKRUPT_OOB,
            RECENCY_REAL_ESTATE_AFP,
            C_HOUSE_AFP,
            C_APARTMENT_AFP,
            C_COTTAGE_AFP,
            C_BUILDING_LOT_AFP,
            C_COMMERCIAL_SPACE_AFP,
            C_GARAGE_AFP,
            I_REFUSE_ANSWER_REAL_ESTATE_AFP,
            C_TOTAL_REAL_ESTATE_AFP,
            RECENCY_VEHICLE_AFP,
            C_OWN_CAR_AFP,
            C_LOAN_CAR_AFP,
            C_WORK_CAR_AFP,
            C_MOTORCYCLE_AFP,
            I_NO_OWN_VEHICLE_AFP,
            I_REFUSE_ANSWER_VEHICLE_AFP,
            C_TOTAL_VEHICLE_AFP  
      )
      (
            SELECT 
                BASE.MONTH_ID,
                BASE.CUSTOMERID,
                
                CASE WHEN COALESCE(AFP.RECENCY_AFP, ${process_dt} - ${process_dt_hist}) < 366 THEN 1 ELSE 0 END I_AFP_Y,
                CASE WHEN COALESCE(AFP.RECENCY_AFP, ${process_dt} - ${process_dt_hist}) < 1826 THEN 1 ELSE 0 END I_AFP_5Y,
                COALESCE(AFP.RECENCY_AFP, ${process_dt} - ${process_dt_hist}) RECENCY_AFP,
                
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_HOUSING_TYPE, 'UNKNOWN') ELSE 'UNKNOWN' END CAT_HOUSING_TYPE_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_INCOME_TYPE, 'UNKNOWN') ELSE 'UNKNOWN' END CAT_INCOME_TYPE_AFP_Y,
                COALESCE(AFP.AFP_HOUSING_TYPE, 'UNKNOWN') CAT_HOUSING_TYPE_AFP,
                COALESCE(AFP.AFP_INCOME_TYPE, 'UNKNOWN') CAT_INCOME_TYPE_AFP,
                CASE WHEN SEI.ROD_STAV_DRUH = 1 THEN 'COMPANION'
                     WHEN SEI.ROD_STAV_ROZVEDENY = 1 THEN 'DIVORCED'
                     WHEN SEI.ROD_STAV_SLOBODNY = 1 THEN 'SINGLE'
                     WHEN SEI.ROD_STAV_VDOVEC = 1 THEN 'WIDOWED'
                     WHEN (SEI.ROD_STAV_ZENATY = 1 OR SEI.ROD_STAV_REG_PAR = 1) THEN 'MARRIED'
                     ELSE 'UNKNOWN' END AS CAT_MARITAL_STATUS,
                COALESCE(AFP.AFP_PRIMARY_BANK, 'UNKNOWN') CAT_PRIMARY_BANK_AFP,
                COALESCE(AFP.CAT_REAL_ESTATE, 'UNKNOWN') CAT_REAL_ESTATE_AFP,
                COALESCE(AFP.CAT_VEHICLE, 'UNKNOWN') CAT_VEHICLE_AFP,
                COALESCE(TTL.TITLE, 'NONE') CAT_TITLE_PD,
    
                CASE WHEN TTL.TITLE = 'BC.' THEN 3
                     WHEN TTL.TITLE = 'MGR.' THEN 5
                     WHEN TTL.TITLE = 'PHDR.' THEN 6
                     WHEN TTL.TITLE = 'PHD.' THEN 8
                     WHEN TTL.TITLE = 'MUDR.' THEN 6
                     WHEN TTL.TITLE = 'JUDR.' THEN 6
                     WHEN TTL.TITLE = 'ACADEMIC' THEN 10
                     WHEN TTL.TITLE = 'OTHER' THEN 3 --- MOST OF THE TITLES IN CATEGORY OTHER REQUIRE AT LEAST 3 YEARS TO ACHIEVE
                     ELSE 0 END AS LEN_STUDY_Y_PD,
                
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_NET_INCOME, -1) ELSE -1 END NET_INCOME_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_LIABILITIES, -1) ELSE -1 END LIABILITIES_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_SAVINGS, -1) ELSE -1 END SAVINGS_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_INCOME_RATIO_SAVED, 0) ELSE 0 END INCOME_RATIO_SAVED_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_INCOME_RATIO_LIABILITIES, 0) ELSE 0 END INCOME_RATIO_LIABILITIES_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_MAIN_BANK, -1) ELSE -1 END I_MAIN_BANK_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_EMPLOYEE, -1) ELSE -1 END I_EMPLOYEE_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_PARENTALLEAVE, -1) ELSE -1 END I_PARENTALLEAVE_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_STUDENT, -1) ELSE -1 END I_STUDENT_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_ENTREPRENEUR, -1) ELSE -1 END I_ENTREPRENEUR_AFP_Y,
                CASE WHEN AFP.RECENCY_AFP < 366 THEN COALESCE(AFP.AFP_OTHERINCOME, -1) ELSE -1 END I_OTHERINCOME_AFP_Y,
    
                COALESCE(AFP.AFP_NET_INCOME, -1) NET_INCOME_AFP,
                COALESCE(AFP.AFP_LIABILITIES, -1) LIABILITIES_AFP,
                COALESCE(AFP.AFP_SAVINGS, -1) SAVINGS_AFP,
                COALESCE(AFP.AFP_INCOME_RATIO_SAVED, 0) INCOME_RATIO_SAVED_AFP,
                COALESCE(AFP.AFP_INCOME_RATIO_LIABILITIES, 0) INCOME_RATIO_LIABILITIES_AFP,
                COALESCE(AFP.AFP_MAIN_BANK, -1) I_MAIN_BANK_AFP,
                COALESCE(AFP.AFP_EMPLOYEE, -1) I_EMPLOYEE_AFP,
                COALESCE(AFP.AFP_PARENTALLEAVE, -1) I_PARENTALLEAVE_AFP,
                COALESCE(AFP.AFP_STUDENT, -1) I_STUDENT_AFP,
                COALESCE(AFP.AFP_PENSION, -1) I_PENSION_AFP,
                COALESCE(AFP.AFP_ENTREPRENEUR, -1) I_ENTREPRENEUR_AFP,
                COALESCE(AFP.AFP_OTHERINCOME, -1) I_OTHERINCOME_AFP,
    
                CASE WHEN ABS(GREATEST(PINT.RECENCY_WANT_CA_AFP, PINT.RECENCY_WANT_STUDENTACC_AFP,
                                       PINT.RECENCY_WANT_CHILDACC_AFP, PINT.RECENCY_WANT_SA_AFP,
                                       PINT.RECENCY_WANT_MTG_AFP, PINT.RECENCY_WANT_CL_AFP,
                                       PINT.RECENCY_WANT_CC_AFP, PINT.RECENCY_WANT_OVD_AFP,
                                       PINT.RECENCY_WANT_FUND_AFP)) >= ABS(LEAST(PINT.RECENCY_WANT_CA_AFP, PINT.RECENCY_WANT_STUDENTACC_AFP,
                                                                                 PINT.RECENCY_WANT_CHILDACC_AFP, PINT.RECENCY_WANT_SA_AFP,
                                                                                 PINT.RECENCY_WANT_MTG_AFP, PINT.RECENCY_WANT_CL_AFP,
                                                                                 PINT.RECENCY_WANT_CC_AFP, PINT.RECENCY_WANT_OVD_AFP,
                                                                                 PINT.RECENCY_WANT_FUND_AFP)) 
                     THEN GREATEST(PINT.RECENCY_WANT_CA_AFP, PINT.RECENCY_WANT_STUDENTACC_AFP,
                                   PINT.RECENCY_WANT_CHILDACC_AFP, PINT.RECENCY_WANT_SA_AFP,
                                   PINT.RECENCY_WANT_MTG_AFP, PINT.RECENCY_WANT_CL_AFP,
                                   PINT.RECENCY_WANT_CC_AFP, PINT.RECENCY_WANT_OVD_AFP,
                                   PINT.RECENCY_WANT_FUND_AFP)
                     ELSE LEAST(PINT.RECENCY_WANT_CA_AFP, PINT.RECENCY_WANT_STUDENTACC_AFP,
                                PINT.RECENCY_WANT_CHILDACC_AFP, PINT.RECENCY_WANT_SA_AFP,
                                PINT.RECENCY_WANT_MTG_AFP, PINT.RECENCY_WANT_CL_AFP,
                                PINT.RECENCY_WANT_CC_AFP, PINT.RECENCY_WANT_OVD_AFP,
                                PINT.RECENCY_WANT_FUND_AFP) END AS RECENCY_WANT_BANK_PRODUCT_AFP,
                
                CASE WHEN ABS(GREATEST(PINT.RECENCY_WANT_TRAVELINS_AFP, PINT.RECENCY_WANT_LIFEINS_AFP,
                                       PINT.RECENCY_WANT_HOMEINS_AFP, PINT.RECENCY_WANT_MTPL_AFP,
                                       PINT.RECENCY_WANT_CASCO_AFP)) >= ABS(LEAST(PINT.RECENCY_WANT_TRAVELINS_AFP, PINT.RECENCY_WANT_LIFEINS_AFP,
                                                                                  PINT.RECENCY_WANT_HOMEINS_AFP, PINT.RECENCY_WANT_MTPL_AFP,
                                                                                  PINT.RECENCY_WANT_CASCO_AFP))
                     THEN GREATEST(PINT.RECENCY_WANT_TRAVELINS_AFP, PINT.RECENCY_WANT_LIFEINS_AFP,
                                   PINT.RECENCY_WANT_HOMEINS_AFP, PINT.RECENCY_WANT_MTPL_AFP,
                                   PINT.RECENCY_WANT_CASCO_AFP)
                     ELSE LEAST(PINT.RECENCY_WANT_TRAVELINS_AFP, PINT.RECENCY_WANT_LIFEINS_AFP,
                                PINT.RECENCY_WANT_HOMEINS_AFP, PINT.RECENCY_WANT_MTPL_AFP,
                                PINT.RECENCY_WANT_CASCO_AFP) END AS RECENCY_WANT_INS_PRODUCT_AFP,
                               
                CASE WHEN ABS(GREATEST(PINT.RECENCY_WANT_MTG_AFP, PINT.RECENCY_WANT_CL_AFP,
                                       PINT.RECENCY_WANT_CC_AFP, PINT.RECENCY_WANT_OVD_AFP)) >= ABS(LEAST(PINT.RECENCY_WANT_MTG_AFP, PINT.RECENCY_WANT_CL_AFP,
                                                                                                          PINT.RECENCY_WANT_CC_AFP, PINT.RECENCY_WANT_OVD_AFP))
                     THEN GREATEST(PINT.RECENCY_WANT_MTG_AFP, PINT.RECENCY_WANT_CL_AFP,
                                   PINT.RECENCY_WANT_CC_AFP, PINT.RECENCY_WANT_OVD_AFP)
                     ELSE LEAST(PINT.RECENCY_WANT_MTG_AFP, PINT.RECENCY_WANT_CL_AFP,
                                PINT.RECENCY_WANT_CC_AFP, PINT.RECENCY_WANT_OVD_AFP) END AS RECENCY_WANT_LOAN_AFP,
                                
                CASE WHEN ABS(GREATEST(PINT.RECENCY_WANT_CA_AFP, PINT.RECENCY_WANT_STUDENTACC_AFP,
                                       PINT.RECENCY_WANT_CHILDACC_AFP, PINT.RECENCY_WANT_SA_AFP)) >= ABS(LEAST(PINT.RECENCY_WANT_CA_AFP, PINT.RECENCY_WANT_STUDENTACC_AFP,
                                                                                                               PINT.RECENCY_WANT_CHILDACC_AFP, PINT.RECENCY_WANT_SA_AFP))
                     THEN GREATEST(PINT.RECENCY_WANT_CA_AFP, PINT.RECENCY_WANT_STUDENTACC_AFP,
                                   PINT.RECENCY_WANT_CHILDACC_AFP, PINT.RECENCY_WANT_SA_AFP)
                     ELSE LEAST(PINT.RECENCY_WANT_CA_AFP, PINT.RECENCY_WANT_STUDENTACC_AFP,
                                PINT.RECENCY_WANT_CHILDACC_AFP, PINT.RECENCY_WANT_SA_AFP) END AS RECENCY_WANT_DDA_AFP,
        
                CASE WHEN ABS(GREATEST(PINT.RECENCY_WANT_SA_AFP, PINT.RECENCY_WANT_FUND_AFP)) >= ABS(LEAST(PINT.RECENCY_WANT_SA_AFP, PINT.RECENCY_WANT_FUND_AFP))
                     THEN GREATEST(PINT.RECENCY_WANT_SA_AFP, PINT.RECENCY_WANT_FUND_AFP)
                     ELSE LEAST(PINT.RECENCY_WANT_SA_AFP, PINT.RECENCY_WANT_FUND_AFP) END AS RECENCY_WANT_DEPOSIT_AFP,
    
                CASE WHEN ABS(GREATEST(PINT.RECENCY_WANT_MTPL_AFP, PINT.RECENCY_WANT_CASCO_AFP)) >= ABS(LEAST(PINT.RECENCY_WANT_SA_AFP, PINT.RECENCY_WANT_FUND_AFP))
                     THEN GREATEST(PINT.RECENCY_WANT_SA_AFP, PINT.RECENCY_WANT_FUND_AFP)
                     ELSE LEAST(PINT.RECENCY_WANT_SA_AFP, PINT.RECENCY_WANT_FUND_AFP) END AS RECENCY_WANT_INS_CAR_AFP,
    
                PINT.RECENCY_WANT_CA_AFP,
                PINT.RECENCY_WANT_STUDENTACC_AFP,
                PINT.RECENCY_WANT_CHILDACC_AFP,
                PINT.RECENCY_WANT_SA_AFP,
                PINT.RECENCY_WANT_MTG_AFP,
                PINT.RECENCY_WANT_CL_AFP,
                PINT.RECENCY_WANT_CC_AFP,
                PINT.RECENCY_WANT_OVD_AFP,
                PINT.RECENCY_WANT_FUND_AFP,
                PINT.RECENCY_WANT_TRAVELINS_AFP,
                PINT.RECENCY_WANT_LIFEINS_AFP,
                PINT.RECENCY_WANT_HOMEINS_AFP,
                PINT.RECENCY_WANT_MTPL_AFP,
                PINT.RECENCY_WANT_CASCO_AFP,
                PINT.RECENCY_WANT_PENSION_AFP,
                
                CASE WHEN ABS(GREATEST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M,
                                       PINT.I_WANT_SA_AFP_M, PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M,
                                       PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M, PINT.I_WANT_FUND_AFP_M)) >= ABS(LEAST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M,
                                                                                                                             PINT.I_WANT_SA_AFP_M, PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M,
                                                                                                                             PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M, PINT.I_WANT_FUND_AFP_M))
                     THEN GREATEST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M,
                                   PINT.I_WANT_SA_AFP_M, PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M,
                                   PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M, PINT.I_WANT_FUND_AFP_M)
                     ELSE LEAST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M,
                                PINT.I_WANT_SA_AFP_M, PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M,
                                PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M, PINT.I_WANT_FUND_AFP_M) END AS I_WANT_BANK_PRODUCT_AFP_M,
                                
                CASE WHEN ABS(GREATEST(PINT.I_WANT_TRAVELINS_AFP_M, PINT.I_WANT_LIFEINS_AFP_M, PINT.I_WANT_HOMEINS_AFP_M,
                                       PINT.I_WANT_MTPL_AFP_M, PINT.I_WANT_CASCO_AFP_M)) >= ABS(LEAST(PINT.I_WANT_TRAVELINS_AFP_M, PINT.I_WANT_LIFEINS_AFP_M, PINT.I_WANT_HOMEINS_AFP_M,
                                                                                                      PINT.I_WANT_MTPL_AFP_M, PINT.I_WANT_CASCO_AFP_M))
                    THEN GREATEST(PINT.I_WANT_TRAVELINS_AFP_M, PINT.I_WANT_LIFEINS_AFP_M, PINT.I_WANT_HOMEINS_AFP_M,
                                  PINT.I_WANT_MTPL_AFP_M, PINT.I_WANT_CASCO_AFP_M)
                    ELSE LEAST(PINT.I_WANT_TRAVELINS_AFP_M, PINT.I_WANT_LIFEINS_AFP_M, PINT.I_WANT_HOMEINS_AFP_M,
                               PINT.I_WANT_MTPL_AFP_M, PINT.I_WANT_CASCO_AFP_M) END AS I_WANT_INS_PRODUCT_AFP_M,
                                             
                CASE WHEN ABS(GREATEST(PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M, PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M)) >= ABS(LEAST(PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M, PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M))
                    THEN GREATEST(PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M, PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M)
                    ELSE LEAST(PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M, PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M) END AS I_WANT_LOAN_AFP_M,
                               
                CASE WHEN ABS(GREATEST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M)) >= ABS(LEAST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M))
                     THEN GREATEST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M)
                     ELSE LEAST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M) END AS I_WANT_DDA_AFP_M,
                
                CASE WHEN ABS(GREATEST(PINT.I_WANT_SA_AFP_M, PINT.I_WANT_FUND_AFP_M)) >= ABS(LEAST(PINT.I_WANT_SA_AFP_M, PINT.I_WANT_FUND_AFP_M))
                     THEN GREATEST(PINT.I_WANT_SA_AFP_M, PINT.I_WANT_FUND_AFP_M)
                     ELSE LEAST(PINT.I_WANT_SA_AFP_M, PINT.I_WANT_FUND_AFP_M) END AS I_WANT_DEPOSIT_AFP_M,
                    
                CASE WHEN ABS(GREATEST(PINT.I_WANT_CASCO_AFP_M, PINT.I_WANT_MTPL_AFP_M)) >= ABS(LEAST(PINT.I_WANT_CASCO_AFP_M, PINT.I_WANT_MTPL_AFP_M))
                     THEN GREATEST(PINT.I_WANT_CASCO_AFP_M, PINT.I_WANT_MTPL_AFP_M)
                     ELSE LEAST(PINT.I_WANT_CASCO_AFP_M, PINT.I_WANT_MTPL_AFP_M) END AS I_WANT_INS_CAR_AFP_M,
    
                PINT.I_WANT_CA_AFP_M,
                PINT.I_WANT_STUDENTACC_AFP_M,
                PINT.I_WANT_CHILDACC_AFP_M,
                PINT.I_WANT_SA_AFP_M,
                PINT.I_WANT_MTG_AFP_M,
                PINT.I_WANT_CL_AFP_M,
                PINT.I_WANT_CC_AFP_M,
                PINT.I_WANT_OVD_AFP_M,
                PINT.I_WANT_FUND_AFP_M,
                PINT.I_WANT_TRAVELINS_AFP_M,
                PINT.I_WANT_LIFEINS_AFP_M,
                PINT.I_WANT_HOMEINS_AFP_M,
                PINT.I_WANT_MTPL_AFP_M,
                PINT.I_WANT_CASCO_AFP_M,
                PINT.I_WANT_PENSION_AFP_M,
    
                CASE WHEN ABS(GREATEST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M,
                                       PINT.I_WANT_SA_AFP_M, PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M,
                                       PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M, PINT.I_WANT_FUND_AFP_M)) >= ABS(LEAST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M,
                                                                                                                             PINT.I_WANT_SA_AFP_M, PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M,
                                                                                                                             PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M, PINT.I_WANT_FUND_AFP_M))
                     THEN GREATEST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M,
                                   PINT.I_WANT_SA_AFP_M, PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M,
                                   PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M, PINT.I_WANT_FUND_AFP_M)
                     ELSE LEAST(PINT.I_WANT_CA_AFP_M, PINT.I_WANT_STUDENTACC_AFP_M, PINT.I_WANT_CHILDACC_AFP_M,
                                PINT.I_WANT_SA_AFP_M, PINT.I_WANT_MTG_AFP_M, PINT.I_WANT_CL_AFP_M,
                                PINT.I_WANT_CC_AFP_M, PINT.I_WANT_OVD_AFP_M, PINT.I_WANT_FUND_AFP_M) END AS I_WANT_BANK_PRODUCT_AFP_M,
                                
                CASE WHEN ABS(GREATEST(PINT.I_WANT_TRAVELINS_AFP_Q, PINT.I_WANT_LIFEINS_AFP_Q, PINT.I_WANT_HOMEINS_AFP_Q,
                                       PINT.I_WANT_MTPL_AFP_Q, PINT.I_WANT_CASCO_AFP_Q)) >= ABS(LEAST(PINT.I_WANT_TRAVELINS_AFP_Q, PINT.I_WANT_LIFEINS_AFP_Q, PINT.I_WANT_HOMEINS_AFP_Q,
                                                                                                      PINT.I_WANT_MTPL_AFP_Q, PINT.I_WANT_CASCO_AFP_Q))
                    THEN GREATEST(PINT.I_WANT_TRAVELINS_AFP_Q, PINT.I_WANT_LIFEINS_AFP_Q, PINT.I_WANT_HOMEINS_AFP_Q,
                                  PINT.I_WANT_MTPL_AFP_Q, PINT.I_WANT_CASCO_AFP_Q)
                    ELSE LEAST(PINT.I_WANT_TRAVELINS_AFP_Q, PINT.I_WANT_LIFEINS_AFP_Q, PINT.I_WANT_HOMEINS_AFP_Q,
                               PINT.I_WANT_MTPL_AFP_Q, PINT.I_WANT_CASCO_AFP_Q) END AS I_WANT_INS_PRODUCT_AFP_Q,
                                             
                CASE WHEN ABS(GREATEST(PINT.I_WANT_MTG_AFP_Q, PINT.I_WANT_CL_AFP_Q, PINT.I_WANT_CC_AFP_Q, PINT.I_WANT_OVD_AFP_Q)) >= ABS(LEAST(PINT.I_WANT_MTG_AFP_Q, PINT.I_WANT_CL_AFP_Q, PINT.I_WANT_CC_AFP_Q, PINT.I_WANT_OVD_AFP_Q))
                    THEN GREATEST(PINT.I_WANT_MTG_AFP_Q, PINT.I_WANT_CL_AFP_Q, PINT.I_WANT_CC_AFP_Q, PINT.I_WANT_OVD_AFP_Q)
                    ELSE LEAST(PINT.I_WANT_MTG_AFP_Q, PINT.I_WANT_CL_AFP_Q, PINT.I_WANT_CC_AFP_Q, PINT.I_WANT_OVD_AFP_Q) END AS I_WANT_LOAN_AFP_Q,
                               
                CASE WHEN ABS(GREATEST(PINT.I_WANT_CA_AFP_Q, PINT.I_WANT_STUDENTACC_AFP_Q, PINT.I_WANT_CHILDACC_AFP_Q)) >= ABS(LEAST(PINT.I_WANT_CA_AFP_Q, PINT.I_WANT_STUDENTACC_AFP_Q, PINT.I_WANT_CHILDACC_AFP_Q))
                     THEN GREATEST(PINT.I_WANT_CA_AFP_Q, PINT.I_WANT_STUDENTACC_AFP_Q, PINT.I_WANT_CHILDACC_AFP_Q)
                     ELSE LEAST(PINT.I_WANT_CA_AFP_Q, PINT.I_WANT_STUDENTACC_AFP_Q, PINT.I_WANT_CHILDACC_AFP_Q) END AS I_WANT_DDA_AFP_Q,
                
                CASE WHEN ABS(GREATEST(PINT.I_WANT_SA_AFP_Q, PINT.I_WANT_FUND_AFP_Q)) >= ABS(LEAST(PINT.I_WANT_SA_AFP_Q, PINT.I_WANT_FUND_AFP_Q))
                     THEN GREATEST(PINT.I_WANT_SA_AFP_Q, PINT.I_WANT_FUND_AFP_Q)
                     ELSE LEAST(PINT.I_WANT_SA_AFP_Q, PINT.I_WANT_FUND_AFP_Q) END AS I_WANT_DEPOSIT_AFP_Q,
                    
                CASE WHEN ABS(GREATEST(PINT.I_WANT_CASCO_AFP_Q, PINT.I_WANT_MTPL_AFP_Q)) >= ABS(LEAST(PINT.I_WANT_CASCO_AFP_Q, PINT.I_WANT_MTPL_AFP_Q))
                     THEN GREATEST(PINT.I_WANT_CASCO_AFP_Q, PINT.I_WANT_MTPL_AFP_Q)
                     ELSE LEAST(PINT.I_WANT_CASCO_AFP_Q, PINT.I_WANT_MTPL_AFP_Q) END AS I_WANT_INS_CAR_AFP_Q,
    
                PINT.I_WANT_CA_AFP_Q,
                PINT.I_WANT_STUDENTACC_AFP_Q,
                PINT.I_WANT_CHILDACC_AFP_Q,
                PINT.I_WANT_SA_AFP_Q,
                PINT.I_WANT_MTG_AFP_Q,
                PINT.I_WANT_CL_AFP_Q,
                PINT.I_WANT_CC_AFP_Q,
                PINT.I_WANT_OVD_AFP_Q,
                PINT.I_WANT_FUND_AFP_Q,
                PINT.I_WANT_TRAVELINS_AFP_Q,
                PINT.I_WANT_LIFEINS_AFP_Q,
                PINT.I_WANT_HOMEINS_AFP_Q,
                PINT.I_WANT_MTPL_AFP_Q,
                PINT.I_WANT_CASCO_AFP_Q,
                PINT.I_WANT_PENSION_AFP_Q,
    
                CASE WHEN SEI.INVESTICNY_PROFIL = 'VELMI OPATRNÝ' THEN 1
                     WHEN SEI.INVESTICNY_PROFIL = 'OPATRNÝ' THEN 2
                     WHEN SEI.INVESTICNY_PROFIL = 'DOČASNÝ' THEN 3
                     WHEN SEI.INVESTICNY_PROFIL = 'ODVÁŽNÝ' THEN 4
                     WHEN SEI.INVESTICNY_PROFIL = 'VELMI ODVÁŽNÝ' THEN 5
                     ELSE 0 END AS INVESTING_PROFILE,
    
                COALESCE(SEI.ROD_STAV_DRUH, 0) AS I_MARITAL_STATUS_COMPANION,
                COALESCE(SEI.ROD_STAV_ROZVEDENY, 0) AS I_MARITAL_STATUS_DIVORCED,
                COALESCE(SEI.ROD_STAV_SLOBODNY, 0) AS I_MARITAL_STATUS_SINGLE,
                COALESCE(SEI.ROD_STAV_VDOVEC, 0) AS I_MARITAL_STATUS_WIDOWED,
                COALESCE(SEI.ROD_STAV_NIE_JE_ZNAME, 0) AS I_MARITAL_STATUS_UNKNOWN,
                COALESCE(GREATEST(SEI.ROD_STAV_ZENATY, SEI.ROD_STAV_REG_PAR), 0) AS I_MARITAL_STATUS_MARRIED,
     
                -- INFO PRAVNICKE OSOBY
                COALESCE(GREATEST(SEI.P_STAV_LIKVIDACIA, SEI.P_STAV_KONKURZ), 0) AS I_COMPANY_LIQ_OR_BANKRUPT,
                COALESCE(GREATEST(SEI.P_STAV_UKONCENE_PODNIKANIE, SEI.P_STAV_ZANIKLY_SUBJEKT), 0) AS I_COMPANY_OUT_OF_BUSINESS,
                COALESCE(GREATEST(SEI.P_STAV_ZANIKLY_SUBJEKT, SEI.P_STAV_KONKURZ, SEI.P_STAV_UKONCENE_PODNIKANIE, SEI.P_STAV_ZANIKLY_SUBJEKT), 0) AS I_COMPANY_LIQ_BANKRUPT_OOB,
    
                COALESCE(AFP.RECENCY_REAL_ESTATE_AFP, ${process_dt} - ${process_dt_hist}) AS RECENCY_REAL_ESTATE_AFP,
                COALESCE(AFP.C_HOUSE, 0) C_HOUSE_AFP, -- RODINNY DOM
                COALESCE(AFP.C_APARTMENT, 0) C_APARTMENT_AFP, -- BYT
                COALESCE(AFP.C_COTTAGE, 0) C_COTTAGE_AFP, -- CHATA
                COALESCE(AFP.C_BUILDING_LOT, 0) C_BUILDING_LOT_AFP, -- STAVEBNY POZEMOK
                COALESCE(AFP.C_COMMERCIAL_SPACE + AFP.C_NON_RESIDENTIAL_SPACE, 0) C_COMMERCIAL_SPACE_AFP, -- PODNIKATELSKY PRIESTOR ALEBO NEBYTOVY PRIESTOR
                COALESCE(AFP.C_GARAGE, 0) AS C_GARAGE_AFP, -- GARAZ/PARK. MIESTO
                COALESCE(AFP.REFUSE_ANSWER_REAL_ESTATE, 0) I_REFUSE_ANSWER_REAL_ESTATE_AFP, -- KLIENT NECHCE UVIEST
                COALESCE(AFP.C_TOTAL_REAL_ESTATE, 0) C_TOTAL_REAL_ESTATE_AFP,
    
                COALESCE(AFP.RECENCY_VEHICLE_AFP, ${process_dt} - ${process_dt_hist}) AS RECENCY_VEHICLE_AFP,
                COALESCE(AFP.C_OWN_CAR, 0) C_OWN_CAR_AFP,
                COALESCE(AFP.C_LOAN_CAR, 0) C_LOAN_CAR_AFP,
                COALESCE(AFP.C_WORK_CAR, 0) C_WORK_CAR_AFP,
                COALESCE(AFP.C_MOTORCYCLE, 0) C_MOTORCYCLE_AFP,
                COALESCE(AFP.NO_OWN_VEHICLE, 0) I_NO_OWN_VEHICLE_AFP,
                COALESCE(AFP.REFUSE_ANSWER_VEHICLE, 0) I_REFUSE_ANSWER_VEHICLE_AFP,
                COALESCE(AFP.C_TOTAL_VEHICLE, 0) C_TOTAL_VEHICLE_AFP
    
            FROM (SELECT CUSTOMERID, MONTH_ID
                  FROM ATTR_CLIENT_BASE
                  WHERE MONTH_ID = CAST(DATE_FORMAT(${process_dt}, 'yyyyMM') AS INT)
            ) BASE
    
            LEFT JOIN
            ( --- AFP
                SELECT
                    CUSTOMERID,
                    MIN(AFP_MOST_RECENT_DT) AFP_MOST_RECENT_DT,
                    MIN(DAYS_SINCE_FIRST_AFP) DAYS_SINCE_FIRST_AFP,
                    MIN(RECENCY_AFP) RECENCY_AFP,
                    MAX(AFP_NET_INCOME) AFP_NET_INCOME,
                    MAX(AFP_LIABILITIES) AFP_LIABILITIES,
                    MAX(AFP_SAVINGS) AFP_SAVINGS,
                    MAX(AFP_INCOME_RATIO_SAVED) AFP_INCOME_RATIO_SAVED,
                    MAX(AFP_INCOME_RATIO_LIABILITIES) AFP_INCOME_RATIO_LIABILITIES,
                    MAX(AFP_MAIN_BANK) AFP_MAIN_BANK,
                    MAX(AFP_EMPLOYEE) AFP_EMPLOYEE,
                    MAX(AFP_PARENTALLEAVE) AFP_PARENTALLEAVE,
                    MAX(AFP_STUDENT) AFP_STUDENT,
                    MAX(AFP_PENSION) AFP_PENSION, 
                    MAX(AFP_ENTREPRENEUR) AFP_ENTREPRENEUR,
                    MAX(AFP_OTHERINCOME) AFP_OTHERINCOME, 
                    --MAX(NM_CHILDREN) NM_CHILDREN,
                    MAX(AFP_HOUSING_TYPE) AFP_HOUSING_TYPE,
                    MAX(AFP_INCOME_TYPE) AFP_INCOME_TYPE,
                    MAX(AFP_PRIMARY_BANK) AFP_PRIMARY_BANK,
                    MIN(RECENCY_REAL_ESTATE_AFP) RECENCY_REAL_ESTATE_AFP,
                    MAX(C_HOUSE) C_HOUSE,
                    MAX(C_APARTMENT) C_APARTMENT,
                    MAX(C_COTTAGE) C_COTTAGE,
                    MAX(C_BUILDING_LOT) C_BUILDING_LOT,
                    MAX(C_COMMERCIAL_SPACE) C_COMMERCIAL_SPACE,
                    MAX(C_NON_RESIDENTIAL_SPACE) C_NON_RESIDENTIAL_SPACE,
                    MAX(C_GARAGE) C_GARAGE,
                    MAX(REFUSE_ANSWER_REAL_ESTATE) REFUSE_ANSWER_REAL_ESTATE,
                    MAX(C_TOTAL_REAL_ESTATE) C_TOTAL_REAL_ESTATE,
                    MAX(CAT_REAL_ESTATE) CAT_REAL_ESTATE,
                    MAX(RECENCY_VEHICLE_AFP) RECENCY_VEHICLE_AFP,
                    MAX(C_OWN_CAR) C_OWN_CAR,
                    MAX(C_LOAN_CAR) C_LOAN_CAR,
                    MAX(C_WORK_CAR) C_WORK_CAR,
                    MAX(C_MOTORCYCLE) C_MOTORCYCLE,
                    MAX(NO_OWN_VEHICLE) NO_OWN_VEHICLE,
                    MAX(REFUSE_ANSWER_VEHICLE) REFUSE_ANSWER_VEHICLE,
                    MAX(C_TOTAL_VEHICLE) C_TOTAL_VEHICLE,
                    MAX(CAT_VEHICLE) CAT_VEHICLE
                FROM STG_AFP
                WHERE PERSON_FACT_START_DT = AFP_MOST_RECENT_DT
                GROUP BY CUSTOMERID
            ) AFP
                ON BASE.CUSTOMERID = AFP.CUSTOMERID
    
            LEFT JOIN (SELECT
                            CLB.CUSTOMERID,
                            COALESCE(RECENCY_WANT_CA_AFP, 0) RECENCY_WANT_CA_AFP,
                            COALESCE(RECENCY_WANT_STUDENTACC_AFP, 0) RECENCY_WANT_STUDENTACC_AFP,
                            COALESCE(RECENCY_WANT_CHILDACC_AFP, 0) RECENCY_WANT_CHILDACC_AFP,
                            COALESCE(RECENCY_WANT_SA_AFP, 0) RECENCY_WANT_SA_AFP,
                            COALESCE(RECENCY_WANT_MTG_AFP, 0) RECENCY_WANT_MTG_AFP,
                            COALESCE(RECENCY_WANT_CL_AFP, 0) RECENCY_WANT_CL_AFP,
                            COALESCE(RECENCY_WANT_CC_AFP, 0) RECENCY_WANT_CC_AFP,
                            COALESCE(RECENCY_WANT_OVD_AFP, 0) RECENCY_WANT_OVD_AFP,
                            COALESCE(RECENCY_WANT_FUND_AFP, 0) RECENCY_WANT_FUND_AFP,
                            COALESCE(RECENCY_WANT_TRAVELINS_AFP, 0) RECENCY_WANT_TRAVELINS_AFP,
                            COALESCE(RECENCY_WANT_LIFEINS_AFP, 0) RECENCY_WANT_LIFEINS_AFP,
                            COALESCE(RECENCY_WANT_HOMEINS_AFP, 0) RECENCY_WANT_HOMEINS_AFP,
                            COALESCE(RECENCY_WANT_MTPL_AFP, 0) RECENCY_WANT_MTPL_AFP,
                            COALESCE(RECENCY_WANT_CASCO_AFP, 0) RECENCY_WANT_CASCO_AFP,
                            COALESCE(RECENCY_WANT_PENSION_AFP, 0) RECENCY_WANT_PENSION_AFP,
                            
                            CASE WHEN COALESCE(RECENCY_WANT_CA_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CA_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_CA_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_STUDENTACC_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_STUDENTACC_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_STUDENTACC_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_CHILDACC_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CHILDACC_AFP, 0) < ${process_dt_hist} -${process_dt} + 31 THEN -1
                                 ELSE 0 END AS I_WANT_CHILDACC_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_SA_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_SA_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_SA_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_MTG_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_MTG_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_MTG_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_CL_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CL_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_CL_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_CC_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CC_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_CC_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_OVD_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_OVD_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_OVD_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_FUND_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_FUND_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_FUND_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_TRAVELINS_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_TRAVELINS_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_TRAVELINS_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_LIFEINS_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_LIFEINS_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_LIFEINS_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_HOMEINS_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_HOMEINS_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_HOMEINS_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_MTPL_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_MTPL_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_MTPL_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_CASCO_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CASCO_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_CASCO_AFP_M,
                            CASE WHEN COALESCE(RECENCY_WANT_PENSION_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 31 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_PENSION_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 31 THEN -1
                                 ELSE 0 END AS I_WANT_PENSION_AFP_M,
                            
                            CASE WHEN COALESCE(RECENCY_WANT_CA_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CA_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_CA_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_STUDENTACC_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_STUDENTACC_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_STUDENTACC_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_CHILDACC_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CHILDACC_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_CHILDACC_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_SA_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_SA_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_SA_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_MTG_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_MTG_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_MTG_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_CL_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CL_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_CL_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_CC_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CC_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_CC_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_OVD_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_OVD_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_OVD_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_FUND_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_FUND_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_FUND_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_TRAVELINS_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_TRAVELINS_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_TRAVELINS_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_LIFEINS_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_LIFEINS_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_LIFEINS_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_HOMEINS_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_HOMEINS_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_HOMEINS_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_MTPL_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_MTPL_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_MTPL_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_CASCO_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_CASCO_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_CASCO_AFP_Q,
                            CASE WHEN COALESCE(RECENCY_WANT_PENSION_AFP, 0) > (${process_dt} - ${process_dt_hist}) - 93 THEN 1
                                 WHEN COALESCE(RECENCY_WANT_PENSION_AFP, 0) < (${process_dt_hist} - ${process_dt}) + 93 THEN -1
                                 ELSE 0 END AS I_WANT_PENSION_AFP_Q
                
                FROM (SELECT CUSTOMERID
                      FROM ATTR_CLIENT_BASE
                      WHERE MONTH_ID = CAST(DATE_FORMAT(${process_dt}, 'yyyyMM') AS INT) ) CLB
                
                LEFT JOIN STG_PRODUCT_INTEREST_AFP SPI
                    ON SPI.CUSTOMERID = CLB.CUSTOMERID
    
            ) PINT
                ON BASE.CUSTOMERID = PINT.CUSTOMERID
    
            LEFT JOIN
            ( --- NAJVYSIE DOSIAHNUTY TITUL
                SELECT 
                    CUSTOMERID,
                    CASE WHEN (TITLE LIKE '%MUDR%' OR TITLE LIKE '%MDDR%' OR TITLE LIKE '%MVDR%') THEN 'MUDR.'
                         WHEN TITLE LIKE '%JUDR%' THEN 'JUDR.'
                         WHEN (TITLE LIKE '%PHD%' OR TITLE LIKE '%DRSC%' OR TITLE LIKE '%CSC%') THEN 'PHD.'
                         WHEN (TITLE LIKE '%PHDR%' OR TITLE LIKE '%PHARMDR%' OR TITLE LIKE '%RNDR%' OR TITLE LIKE '%DR%' OR TITLE LIKE '%PAEDDR%') THEN 'PHDR.'
                         WHEN (TITLE LIKE '%MGR%' OR TITLE LIKE '%MGRART%' OR TITLE LIKE '%ING%' OR TITLE LIKE '%INGARCH%' OR TITLE LIKE '%MSC%' 
                               OR TITLE LIKE '%MA%' OR TITLE LIKE '%LLM%' OR TITLE LIKE '%MBA%' OR TITLE LIKE '%MGA%') THEN 'MGR.'
                         WHEN (TITLE LIKE '%DOC%' OR TITLE LIKE '%PROF%' OR TITLE LIKE '%DIS%') THEN 'ACADEMIC'
                         WHEN (TITLE LIKE '%BC%' OR TITLE LIKE '%BA%' OR TITLE LIKE '%BSC%') THEN 'BC.'
                         WHEN TITLE <> 'NONENONE' THEN 'OTHER'
                         ELSE 'NONE' END AS TITLE
                FROM
                (
                    SELECT
                        CLB.CUSTOMERID,
                        --- UPPERCASE OF TITLE BEFORE NAME + TITLE AFTER NAME IN ONE STRING WITH REMOVED WHITESPACES AND PUNCTUATION
                        UPPER(REPLACE(REPLACE(CONCAT(COALESCE(MAX(PIN.PARTY_INDIV_NM_TL_TX), 'NONE'),
                                                     COALESCE(MAX(CASE WHEN PIN.PARTY_INDIV_NM_SUFFIX_TX NOT IN ('ML.', 'ST.') THEN PIN.PARTY_INDIV_NM_SUFFIX_TX ELSE NULL END), 'NONE')),' ',''),'.','')) AS TITLE
    
                                        FROM L0_OWNER__PARTY P

                    JOIN L0_OWNER__PARTY_ROLE_STAT PRS
                        ON  P.PARTY_ID = PRS.PARTY_ID
                        AND PRS.PARTY_ROLE_CD IN (13, 28) --PARTY CMD
                        AND PRS.PARTY_ROLE_STAT_START_DT <= ${process_dt}
                        AND PRS.PARTY_ROLE_STAT_END_DT > ${process_dt}

                    JOIN L0_OWNER__PARTY_RLTD PR
                        ON  PR.CHILD_PARTY_ID = P.PARTY_ID
                        AND PR.PARTY_RLTD_RSN_CD = 4
                        AND PR.PARTY_RLTD_START_DT <= ${process_dt}
                        AND PR.PARTY_RLTD_END_DT > ${process_dt}
                    
                    JOIN (SELECT
                            CUSTOMERID 
                          FROM ATTR_CLIENT_BASE
                          WHERE MONTH_ID = CAST(DATE_FORMAT(${process_dt}, 'yyyyMM') AS INT)
                          ) CLB
                        ON CLB.CUSTOMERID = PR.PARTY_ID
                    
                    LEFT JOIN L0_OWNER__PARTY_INDIV_NM PIN
                        ON  PIN.PARTY_ID = P.PARTY_ID
                        AND PIN.NM_TYPE_CD = 1
                        AND PIN.PARTY_INDIV_NM_START_DT <= ${process_dt}
                        AND PIN.PARTY_INDIV_NM_END_DT > ${process_dt}
                    
                    WHERE
                        P.SRC_SYST_CD = 110 
                        AND P.PARTY_SUBTP_CD IN (0)
                        AND P.PARTY_SRC_KEY LIKE 'PMC%'
                    
                    GROUP BY
                        CLB.CUSTOMERID
                )
            ) TTL
                ON BASE.CUSTOMERID = TTL.CUSTOMERID
    
            LEFT JOIN STG_EXTRA_INFO SEI
                ON BASE.CUSTOMERID = SEI.CUSTOMERID
    
        )
    """)
    
    return df_final_attr_afp
