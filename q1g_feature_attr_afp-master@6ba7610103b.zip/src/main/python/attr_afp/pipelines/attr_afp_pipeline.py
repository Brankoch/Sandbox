from pyspark.sql import DataFrame
from q1g_common.pipelines.csob_pipeline import CSOBPipeline
from attr_afp.pipelines.attr_afp_transformations import transform

sources_master = {
    'ccdb__oh__w_event': {},
    'ccdb__oh__w_event_tick': {},
    'ccdb__oh__w_party': {},
    'ccdb__oh__w_person_fact': {},
    'ccdb__oh__w_property_value': {},
    'ccdb__oh__w_real_estate_fact': {},
    'ccdb__oh__w_vehicle_fact': {},
    'dmsk__l0_owner__party': {},
    'dmsk__l0_owner__party_indiv_nm': {},
    'dmsk__l0_owner__party_rltd': {},
    'dmsk__l0_owner__party_role_stat': {},
    'dmsk__l0_owner__party_seg': {},
    'dmsk__l0_owner__seg_gen': {}
}
sources_feature = {
    'attr_client_base': {},
    'dmsk__pm_owner__stg_extra_info': {},
    'dmsk__pm_owner__stg_product_interest_afp': {}
}
sources = {
    'feature': sources_feature,
    'master': sources_master
}

tkn_policies = {}


class AttrAfp(CSOBPipeline):

    def get_initial_configuration(self):
        self.modelling_date = self.business_date
        # L_MONTH_START_DT    DATE  := TRUNC(PROCESS_DT,'MM');
        # L_MONTH_END_DT      DATE  := LAST_DAY(PROCESS_DT);
        return sources, tkn_policies

    def transform_sources(self, sources_df: dict) -> DataFrame:
        final_df = transform(sources_df, self.modelling_date, self.spark)

        return final_df
