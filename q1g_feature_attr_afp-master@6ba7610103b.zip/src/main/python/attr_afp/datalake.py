from oktopuss_core.datalake import DefaultDatalake
from oktopuss_core.datalinks import ComponentDataLink
from oktopuss_datalake.datalake_env import update_environment
from oktopuss_datalake.datalakes.parser import Parser
from pkg_resources import resource_filename
from datalake_csobsk_q0g.datalake import Q0GDatalake


Master, _master_yml = Parser.parse(resource_filename('attr_afp', 'resources/datalakes/master'))
Feature, _feature_yml = Parser.parse(resource_filename('attr_afp', 'resources/datalakes/feature'))


class Datalake(DefaultDatalake):
    def __init__(self):
        DefaultDatalake.__init__(self)
        self.datalake = Q0GDatalake()
        self.environments.update(ds=self.initDataScienceEnvironment)

    def initDefaultEnvironment(self, env):
        env = self.datalake.initDefaultEnvironment(env)
        env = update_environment(env, Master, _master_yml)
        env = update_environment(env, Feature, _feature_yml)
        return env

    def initDataScienceEnvironment(self, env):
        env = self.initDefaultEnvironment(env)

        for datalink in Master:
            dl = env[datalink]

            # Set DS relative path just in cloud environment. For local development full path is required.
            if type(dl) is ComponentDataLink:
                env[datalink].set_path_to_ds_case_space()

        for datalink in Feature:
            dl = env[datalink]

            # Set DS relative path just in cloud environment. For local development full path is required.
            if type(dl) is ComponentDataLink:
                env[datalink].set_path_to_ds_case_space()

        return env
