#!/usr/bin/env python
import argparse
import logging
from oktopuss_common.logging import setupLogging
from q1g_common.utils.parser import parse_date_time

from attr_afp.pipelines.attr_afp_pipeline import AttrAfp

if __name__ == '__main__':
    # Command line argument parsing
    # These parameters will have to come from the airflow dag
    parser = argparse.ArgumentParser()
    parser.add_argument('--verbose', help='Set loglevel to debug', required=False, action='store_true')
    parser.add_argument('--business_date', help='Date for which to read data', required=True, type=str)
    parser.add_argument('--include_tokenization', help='Flag set to include tokenization mechanism', required=False,
                        action='store_false')
    arguments = parser.parse_args()

    # Parse business_date
    business_date = parse_date_time('business_date', arguments.business_date)
    include_tokenization = True if arguments.include_tokenization == "True" else False

    # Set up logger
    setupLogging(default_level=logging.DEBUG if arguments.verbose else logging.INFO)
    logger = logging.root

    pipeline = AttrAfp(
        business_date=business_date,
        target_key='attr_afp',
        target_layer='feature',
        include_tokenization=include_tokenization)
    pipeline.run_pipeline()
