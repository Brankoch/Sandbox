from os import path

from pybuilder.cli import main
from pybuilder.core import use_plugin, init, Author

########################################################################################################################
# INTRODUCTION
#
# PyBuilder is to Python what Maven is to Java.
#
# PyBuilder is a build tool to standardize the way a Python project should be
# structured and how it should be built, tested, packaged and uploaded.
#
# Where Maven uses a POM to describe the project, Python use a `build.py` file like this file
# as project descriptor.
#
# PyBuilder is run from the command line with actions to take while building,
# very aligned with what Maven supports:
#
#    `pyb +clean +install +publish +upload`
#
# If you simply run `pyb -X`, the `-X` activates debug logging and it runs the default tasks (cfr. underneath).
########################################################################################################################

########################################################################################################################
# MODULE ATTRIBUTES
#
# PyBuilder has a mechanism of module arguments that it copies onto the project at the start of the build.
#
# If you set a project property in your initializer like `project.version`, the module attribute `version`
# will overwrite the project property!
########################################################################################################################
# general python package attributes
name = 'q1g_feature_attr_afp'
version = '1.0.0'
summary = 'q1g_feature_attr_afp Spark project'
url = 'https://agit.kbc.be:6088/projects/Q1G/repos/q1g_feature_attr_afp/'
license = 'copyright (c) 2018, KBC NV. All rights reserved'
authors = [
    Author('KBC', 'oktopuss@kbc.be')
]

# where to upload in Nexus/PyPi?
distutils_release_repo = 'releases-q1g-python'

# bladelogic package attributes
# REMINDER summary attribute above is used as DESCRIPTION towards Bladelogic!
subsystem = 'q1g'

# deploy targets
deploy_servers = {
    'dev': 's2ab00np.be.srv.dev.sys',
    'acc': 's1s004um.be.srv.acc.sys',
    'pdn': 's0ab03ey.be.srv.sys'
}

# build control properties
requires_python = '>=3.7'
default_task = ['clean', 'analyze', 'install']


########################################################################################################################
# PLUGINS
#
# python.core             is the general plugin to deal with Python-based projects
# python.flake8           validates the code against PEP8 general Python code conventions
# python.unittest         to run the tests in `src/unittest/python/**_tests.py` that have to derive from
#                         `unittest.TestCase` and contain functions `test_*`
# python.integrationtest  runs the integrations tests in `src/integrationtest/python/**_tests.py` that
#                         have to derive from `unittest.TestCase` and contain functions `test_*`
# pyb_prep_itgtest_plugin adds your test data for integration tests to the execution path, by copying your
#                         `src/integrationtest/resources/**` files to `target/output/**`
# filter_resources        plugin allows to search files to replace keywords with project build-time values, e.g.
#                         in `__init__.py` files we typiccally replace `__name__ = {name}` and
#                         `__version__ = ${dist_version}`
# python.distuls*         runs the default PyPi packaging and upload to make the project available as library
#                         for other projects via `pip`.
# pyb_conda_env_create*   generates a Conda virtual environment at `/target/conda/runtime`, includes all the
#                         project's runtime dependencies and install the project itself in the environment.
# pyb_package_bladelogic  packages and uploads the project to Bladelogic.
# pyb_package_edison      to store information in an edison cicd repository to trigger a cloud build.
#
########################################################################################################################
use_plugin('python.core')
use_plugin('python.flake8')
use_plugin('filter_resources')
use_plugin('pyb_pytest')
use_plugin('pyb_conda_build')
use_plugin('pyb_conda_env_create')
use_plugin('copy_resources')
use_plugin('pyb_code_insights')

# for edison packaging
use_plugin('pyb_package_edison')
use_plugin('pyb_prep_itgtest_plugin')

@init
def initialize(project):
    # as much output as possible
    project.set_property('verbose', True)

    # Only enable sonar scanning
    project.set_property('code_insights_tpca_enabled', False)

    # configure edison packaging
    project.set_property('package_edison_cicd_repo', 'https://agit.kbc.be:6088/scm/q1g/q1g_cicd.git')

    # currently we only filter __init__.py files;
    # the replace() at the end is to make this joined path work on Windows (GLOW laptops)
    project.get_property('filter_resources_glob').append(
        path.join('**', 'attr_afp', '__init__.py').replace('\\', '\\\\')
    )

    # configure flake to test as many files as possible for PEP8 compliance
    # and break the build if not compliant
    project.set_property('flake8_include_test_sources', True)
    project.set_property("flake8_break_build", True)
    project.set_property('flake8_verbose_output', True)

    # for now, code coverage does not break the build
    # as we do Python, a scripted language, you have to aim for 100% coverage!
    project.set_property('coverage_break_build', False)

    # run the unit tests
    project.set_property('pytest_run_unittests', False)

    # run the integration tests
    project.set_property('integrationtest_always_verbose', True)
    project.set_property('integrationtest_inherit_environment', True)

    # configure PyPI package uploading
    # to make the upload repository work, your home directory must contain `.pypirc` file
    # that is configured to resolve the repository's name to its URL and username + password if so required
    # project.set_property('distutils_upload_repository', distutils_release_repo)
    project.set_property('condabuild_repository', 'releases-q1g-conda')
    project.set_property('distutils_classifiers', [
        'Development Status :: 3 - Alpha',
        'License :: Other/Proprietary License',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3.9',
        'Topic :: Software Development :: Libraries',
        'Topic :: Software Development :: Libraries :: Application Frameworks',
        'Intended Audience :: Developers',
        'Natural Language :: English'
    ])

    project.include_file('attr_afp', 'resources/datalakes/clean/*.yml')


if __name__ == '__main__':
    main()
